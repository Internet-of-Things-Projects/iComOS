/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
#ifdef _QUECTEL_OPEN_CPU_

#ifndef __EXAMPLE_H__
#define __EXAMPLE_H__

void main_task( void *unused );

#ifdef __EXAMPLE_MULTITASK__
void sub_task1( void *unused);
void sub_task2( void *unused);
#endif

#endif

#endif