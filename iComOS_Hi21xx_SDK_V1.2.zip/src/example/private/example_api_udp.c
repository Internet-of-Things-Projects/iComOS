/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_udp.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use UDP API functions communication in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_UDP__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "create udp" conmand via uart1 to create UDP port. 
*     2.Input "send data"  conmand via uart1 to send data with UDP server communication.
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_UDP__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "example.h"

#define UART_QUEUE_LEN  3

const uint32 UART_QUEUE_ITEM_SIZE = 4;

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	APP_DEBUG("<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("<-- error: set cfun fail-->\r\n");
	}
}

static void ql_socket_recv_cb(int socket, ssize_t length)
{
	ssize_t len = length;
	char buf[100] = {0};
	char ip[50] = {0};
	uint16 port = 0;
	QL_RET ql_ret= 0;
	
	APP_DEBUG("<-- socket receive callback, socket:%d,length:%d-->\r\n",socket,length);

	while(len>0)
	{
		ql_ret = ql_soc_recvfrom((uint16)socket,buf,sizeof(buf),ip,sizeof(ip),&port);

		if (QL_RET_OK == ql_ret)
		{
			APP_DEBUG("<-- received data from:%s:%d,%s-->\r\n",ip,port,buf);
		}
		else
		{
			APP_DEBUG("<--Error: received data fail-->\r\n");
		}
		ql_soc_remainlen((uint16)socket,(uint32*) &len);
	}
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16 soc_index = 0xFFFF, autocon, local_port = 0;
    QL_RET ql_ret  = 0;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API UDP Example -->\r\n");
    APP_DEBUG("<-- step1: create udp -->\r\n");
    APP_DEBUG("<-- step2: send data -->\r\n");

    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("<-- Disable AUTOCONNECT network and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    ql_set_cfun(1,cfun_callback);
    ql_set_cereg_callback(cereg_callback);
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s ",uart_buf);

			if (NULL != strstr((char*)uart_buf,"create udp"))
			{
				ql_ret = ql_soc_create(&soc_index,UDP,IPV4,NULL,local_port++,ql_socket_recv_cb);
				if (QL_RET_OK == ql_ret)
				{
					 APP_DEBUG("<-- create udp socket success, socket:%d -->\r\n",soc_index);
				}
				else 
				{
					APP_DEBUG("<--Error: create udp socket fail, ret:%d -->\r\n",ql_ret);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"send data"))
			{
				static uint8 seq_num =0;
				uint32 sent_len = 0;
				char *str = "hello, I am come from udp client!";

				sent_len = 0;
				ql_ret = ql_soc_sendto_with_ind(soc_index,seq_num++,str,strlen(str),QL_SOCMSG_NORMAL,"220.180.239.212",8052,&sent_len);
				if (QL_RET_OK == ql_ret)
				{
					 APP_DEBUG("<-- sent udp data success, lenght:%d -->\r\n",sent_len);
				}
				else 
				{
					APP_DEBUG("<--Error: sent udp data fail, ret:%d -->\r\n",ql_ret);
				}
			}
			else
			{
				APP_DEBUG("\r\n<-- Error: Unknown input -->\r\n");
			}
       }
       (void)osThreadYield(); 
    }

}
#endif // __EXAMPLE_API_UDP__