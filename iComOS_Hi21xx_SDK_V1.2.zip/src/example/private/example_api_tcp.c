/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_tcp.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use TCP API functions communication in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_TCP__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "cerate tcp"  conmand via uart1 to create TCP port. 
*     2.Input "tcp connect" conmand via uart1 to connect the TCP server.
*     2.Input "send data"   conmand via uart1 to send data with TCP server communication.
*
* Author: Benjamin.Lu
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_TCP__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "example.h"

#define UART_QUEUE_LEN              3
#define SOCK_CLOSE_RSP_LEN          12
#define QL_MAX_SENT_DATA_RSP_LEN    20

const uint32 UART_QUEUE_ITEM_SIZE = 4;

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void ql_socket_recv_cb(int socket, ssize_t length)
{
	ssize_t len = length;
	char buf[100] = {0};
	char ip[50] = {0};
	uint16 port = 0;
	QL_RET ql_ret= 0;
	
	APP_DEBUG("\r\n<-- socket receive callback, socket:%d,length:%d-->\r\n",socket,length);

	while(len>0)
	{
		ql_ret = ql_soc_recvfrom((uint16)socket,buf,sizeof(buf),ip,sizeof(ip),&port);

		if (QL_RET_OK == ql_ret)
		{
			APP_DEBUG("\r\n<-- received data from:%s:%d,%s-->\r\n",ip,port,buf);
		}
		else
		{
			APP_DEBUG("\r\n<--Error: received data fail-->\r\n");
		}
		ql_soc_remainlen((uint16)socket,(uint32*) &len);
	}
}

static void ql_socket_status_callback(int sock_num, QL_SOCKET_STATUS status, int arg)
{

    switch (status)
    {
        case QL_TCP_CONNECTED:
            APP_DEBUG("Socket %d had connected\r\n", sock_num);
            break;

        case QL_TCP_SENT:
            APP_DEBUG("Socket %d had acked %d bytes\r\n", sock_num, arg);
            break;

        case QL_TCP_RECV:
            APP_DEBUG("Socket %d had recved %d bytes\r\n", sock_num, arg);
            break;

        case QL_TCP_ERR:
            APP_DEBUG("Socket %d had closed by err %d\r\n", sock_num, arg);
            break;

        case QL_TCP_CONNECTION_CLOSED:
            APP_DEBUG("Socket %d had closed by server\r\n", sock_num);
            break;

        case QL_SOCKET_CLOSE_PASSIVE:
            APP_DEBUG("Socket %d had closed by protocol stack error\r\n", sock_num);
            break;

        case QL_SOCKET_CLOSE_PROACTIVE:
            APP_DEBUG("Socket %d had closed by user\r\n", sock_num);
            break;

        case QL_SOCKET_DATA_DROPPED:
            APP_DEBUG("Socket %d dropped %d bytes data due to cache full\r\n", sock_num, arg);
            break;

        default:
            break;
    }
}


static void ql_socket_sent_callback(int sock_num, uint8 seq_num, bool data_status)
{

    char rsp_string[QL_MAX_SENT_DATA_RSP_LEN] = {0};

    if (sock_num != 0xFF)
    {
        (void)sprintf(rsp_string, "\r\n%s%d,%d,%d", "+NSOSTR:", sock_num, seq_num, (uint8)data_status);
    }
    else
    {
        (void)sprintf(rsp_string, "\r\n%s%d,%d", "+NSOSTR:", seq_num, (uint8)data_status);
    }
	APP_DEBUG(rsp_string);
}


/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16 soc_index = 0xFFFF, autocon;
    QL_RET ql_ret  = 0;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API TCP Example -->\r\n");
    APP_DEBUG("\r\n<-- step1: create tcp -->");
    APP_DEBUG("\r\n<-- step2: tcp connect -->");
	APP_DEBUG("\r\n<-- step3: send data -->\r\n");

    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disable AUTOCONNECT network and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    ql_set_cfun(1,cfun_callback);
    ql_set_cereg_callback(cereg_callback);
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s ",uart_buf);

			if (NULL != strstr((char*)uart_buf,"create tcp"))
			{
				ql_ret = ql_soc_create(&soc_index,TCP,IPV4,NULL,0,ql_socket_recv_cb);
				if (QL_RET_OK == ql_ret)
				{
					 APP_DEBUG("\r\n<-- create tcp socket success, socket:%d -->\r\n",soc_index);
					 ql_ret = ql_soc_set_callback(soc_index,ql_socket_sent_callback,ql_socket_status_callback);
					 if(QL_RET_OK == ql_ret)
					 {
					 	APP_DEBUG("\r\n<-- set tcp status callback success, socket:%d -->\r\n",soc_index);
					 }
					 else
					 {
					 	APP_DEBUG("\r\n<-- set tcp status callback fail, socket:%d -->\r\n",soc_index);
					 }
				}
				else 
				{
					APP_DEBUG("\r\n<-- create tcp socket fail, ret:%d -->\r\n",ql_ret);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"tcp connect"))
			{
				ql_ret = ql_soc_connect(soc_index, "220.180.239.212", 8065);
				if (QL_RET_OK == ql_ret)
				{
					 APP_DEBUG("\r\n<-- connecting....... -->\r\n");
				}
				else 
				{
					APP_DEBUG("\r\n<--tcp connect fail, ret:%d -->\r\n",ql_ret);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"send data"))
			{
				static uint8 seq_num =0;
				uint32 sent_len = 0;
				char *str = "hello, I am come from tcp client!";

				sent_len = 0;
				
				ql_ret = ql_soc_send_with_ind(soc_index,seq_num++,str,strlen(str),QL_SOCMSG_NORMAL,&sent_len);
				if (QL_RET_OK == ql_ret)
				{
					APP_DEBUG("\r\n<-- sent tcp data success, lenght:%d -->\r\n",sent_len);
				}
				else 
				{
					APP_DEBUG("\r\n<-- sent tcp data fail, ret:%d -->\r\n",ql_ret);
				}
			}
            else
			{
				APP_DEBUG("\r\n<-- Error: Unknown input -->\r\n");
			}
       }
       (void)osThreadYield(); 
    }

}
#endif // __EXAMPLE_API_TCP__