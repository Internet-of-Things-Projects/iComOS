/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_pwm.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to program PWM interface in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_PWM__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Operation:
*
*     Send "pwm <cycle>,<duty>" command via uart1 to output PWM waveform on PINNAME_NETLIGHT pin.
*     eg. Send "pwm 1000,800" command via uart1 to output cycle=1KHz, duty=%80 PWM waveform on PINNAME_NETLIGHT pin.
*
* Author: Evan.Wu
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_PWM__
#include "ql_common.h"
#include "ql_system.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_gpio.h"
#include "ql_string.h"
#include "ql_io_bank.h"
#include "ql_pwm.h"
#include "example.h"

#define PWM_CHNNLNO         0
#define PWM_PINNAME         PINNAME_NETLIGHT
#define UART_QUEUE_LEN      4

static osMessageQueueId_t uart_queue = NULL;
static uint8 uart_buf[255]={0};
static uint16 buf_len=0;
static uint8 isFlag = 0;

/** Configure T=1000, Duty=50% */
static PWM_DATA_CONFIG pwm_data_config = {1000,500};
static PWM_BASE_CONFIG pwm_base_config = {1,0xff,1};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 data_len)
{
    buf_len=0;
    memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,data_len);
    buf_len=data_len;
    uart_send_to_incoming_queue_from_isr(1);
}

static QL_RET pwm_program(void)
{
    QL_RET ret;
    ret = ql_pwm_init(PWM_CHNNLNO, PWM_PINNAME);
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<---PWM init failed!,ret=%d --->\r\n",ret);
        return ret;
    }
    ret = ql_pwm_usoutput(PWM_CHNNLNO,pwm_data_config,pwm_base_config);
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<---PWM output waveform failed!,ret=%d --->\r\n",ret);
        return ret;
    }    
    return ret;
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void)unused;
    ql_uart_config uart1_config;    
    uint32 msg = 0;
    QL_RET ret = QL_RET_OK;
    
    ql_wait_for_at_init();  //wait for modem ok
    
    uart_create_queue();
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if (ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    
    if (ql_io_bank_open(IO_BANK_L1,VDD_IO_LEVEL_3V0) != QL_RET_OK )
    {
        QDEBUG_TRACE("user open IO_BANK_L1 err");
    }
    else
    {
        QDEBUG_TRACE("user open IO_BANK_L1 succe");
    }

    ql_add_stop_clocksveto();// disable A core enter to idle or sleep.
    
    ret = pwm_program();
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<-- PWM program error,ret=%d -->\r\n",ret);
    }
    else
    {
        isFlag = 1;
        APP_DEBUG("\r\n<-- PWM program succeed -->\r\n");
        APP_DEBUG("\r\n<-- PWM output waveform succeed -->\r\n");
    } 

    APP_DEBUG("\r\n<-- OpenCPU: PWM Example -->\r\n");
    APP_DEBUG("\r\n<-- cmd: pwm <cycle>,<duty> -->\r\n");
     
    for (;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            char *temp = strstr((char*)uart_buf,"pwm ");
            char *comma = strstr((char*)uart_buf,",");
            if((temp != NULL)&&((comma != NULL)))
            {   
                uint8 i=(int)(comma-temp);
                uint16 m=0;
                uint16 n=0;
                uint16 cycle[5]={0};
                uint16 duty[5]={0};
                memcpy(cycle,temp+4,i-4);
                memcpy(duty,comma+1,4); 
                m=atoi((char*)cycle);
                n=atoi((char*)duty);
                if ((m>5000)||(m<1)||(n>=1000)||(n<1))
                {
                    APP_DEBUG("\r\n<-- Input parameter invalide  -->\r\n");
                }
                else
                {
                    if (isFlag == 1)
                    {
                        ret = ql_pwm_uninit(PWM_CHNNLNO);
                        if (ret != QL_RET_OK)
                        {
                            APP_DEBUG("\r\n<-- PWM uninit failed!,ret=%d -->\r\n",ret);
                        }
                        else
                        {
                            isFlag=0;
                            ret = ql_pwm_init(PWM_CHNNLNO, PWM_PINNAME);
                            if (ret != QL_RET_OK)
                            {
                                APP_DEBUG("\r\n<-- PWM init failed!,ret=%d --->\r\n",ret);
                            }
                        }
                        
                    }
                    if (isFlag == 0)
                    {
                        pwm_data_config.period_cycles = m;
                        pwm_data_config.duty_cycle    = n;
                        
                        ret = ql_pwm_usoutput(PWM_CHNNLNO,pwm_data_config,pwm_base_config);
                        if (ret != QL_RET_OK)
                        {
                            APP_DEBUG("\r\n<-- PWM output waveform failed!,ret=%d -->\r\n",ret);
                        } 
                        else
                        {
                            isFlag = 1;
                            APP_DEBUG("\r\n<-- PWM output waveform succeed, cycle:%d,duty:%d -->\r\n",pwm_data_config.period_cycles,pwm_data_config.duty_cycle);
                        }
                    }
                }
            }
            else
            {
                APP_DEBUG("\r\n<-- Input command error, input again! -->\r\n");
            }
        }
        (void)osThreadYield();
    }
}
#endif // __EXAMPLE_PWM__