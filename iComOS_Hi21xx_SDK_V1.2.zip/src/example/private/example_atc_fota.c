/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_atc_fota.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example introduces the FOTA upgrade on the IoT platform through ATC mode and the 
*   FOTA upgrade mode is controlled by default.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_KV__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Prepare:
*     1. Prepare the delta firmware package in advance, and create a delta firmware upgrade 
*        package between the two firmware versions by making a tool for the delta firmware package.
*     2. After making the differential package file, upload the delta firmware package to the IoT platform    
*     3. Create a FoTA upgrade task on the IoT platform.
*     4. After registering the module to the IoT platform, send a packet of data to the IoT 
*        platform to trigger the FOTA upgrade.
*
*   Operation:
*     1. Input "cmd:<type>" via uart1 to execute the relevant AT commands in the "atcmd table";
*     2. Input "AT+QLWFOTAIND=<state>" via uart1 to set whether the FOTA upgrade mode is automatic 
*        mode or controlled mode. For the specific setting mode, refer to the AT manual of the 
*        corresponding module model.   
*
* Author: 
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_ATC_FOTA__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "example.h"

#if 0
#define APP_ATCDBG      APP_DEBUG
#else
#define APP_ATCDBG(x,...);     
#endif

#define UART_QUEUE_LEN                  25
#define ATCMD_TABLE_ITEM_MAX            sizeof(atcmd_table)/sizeof(AT_CMD)
#define ATRET_TABLE_ITEM_MAX            sizeof(atret_table)/sizeof(char*)
#define URC_TABLE_ITEM_MAX              sizeof(urc_handle_table)/sizeof(URC_HANDLE)

static osMessageQueueId_t uart_queue = NULL;
static uint8  uart_buf[512] = {0};
static uint16 buf_len = 0;

static void atcmd_general_result_handle(uint8 ret,uint8 err);
static void atcmd_send_timeout_handle(void);
static bool atcmd_general_process_handle(char* str);
static bool atcmd_nuestatsmem_process_handle(char* str);
static void urc_registernotify_handle(char* str);
static void urc_cereg_handle(char* str);
static void urc_evtind_handle(char* str);
static void urc_nnmi_handle(char* str);
static void urc_firmware_handle(char* str);

typedef void (*atcmd_result_fn)(uint8 ret,uint8 err);
typedef bool (*atcmd_process_fn)(char*);
typedef void (*urc_handle_fn)(char*);

typedef enum
{
    UART1_MSG = 1,
    VUART_MSG,
}MSG_TYPE;

typedef enum
{
    AT_PRO_IDLE,
    AT_PRO_WAIT_FOR_OK,
    AT_PRO_WAIT_FOR_PREFIX,
    AT_PRO_WAIT_FOR_PREFIX_CONTINUE,
    AT_PRO_WAIT_FOR_SUFFIX,
    AT_PRO_WAIT_FOR_SUFFIX_CONTINUE,
}AT_PRO_STATE;

typedef struct
{
    const char* pcmd;
    char prefix[64];
    char suffix[64];
    AT_PRO_STATE at_current;
    uint8 is_block;
    osTimerId_t timer_id;
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback; 
    char result[100];
    uint8 ret;
    uint8 err;
}AT_PROCESS;

typedef struct
{
    char* pcmd;
    uint32 timeout;
    char* pprefix;
    char* psuffix;
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
}AT_CMD;

typedef struct
{
    char* urc_str;
    urc_handle_fn urc_handle;
}URC_HANDLE;

AT_CMD atcmd_table[] = {
    {"AT+NCONFIG?",5,"+NCONFIG:AUTOCONNECT",NULL,atcmd_general_process_handle,atcmd_general_result_handle},
    {"AT+CFUN?",5,"+CFUN:",NULL,atcmd_general_process_handle,atcmd_general_result_handle},
    {"AT+CGATT?",3,"+CGATT:",NULL,atcmd_general_process_handle,atcmd_general_result_handle}, 
    {"AT+QREGSWT?",3,"+QREGSWT:",NULL,atcmd_general_process_handle,atcmd_general_result_handle}, 
    {"AT+CEREG=1",3,NULL,NULL,NULL,atcmd_general_result_handle}, 
    {"AT+CMEE=1",3,NULL,NULL,NULL,atcmd_general_result_handle}, 
    {"AT+QREGSWT=1",3,NULL,NULL,NULL,atcmd_general_result_handle},
    {"AT+CFUN=1",50,NULL,NULL,NULL,atcmd_general_result_handle}, 
    {"AT+CGATT=1",10,NULL,NULL,NULL,atcmd_general_result_handle},
    {"AT+NCDP?",10,"+NCDP:",NULL,atcmd_general_process_handle,atcmd_general_result_handle},
    {"AT+NMGS=3,ABCABC",5,NULL,NULL,NULL,atcmd_general_result_handle},
    {"AT+NCDP=180.101.147.115,5683",10,NULL,NULL,NULL,atcmd_general_result_handle},
    {"AT+NUESTATS=APPSMEM",8,"NUESTATS:APPSMEM",NULL,atcmd_nuestatsmem_process_handle,atcmd_general_result_handle},  
    {"AT+NRB",10,NULL,NULL,NULL,atcmd_general_result_handle},
};

char* atret_table[] = {
    "OK",
    "ERROR",
    "+CME ERROR:",
};

URC_HANDLE urc_handle_table[] = 
{
    {"REGISTERNOTIFY",  urc_registernotify_handle},
    {"+CEREG:",         urc_cereg_handle},
    {"+QLWEVTIND:",     urc_evtind_handle},
    {"+NNMI:",          urc_nnmi_handle},
    {"FIRMWARE",        urc_firmware_handle} ,
};

AT_PROCESS current_atcmd = {0};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf+1,buffer,len);
    buf_len = len;
    uart_buf[0] = UART1_MSG;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr((uint32)uart_buf);
}

static void vuart_recieve_handle(uint8 *buffer,uint32 len)
{
    char* p = NULL;
    uint32 i = 0,j = 0;
    p = ql_malloc(len+2);
    if (NULL == p)
    {
        APP_DEBUG("\r\n<-- Error: malloc fail, len:%d -->\r\n",len);
        return;
    }
    memset(p,0,len+1);
    for (i=0,j=0; i<len; i++)
    {
        if (('\r'==buffer[i])||('\n'==buffer[i]))
        {
            continue;
        }
        *(p+1+j) = buffer[i];
        j++;
    }
    if (0 < strlen((char* )p+1))
    {
        *p = VUART_MSG;
        uart_send_to_incoming_queue_from_isr((uint32)p);
    }
    else
    {
        ql_free(p);
    }
}

static void atcmd_send_timeout_handle(void)
{
    memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
    memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
    current_atcmd.ret = 0xff;
    current_atcmd.err = 0xff;
    current_atcmd.at_current = AT_PRO_IDLE;
    osTimerStop(current_atcmd.timer_id);
    APP_DEBUG("\r\n<-- Error: cmd %s timeout! -->\r\n",current_atcmd.pcmd);
}

static QL_RET atcmd_send(const char* atcmd, char* prefix, char* suffix, uint32 timeout, atcmd_process_fn process_callback, atcmd_result_fn result_callback)
{
    if ((NULL==atcmd)||(AT_PRO_IDLE!=current_atcmd.at_current))
    {
        return -1;
    }
    current_atcmd.pcmd = atcmd;
    if (NULL==prefix)
    {
        memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
    }
    else
    {
        strcpy(current_atcmd.prefix,prefix);
    }
    if (NULL==suffix)
    {
        memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
    }
    else
    {
        strcpy(current_atcmd.suffix,suffix);
    }
    current_atcmd.atcmd_process_callback = process_callback;
    current_atcmd.atcmd_result_callback = result_callback;
    if (QL_RET_OK != ql_uart_write(VIRTUAL_PORT,(uint8*)current_atcmd.pcmd,strlen(current_atcmd.pcmd)))
    {
        return QL_RET_ERR_UNKNOWN;
    }
    if (NULL == strstr(current_atcmd.pcmd,"\r\n"))
    {
        ql_uart_write(VIRTUAL_PORT,(uint8*)"\r\n",strlen("\r\n"));
    }
    
    if ((NULL == prefix) && (NULL == suffix))
    {
        current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
    }
    else if ((NULL != prefix) && (NULL == suffix))
    {
        current_atcmd.at_current = AT_PRO_WAIT_FOR_PREFIX;
    }
    else
    {
        current_atcmd.at_current = AT_PRO_WAIT_FOR_SUFFIX;
    }
    if (NULL == current_atcmd.timer_id)
    {
        current_atcmd.timer_id = osTimerNew((osTimerFunc_t)atcmd_send_timeout_handle,osTimerOnce,NULL,NULL);
    }
    if (0 < timeout)
    {
        osTimerStart(current_atcmd.timer_id,(int32_t)osMs2Tick((uint64_t)timeout*1000));
    } 
    return QL_RET_OK;
}

static void atcmd_result_process_handle(char * str)
{
    char* p = NULL;
    uint8 i = 0;
    if (AT_PRO_IDLE == current_atcmd.at_current)
    {
        return;
    }
    if (AT_PRO_WAIT_FOR_OK == current_atcmd.at_current)
    {
        for (i=0; i < ATRET_TABLE_ITEM_MAX; i++)
        {
            p = strstr(str,atret_table[i]);
            if ((NULL != p) && (0 == strncmp(str,atret_table[i],strlen(atret_table[i]))))
            {
                if (0 == i)
                {
                    if (osTimerIsRunning(current_atcmd.timer_id))
                    {
                        osTimerStop(current_atcmd.timer_id);
                        APP_ATCDBG("\r\n<-- Normal stop timeout timer -->\r\n");
                    } 
                }
                else
                {
                    APP_DEBUG("\r\n<-- at cmd %s process fail! -->\r\n",current_atcmd.pcmd);
                }
                if (2 == i)
                {
                    p += (strlen(atret_table[i])+1);
                    current_atcmd.err = atoi(p);
                }
                if (NULL != current_atcmd.atcmd_result_callback)
                {
                    current_atcmd.atcmd_result_callback(i,current_atcmd.err);
                }
                current_atcmd.at_current = AT_PRO_IDLE;
                break;
            }
        }
    }
    else
    {
        if (NULL != current_atcmd.atcmd_process_callback)
        {
            if (AT_PRO_WAIT_FOR_PREFIX != current_atcmd.at_current)
            {
                APP_DEBUG("\r\n<-- at cmd %s  status error! -->\r\n",current_atcmd.pcmd);
				return;
            }
            if (NULL != strstr(str,":"))
            {
                current_atcmd.atcmd_process_callback(str);
            }
            else
			{
				APP_ATCDBG("\r\n<-- unexpected return value: %s -->\r\n",str);
			}
        }
        else
        {
            APP_ATCDBG("\r\n<-- no callback function found -->\r\n");
        }
    }
}

static void urc_process_handle(char* str)
{
    uint8 i = 0;
    char* p = NULL;
    for (i=0; i < URC_TABLE_ITEM_MAX; i++)
    {
        p = strstr(str,urc_handle_table[i].urc_str);
        if (NULL != p)
        {
            urc_handle_table[i].urc_handle(str);
            break;
        }
    }
}

static void urc_cereg_handle(char* str)
{
    uint8 status = atoi(str+7);
    APP_DEBUG("\r\n<-- urc/cereg:%s,%d -->\r\n",str,status);
    if (1 == status)
    {
        APP_DEBUG("\r\n<-- has attached network -->\r\n");
    }
}

static void urc_evtind_handle(char* str)
{
    char* p = str;
    APP_DEBUG("\r\n<-- urc/evtind:%s -->\r\n",str);
    p += 11;
    if ('3' == *p)
    {
        if (QL_RET_OK == atcmd_send("AT+QLWFOTAIND=1",NULL,NULL,3,NULL,atcmd_general_result_handle))
        {
            APP_ATCDBG("\r\n<-- atcmd sent : AT+QLWFOTAIND=1 succe -->\r\n");
        }
    }
    else if ('6' == *p)
    {
        APP_DEBUG("\r\n<-- Please input AT+QLWFOTAIND=2 start downloading -->\r\n");
    }
    else if ('7' == *p)
    {
        APP_DEBUG("\r\n<-- Please input AT+QLWFOTAIND=4 start update -->\r\n");
    }
}

static void urc_registernotify_handle(char* str)
{
    UNUSED(str);
	APP_DEBUG("\r\n<-- urc/registernotify:%s -->\r\n",str);
}

static void urc_nnmi_handle(char* str)
{
    UNUSED(str);
	APP_DEBUG("\r\n<-- urc/nnmi:%s -->\r\n",str);
}

static void urc_firmware_handle(char* str)
{
    UNUSED(str);
	APP_DEBUG("\r\n<-- urc/firmware:%s -->\r\n",str);
}

static void atcmd_general_result_handle(uint8 ret,uint8 err)
{
    if (2 > ret)
    {
        APP_DEBUG("\r\n<-- at cmd:%s return:%s -->\r\n", current_atcmd.pcmd,atret_table[ret]);
    }
    else
    {
        APP_DEBUG("\r\n<-- at cmd:%s return error code, %s:%d -->\r\n", current_atcmd.pcmd,atret_table[ret],err);
    }
}

static bool atcmd_general_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	if (NULL != p)
	{
        APP_DEBUG("\r\n<-- atcmd/process:%s -->\r\n",p);
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
    else
    {
        APP_DEBUG("\r\n<-- Some error: atcmd/process:%s -->\r\n",str);
    }
	return true;
}

static bool atcmd_nuestatsmem_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	static uint8 i = 0;
	p = strstr(str,current_atcmd.prefix);
	if (NULL != p)
	{
        APP_DEBUG("\r\n<-- atcmd/process:%s -->\r\n",p);
        if (++i == 5)
        {
            current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
        }
		return false;
	}
    else
    {
        APP_DEBUG("\r\n<-- Some error: atcmd/process:%s -->\r\n",str);
    }
	return true;
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void)unused;    
    ql_uart_config uart1_config;
    uint32 msg = 0;
    uint8 i = 0;
    QL_RET ret;
    
    ql_wait_for_at_init();  //wait for modem ok  
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 

    if(ql_uart_init(VIRTUAL_PORT) != QL_RET_OK)
    {
        QDEBUG_TRACE("vuart port init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if(QL_RET_OK !=  ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle))
    {
        QDEBUG_TRACE("uart port1 init error");
    }

    enable_virtual_port();
    if (QL_RET_OK != ql_uart_open(VIRTUAL_PORT, &uart1_config, vuart_recieve_handle))
    {
        QDEBUG_TRACE("vuart port init error");
    }

    
    APP_DEBUG("\r\n<-- OpenCPU: ATC FOTA Example -->\r\n");
    for (i = 0; i < ATCMD_TABLE_ITEM_MAX; i++)
	{
		APP_DEBUG("<-- command: cmd:%d %s -->\r\n",i,atcmd_table[i].pcmd);
	}
    APP_DEBUG("\r\n<-- Execute Command: cmd:0~%d-->",ATCMD_TABLE_ITEM_MAX-1);
    APP_DEBUG("\r\n<-- Execute Command: AT+QLWFOTAIND=<state> -->\r\n");
    for(;;)
    {
       if(osMessageQueueGet(uart_queue,(void*)&msg, NULL, osWaitForever) == osOK)
       {
            uint8* pmsg = (uint8*)msg;
			switch (*pmsg)
			{
                case UART1_MSG:
                {
                    APP_DEBUG("\r\n>>>>input: %s",++msg);
                    char* p = NULL;
                    uint8 cmd = 0xff;
                    if (NULL != strstr((char*)pmsg,"cmd:"))
                    {
                        p = strstr((char*)pmsg,"cmd:");
                        p += 4;
                        cmd = atoi(p);
                        
                        if ((0 == cmd) && ('0' != *p))
                        {
                            APP_DEBUG("\r\n<-- Error: unknown input cmd -->\r\n");
                            break;
                        }
                        if ((NULL != p) && (cmd < ATCMD_TABLE_ITEM_MAX))
                        {
                            ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,\
                                atcmd_table[cmd].timeout,atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
                            APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
                        }
                        else
                        {
                            APP_DEBUG("\r\n<-- at cmd don't find -->\r\n");
                        }
                        break;
                    }
                    else if (NULL != strstr((char*)pmsg,"AT+QLWFOTAIND="))
                    {
                        char pcmd[20]  = {0};
                        p = strstr((char*)pmsg,"AT+QLWFOTAIND=");
                        p += 14;
                        cmd = atoi(p);
                        if (((0 == cmd) && ('0' != *p)) || (cmd > 5))
                        {
                            APP_DEBUG("\r\n<-- Error: unknown input at cmd -->\r\n");
                            break;
                        }
                        memcpy(pcmd,pmsg,strlen((char*)pmsg)-strlen("\r\n"));
                        ret = atcmd_send(pcmd,NULL,NULL,5,NULL,atcmd_general_result_handle);
                        APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",pcmd,ret);
                    } 
                    else
                    {
                        APP_DEBUG("\r\n<-- Error: unknown input -->\r\n");
                        break;
                    }
                }
                case VUART_MSG:
                {
                    pmsg++;
                    APP_ATCDBG("\r\n<-- process handle string:%s -->\r\n",pmsg);
                    atcmd_result_process_handle((char*)pmsg);
                    if (AT_PRO_IDLE == current_atcmd.at_current)
                    {
                        urc_process_handle((char*)pmsg);
                    }
                    pmsg = (uint8*)msg;
                    ql_free(pmsg);
                    break;
                }
                 default:
                    APP_DEBUG("\r\n<-- Error: unknown msg type,type:%d  -->\r\n",*pmsg);
                    break;
            }
       }
       (void)osThreadYield();       
    }
}
#endif // __EXAMPLE_ATC_FOTA__
