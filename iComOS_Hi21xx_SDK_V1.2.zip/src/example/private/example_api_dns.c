/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_dns.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use DNS API functions communication in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_DNS__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "set dns: xx.xx.xx.xx" conmand via uart1 to set DNS domain name server address and related parameter.
*     2.Input "get dns"              conmand via uart1 to get DNS domain name server address and related parameter. 
*     3.Input "url: www.xxxxx.com"   conmand via uart1 to set need domain name resolution address.
*     4.Input "clear: www.xxxxx.com" conmand via uart1 to clear the saved domain name resolution address.
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_DNS__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "ql_dns.h"
#include "example.h"

#define DNS_MAXATTEMPTS     2
#define DNS_WAIT_TIMEOUT    30  //s

#define UART_QUEUE_LEN      3

const uint32 UART_QUEUE_ITEM_SIZE = 4;

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}

static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void dns_parse_callback(char* ip)
{
	APP_DEBUG("\r\n<-- dns parse callback:%s-->\r\n",ip);
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16 autocon;
    QL_RET ql_ret  = 0;
    char * p = NULL;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API DNS Example -->");
    APP_DEBUG("\r\n<-- execute cmd: set dns server:<ip address1>,<ip address2>,<attempts times>,<timeout> -->");
    APP_DEBUG("\r\n<-- execute cmd: get dns server -->");
    APP_DEBUG("\r\n<-- execute cmd: url:<www.xxxxx.com> -->");
    APP_DEBUG("\r\n<-- execute cmd: clear:<www.xxxxx.com> -->\r\n");

    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disable AUTOCONNECT network and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    ql_set_cfun(1,cfun_callback);
    ql_set_cereg_callback(cereg_callback);
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s ",uart_buf);

			if (NULL != (p = strstr((char*)uart_buf,"set dns server:")))
			{
				char dns_ip[2][100] = {{0},{0}};
				uint8 max_attempts  = 0;
				uint32 wait_timeout = 0;
				int str_index = 0;
				char a[10] = {0};
				
				p += strlen("set dns server:");

				/***** get dns1,Note: separated by ","******/
				str_index = ql_util_strindex(p,",");
				if (str_index < 0)
				{
					APP_DEBUG("\r\n<-- Error: get dns1 error! continue! -->\r\n");
					continue;
				}
				memcpy(dns_ip[0],p,str_index);
				p += str_index+1;
				
				/***** get dns2,Note: separated by ","******/
				str_index = ql_util_strindex(p,",");
				if (str_index < 0)
				{
					APP_DEBUG("\r\n<-- Error: get dns2 error! continue! -->\r\n");
					continue;
				}
				memcpy(dns_ip[1],p,str_index);
				p += str_index+1;
				
                /***** get max attempts,Note: separated by ","******/
				str_index = ql_util_strindex(p,",");
				if (str_index < 0)
				{
					APP_DEBUG("\r\n<-- Error: get max attempts error! continue! -->\r\n");
					continue;
				}
				memcpy(a,p,str_index);
				max_attempts = atoi(a);
				p += str_index+1;
				memset(a,0,sizeof(a));

                /***** get wait timeout, Note:there is no ","******/
				memcpy(a,p,strlen(p));
				wait_timeout = atoi(a);				

				APP_DEBUG("\r\n<-- set dns server ip:%s--%s--%d--%d -->\r\n",dns_ip[0],dns_ip[1],max_attempts,wait_timeout);

				ql_dns_set_config(max_attempts,wait_timeout);
				
				ql_ret = ql_dns_set_server_addr(dns_ip[0],dns_ip[1]);
				
			}
			else if (NULL != strstr((char*)uart_buf,"get dns server"))
			{
				char dns_ip[2][100] = {{0},{0}};
				uint8 max_attempts;
				uint32 wait_timeout;
				
				ql_ret = ql_dns_get_server_addr(dns_ip[0],dns_ip[1]);
				if (strlen(dns_ip[0]))
				{
					APP_DEBUG("\r\n<-- get dns server ip:%s -->\r\n",dns_ip[0]);
				}
				if (strlen(dns_ip[1]))
				{
					APP_DEBUG("\r\n<-- get dns server ip:%s -->\r\n",dns_ip[1]);
				}
				
				ql_dns_get_config(&max_attempts,&wait_timeout);
				APP_DEBUG("\r\n<-- get dns config,attempts:%d, timeout:%d -->\r\n",max_attempts,wait_timeout);
			}
			else if (NULL != (p = strstr((char*)uart_buf,"url:")))
			{
				char* ptmp = NULL;
				
				ptmp = strstr((char*)p,"\r");
				if (NULL != ptmp)
				{
					*ptmp = '\0';
				}
				p += strlen("url:");
				APP_DEBUG("\r\n<-- parse hostname:%s-->\r\n",p);
				ql_ret = ql_dns_parse_hostname(DNS_MODE_RESOLVE,p,dns_parse_callback);
			}
			else if (NULL != (p = strstr((char*)uart_buf,"clear:")))
			{
				char* ptmp = NULL;
				
				ptmp = strstr((char*)p,"\r");
				if (NULL != ptmp)
				{
					*ptmp = '\0';
				}
				p += strlen("clear:");
				APP_DEBUG("\r\n<-- clear hostname:%s-->\r\n",p);
				ql_ret = ql_dns_parse_hostname(DNS_MODE_DELETE,p,dns_parse_callback);
			}
			else
			{
				APP_DEBUG("\r\n<-- unknown input-->\r\n");
				ql_ret = QL_RET_ERR_PARAM;
			}
			APP_DEBUG("\r\n<-- api dns example return:%d -->\r\n",ql_ret);
       }
       (void)osThreadYield(); 
    }

}
#endif // __EXAMPLE_API_DNS__