/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_onenet.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use API function communication with OneNET platform in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_ONENET__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "ont attach"  conmand via uart1 to attach network. 
*     2.Input "ont init"  conmand via uart1 to initialize program. 
*     3.Input "ont connect" conmand via uart1 to start registraion process. 
*     4.Input "ont send NON:<data>" conmand via uart1 to send the non-confirmable(NON) data to the OneNET platform.
*     5.Input "ont send CON:<data>"     conmand via uart1 to send the confirmable(CON) data to the OneNET platform
*     6.Input "ont update"  conmand via uart1 to send update request the OneNET platform. 
*     7.Input "ont disconnect" conmand via uart1 to deregister to the OneNET platform. 
*
*     The program only support object 3303, all data will be sent on 3303/0/5701.
*     Support Read(3303/0/5700),Write,Execute,Observe and Write-Attribute operations.
* Author: Gary.Tang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_ONENET__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "ql_onenet_api.h"
#include "example.h"

#define UART_QUEUE_LEN        3
#define UART_QUEUE_ITEM_SIZE  4

static QL_ONENET_INIT_PARAMS onenet_init_params = {
    false,
    5683,
	"183.230.40.40",
	3,
	true, //auto ack observe
	QL_WRITE_FORMAT_HEXSTRING,
};

QL_ONT_CALLBACK ont_callback = {0};
static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255] = {0};
static uint16 buf_len = 0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, UART_QUEUE_ITEM_SIZE, NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void ont_read_callback(QL_ONT_URI* uri,uint32 mid)
{
    APP_DEBUG("\r\n<-- ont read cb:%d/%d/%d,msgid:%d -->\r\n",uri->objectId,uri->instanceId,uri->resourceId,mid);
    if((QL_URI_IS_SET_RESOURCE(uri) && (uri->resourceId == 5700)&& (uri->objectId == 3303)) ||(!QL_URI_IS_SET_RESOURCE(uri) &&  (uri->objectId == 3303)))
    {
        QL_ONT_URI read_uri;
        ql_onenet_uri_make(3303,0,5700,&read_uri);
        QL_ONT_DATA senddata = {0};
        
        senddata.id = 0;
        senddata.type = data_type_float;
        senddata.value.asFloat =  8.13;
        if(QL_RET_OK != ql_onenet_read_response((QL_ONT_URI*)&read_uri,(QL_ONT_DATA*)&senddata,mid,QL_ONT_COAP_205_CONTENT,0))
        {
            QDEBUG_TRACE("ont send non err\r\n");
        }
    }
}

static void ont_write_callback(QL_ONT_URI* uri,const QL_ONT_DATA* value,uint16 attrcount,uint32 mid)
{
    char recvstr[256] = {0};
    APP_DEBUG("\r\n<-- ont write cb:%d/%d/%d,msgid:%d,count:%d -->\r\n",uri->objectId,uri->instanceId,uri->resourceId,mid,attrcount);
    if(NULL !=  value)
    {
        for(uint16 i = 0;i < attrcount; i++)
        {
            if((data_type_string == value[i].type) ||(data_type_opaque == value[i].type))
            {
                if(NULL != value[i].asBuffer.buffer)
                {
                    memset(recvstr,0,256);
                    memcpy(recvstr,value[i].asBuffer.buffer,value[i].asBuffer.length);
                    APP_DEBUG("\r\n<-- Write Recv:%s -->\r\n",recvstr);
                }
            }
        }
    }
    
    if(QL_RET_OK != ql_onenet_write_response(mid,QL_ONT_COAP_204_CHANGED,0))
    {
        APP_DEBUG("\r\n<-- error: write rsp -->\r\n");
    }
}

static void ont_exe_callback(QL_ONT_URI* uri,const uint8* buffer,uint32 length,uint32 mid)
{
    APP_DEBUG("\r\n<-- ont exe cb:%d/%d/%d,msgid:%d -->\r\n",uri->objectId,uri->instanceId,uri->resourceId,mid);
    if(NULL != buffer)
    {
        char exerecv[256];
        memset(exerecv,0,256);
        memcpy(exerecv,buffer,length);
        APP_DEBUG("\r\n<-- Execute Recv %d:%s -->\r\n",length,exerecv);
    }

    if(QL_RET_OK != ql_onenet_execute_response(mid,QL_ONT_COAP_204_CHANGED,0))
    {
        APP_DEBUG("\r\n<-- error: exe rsp -->\r\n");
    }
}

static void ont_observe_callback(QL_ONT_URI* uri,bool flag,uint32 mid)
{
    APP_DEBUG("\r\n<-- ont observe cb:%d/%d/%d,flag:%d,msgid:%d -->\r\n",uri->objectId,uri->instanceId,uri->resourceId,flag?1:0,mid);
    if(QL_RET_OK != ql_onenet_observe_response(mid,QL_ONT_COAP_205_CONTENT,0))
    {
        APP_DEBUG("\r\n<-- error: exe rsp -->\r\n");
    }
}

static void ont_setparam_callback(QL_ONT_URI* uri,const uint8* buffer,uint32 length,uint32 mid)
{
    APP_DEBUG("\r\n<-- ont setParam cb:%d/%d/%d,,msgid:%d -->\r\n",uri->objectId,uri->instanceId,uri->resourceId,mid);
    if(NULL != buffer)
    {
        char setrecv[256];
        memset(setrecv,0,256);
        memcpy(setrecv,buffer,length);
        APP_DEBUG("\r\n<-- SetParam Recv %d:%s -->\r\n",length,setrecv);
    }

    if(QL_RET_OK != ql_onenet_observe_param_response(mid,QL_ONT_COAP_204_CHANGED,0))
    {
        APP_DEBUG("\r\n<-- error: setParam rsp -->\r\n");
    }
}

static void ont_discover_callback(uint16 objectId,uint32 mid)
{
    APP_DEBUG("\r\n<-- ont discover cb:%d,msgid:%d -->\r\n",objectId,mid);
    uint16 res[2] = {5700,5701};
     if(QL_RET_OK != ql_onenet_discover_response(mid,2,res,QL_ONT_COAP_205_CONTENT,0))
     {
        APP_DEBUG("\r\n<-- ont discover rsp fail -->\r\n");
     }
}

static void ont_event_callback(QL_ONT_EVT id,uint16 ackid,uint32 mid,void* param)
{
    if(NULL == param)
    {
        APP_DEBUG("\r\n<-- ont event cb:evt:%d,ackid:%d,msgid:%d -->\r\n",id,ackid,mid);
    }
    else
    {
        APP_DEBUG("\r\n<-- ont event cb:evt:%d,ackid:%d,msgid:%d,param:%s -->\r\n",id,ackid,mid,param);
    }
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16  autocon;
    char * p = NULL;
    QL_RET ql_ret  = 0;
    char ont_version[QL_ONT_VERSION_SIZE] = {0};
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }

    if(QL_RET_OK != ql_onenet_get_version(ont_version,QL_ONT_VERSION_SIZE))
    {
        QDEBUG_TRACE("get version err\r\n");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API OneNET Example -->");
    APP_DEBUG("\r\n<-- OpenCPU: OneNET version:%s-->",ont_version);
    APP_DEBUG("\r\n<-- step1: ont attach -->");
    APP_DEBUG("\r\n<-- step2: ont init -->");
    APP_DEBUG("\r\n<-- step3: ont connect -->");
    APP_DEBUG("\r\n<-- step4: ont send NON:xxx -->");
    APP_DEBUG("\r\n<-- step5: ont send CON:xxx -->");
    APP_DEBUG("\r\n<-- step6: ont update -->");
    APP_DEBUG("\r\n<-- step7: ont disconnect -->");
    
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disenable AUTOCONNECT and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s \r\n",uart_buf);

			if (NULL != strstr((char*)uart_buf,"ont attach"))
			{
				ql_set_cfun(1,cfun_callback);
				ql_set_cereg_callback(cereg_callback);
			}
			else if (NULL != strstr((char*)uart_buf,"ont init"))
			{
				p += (strlen("ont init:")+1);
				
				ql_ret = ql_onenet_init(&onenet_init_params);
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont init err\r\n");
                }
                if(QL_RET_OK != ql_onenet_addobj(3303,2,"11",4,2))
                {
                    QDEBUG_TRACE("ont addobj err\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"ont connect"))
			{
				p += (strlen("ont connect:")+1);

				ont_callback.ql_Read  = ont_read_callback;
                ont_callback.ql_Write = ont_write_callback;
                ont_callback.ql_Exec  = ont_exe_callback;
                ont_callback.ql_Observe = ont_observe_callback;
                ont_callback.ql_Discover = ont_discover_callback;
                ont_callback.ql_SetParams = ont_setparam_callback;
                ont_callback.ql_Event = ont_event_callback;
				ql_ret = ql_onenet_connect(86400,60,ont_callback);
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont connect err\r\n");
                }
			}
			else if (NULL != strstr((char*)uart_buf,"ont send NON:"))
			{
				p = (char *)uart_buf;
				p += strlen("ont send NON:");
                QL_ONT_URI uri;
                ql_onenet_uri_make(3303,0,5701,&uri);
                QL_ONT_DATA senddata = {0};
                
                senddata.id = 0;
                senddata.type = data_type_string;
                senddata.asBuffer.buffer =  (uint8 *)p;
                senddata.asBuffer.length = strlen(p);
                QDEBUG_TRACE("ont prepare send non:len%d,%s\r\n",senddata.asBuffer.length,p);
				ql_ret = ql_onenet_notify(&uri,&senddata,QL_ONT_COAP_205_CONTENT,0,0);
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont send non err\r\n");
                }
			}
			else if (NULL != strstr((char*)uart_buf,"ont send CON:"))
			{
				p = (char *)uart_buf;
				p += strlen("ont send CON:");

				QL_ONT_URI uri;
                ql_onenet_uri_make(3303,0,5701,&uri);
                QL_ONT_DATA senddata = {0};
                
                senddata.id = 0;
                senddata.type = data_type_string;
                senddata.asBuffer.buffer = (uint8 *)p;
                senddata.asBuffer.length = strlen(p);
                static uint32 ackid = 1;
                QDEBUG_TRACE("ont prepare send non:len%d,%s\r\n",senddata.asBuffer.length,p);
				ql_ret = ql_onenet_notify(&uri,&senddata,QL_ONT_COAP_205_CONTENT,ackid++,0);
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont send con err\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"ont update"))
			{
				p += strlen("ont update");

				ql_ret = ql_onenet_update(9600,false,0);
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont update err\r\n");
                }
			}
			else if (NULL != strstr((char*)uart_buf,"ont disconnect"))
			{
				ql_ret = ql_onenet_disconnect();
                if(QL_RET_OK != ql_ret)
                {
                    QDEBUG_TRACE("ont update err\r\n");
                }
			}
			else
			{
				APP_DEBUG("\r\n<-- unknown input-->\r\n");
				ql_ret = QL_RET_ERR_PARAM;
			}
			APP_DEBUG("\r\n<-- api onenet example return:%d -->\r\n",ql_ret);

       }
       (void)osThreadYield(); 
    }
}
#endif // __EXAMPLE_API_ONENET__