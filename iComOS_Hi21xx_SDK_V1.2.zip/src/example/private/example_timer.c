/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_timer.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to program TIMER interface in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_TIMER__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Operation:
*
*     Input "cmd:add timer:<val(ms)>" via uart1 to added a timer.
*     Input "cmd:stop timer"          via uart1 to stop a timer.
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_TIMER__
#include "ql_common.h"
#include "ql_system.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_timer.h"
#include "ql_string.h"
#include "example.h"

#define UART_QUEUE_LEN      4

static osMessageQueueId_t uart_queue = NULL;
static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 data_len)
{
    buf_len=0;
    memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,data_len);
    buf_len=data_len;
    uart_send_to_incoming_queue_from_isr(1);
}

static void ql_timer_handle(void)
{
	APP_DEBUG("<--timer timeout handle -->\r\n");
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void)unused;
    ql_uart_config uart1_config;    
    uint32 msg = 0;
    QL_RET ql_ret = QL_RET_OK;
    uint8* timer_id = NULL;
    char * p = NULL;
    
    ql_wait_for_at_init();  //wait for modem ok
    
    uart_create_queue();
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if (ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }

    ql_add_stop_clocksveto();// disable A core enter to idle or sleep.
    
  
    APP_DEBUG("<-- OpenCPU: Timer Example -->\r\n");
    APP_DEBUG("<-- cmd:add timer:<val(ms)> -->\r\n");
	APP_DEBUG("<-- cmd:stop timer -->\r\n");
     
    for (;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            APP_DEBUG("\r\n>>>>input: %s ",uart_buf);
            p = (char*)uart_buf;

			if (NULL != strstr((char*)uart_buf,"add timer"))
			{
				int callback_delay = 0;
				char  buf[64]= {0};

				p += strlen("add timer:");

				if (ql_util_get_substring_split_by_comma(p,1,buf,sizeof(buf))>0)
				{
				   callback_delay = atoi(buf);
                   if (callback_delay <= 0)
                   {
                        APP_DEBUG("<-- input timer value error !!-->\r\n");
                        continue;
                   }
				}
				APP_DEBUG("<-- add timer,delay:%d ms -->\r\n",callback_delay);

				timer_id = ql_timer_addms(callback_delay,ql_timer_handle,QL_TIMER_FLAG_PERMANENT);
				if (NULL != timer_id)
				{
					 APP_DEBUG("<-- register timer success, timer id:0x%08X -->\r\n",timer_id);
				}
				else 
				{
					APP_DEBUG("<--Error: register timer fail -->\r\n");
				}
			}
			else if (NULL != strstr((char*)uart_buf,"stop timer"))
			{
				ql_ret = ql_timer_stop(timer_id);
				if (QL_RET_OK == ql_ret)
				{
					 APP_DEBUG("<-- stop timer success, timer id:0x%08X -->\r\n",timer_id);
				}
				else 
				{
					APP_DEBUG("<--Error: stop timer fail, ret:%d -->\r\n",ql_ret);
				}
			}
			else
			{
				APP_DEBUG("<-- unknown input-->\r\n");
			}
       }
        (void)osThreadYield();
    }
}
#endif // __EXAMPLE_TIMER__
