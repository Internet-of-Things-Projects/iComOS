/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_mqtt.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use API function communication with OneNET platform in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_ONENET__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "mqtt config"      conmand via uart1 to configure Aliauth parameters of MQTT. 
*     2.Input "mqtt init"        conmand via uart1 to initialize MQTT function and open a network for MQTT client. 
*     3.Input "mqtt connect"     conmand via uart1 to start connect a client to MQTT server. 
*     4.Input "mqtt subscribe"   conmand via uart1 to subscribe to topics.
*     5.Input "mqtt publish"     conmand via uart1 to publish messages.
*     6.Input "mqtt disconnect"  conmand via uart1 to disconnect a client from MQTT server. 
*     7.Input "mqtt unsubscribe" conmand via uart1 to unsubscribe from topics. 
*
* Author: 
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_MQTT__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "ql_mqtt_api.h"
#include "example.h"

#define UART_QUEUE_LEN          3
#define UART_QUEUE_ITEM_SIZE    4

#define TCPIDX                  0
#define PKTID                   1
#define TOPIC_MAX_LEN           35


static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255] = {0};
static uint16 buf_len = 0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, UART_QUEUE_ITEM_SIZE, NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}

static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void mqtt_open_callback(int8 tcpidx, int8 result)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt open:%d,%d -->\r\n",tcpidx,result);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt open -->\r\n");
    }
}

static void mqtt_conn_callback(int8 tcpidx, int8  result, int8 ret_code)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt connect:%d,%d,%d -->\r\n",tcpidx,result,ret_code);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt connect -->\r\n");
    }
}

static void mqtt_sub_callback(int8 tcpidx, uint16 msgID, int8 result, uint8 value)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt subcribe:%d,%d,%d,%d -->\r\n",tcpidx,msgID,result,value);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt subcribe -->\r\n");
    }      
}

static void mqtt_pub_callback(int8 tcpidx, uint16 msgID, int8 result, uint8 value)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt publish:%d,%d,%d,%d -->\r\n",tcpidx,msgID,result,value);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt publish -->\r\n");
    }      
}

static void mqtt_recv_callback(int8 tcpidx, uint16 msgID, uint8 *topic, uint8 *recv_payload)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt receive:%d,%d,%s,%s -->\r\n",tcpidx,msgID,topic,recv_payload);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt receive -->\r\n");
    }      
}

static void mqtt_stat_callback(int8 tcpidx, uint8 err_code)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt state:%d,%d -->\r\n",tcpidx,err_code);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt state -->\r\n");
    }     
}

static void mqtt_close_callback(int8 tcpidx, int8 result)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt close:%d,%d -->\r\n",tcpidx,result);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt close -->\r\n");
    }     
}

static void mqtt_disc_callback(int8 tcpidx, int8 result)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt disconnect:%d,%d -->\r\n",tcpidx,result);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt disconnect -->\r\n");
    }      
}

static void mqtt_uns_callback(int8 tcpidx, uint16 msgID, int8 result)
{
    if (0 == tcpidx)
    {
        APP_DEBUG("\r\n<-- mqtt unsubscribe:%d,%d,%d -->\r\n",tcpidx,msgID,result);
    }
    else
    {
        APP_DEBUG("\r\n<-- error: mqtt unsubscribe -->\r\n");
    }      
}
/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void) unused;
    ql_uart_config uart1_config;    
    uint32 msg = 0;
    uint16  autocon;
    char * p = NULL;
    QL_RET ql_ret = 0;
    QL_MQTT_CFG mqtt_cfg;
    uint8  clientid[QL_MQTT_CLIENT_MAX_LEN+1];
    uint8  topic[QL_MTCFG_TOPIC_MAX_LEN+1];
    
    memset(&mqtt_cfg,0,sizeof(QL_MQTT_CFG));
    mqtt_cfg.aliauth.tcpidx = TCPIDX;
    strcpy((char*)mqtt_cfg.aliauth.aliauth_type, "aliauth");
    strcpy((char*)mqtt_cfg.aliauth.prod_key,"a1YNcZ1UvqN");
    strcpy((char*)mqtt_cfg.aliauth.dev_name, "BC28_TEST");
    strcpy((char*)mqtt_cfg.aliauth.dev_secret, "Z5iwwzVmslLWhOwU9X4ZfcR8GrRUuyEc"); 

    memset(topic,0,QL_MTCFG_TOPIC_MAX_LEN);
    memcpy(topic,"/a1YNcZ1UvqN/BC28_TEST/user/update",strlen("/a1YNcZ1UvqN/BC28_TEST/user/update"));
    
    QL_MQTT_LINK_CONFIG mqtt_link_cfg = {   0,
                                            1883,
                                            "116.211.167.65",};
    QL_MQTT_CALLBACK mqtt_callback;
      
    osDelay(3000);
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user port1 open error");
    }
    
    
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disable AUTOCONNECT and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }

	ql_set_cfun(1,cfun_callback);
	ql_set_cereg_callback(cereg_callback);

    osDelay(5000);
    
    APP_DEBUG("\r\n<-- OpenCPU: API MQTT Example -->");
    APP_DEBUG("\r\n<-- step1: mqtt config -->");
    APP_DEBUG("\r\n<-- step2: mqtt init -->");
    APP_DEBUG("\r\n<-- step3: mqtt connect -->");
    APP_DEBUG("\r\n<-- step4: mqtt subscribe -->");
    APP_DEBUG("\r\n<-- step5: mqtt publish -->");
    APP_DEBUG("\r\n<-- step6: mqtt disconnect -->");
    APP_DEBUG("\r\n<-- step7: mqtt unsubscribe -->\r\n");
    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s",uart_buf);
            
            if (NULL != strstr((char*)uart_buf,"mqtt config"))
			{
				ql_ret = ql_mqtt_set_config(&mqtt_cfg);
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt set config succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt set config error,ret:%d -->\r\n",ql_ret);
                }
			}
			else if (NULL != strstr((char*)uart_buf,"mqtt init"))
			{
				p += (strlen("mqtt init:")+1);
				
				ql_ret = ql_mqtt_init();
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt init succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt init error -->\r\n");
                }

                osDelay(1000);
                memset(&mqtt_callback,0,sizeof(QL_MQTT_CALLBACK));
                
                mqtt_callback.ql_mqtt_open_callback = mqtt_open_callback;
                mqtt_callback.ql_mqtt_conn_callback = mqtt_conn_callback;
                mqtt_callback.ql_mqtt_sub_callback = mqtt_sub_callback;
                mqtt_callback.ql_mqtt_pub_callback = mqtt_pub_callback;
                mqtt_callback.ql_mqtt_recv_callback = mqtt_recv_callback;
                mqtt_callback.ql_mqtt_stat_callback = mqtt_stat_callback;
                mqtt_callback.ql_mqtt_close_callback = mqtt_close_callback;
                mqtt_callback.ql_mqtt_disc_callback = mqtt_disc_callback;
                mqtt_callback.ql_mqtt_uns_callback = mqtt_uns_callback;
                
                if(QL_RET_OK == ql_mqtt_open(&mqtt_link_cfg, mqtt_callback))
                {
                    APP_DEBUG("\r\n<-- mqtt open succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt open error,ret:%d -->\r\n",ql_ret);
                }
                
			}
            else if (NULL != strstr((char*)uart_buf,"mqtt connect"))
			{          
                memset(clientid,0,sizeof(clientid));
                memcpy(clientid,"clientExample",strlen("clientExample"));
                //APP_COAP_ERROR("Evan:%s,",clientid,strlen("clientExample"),sizeof(clientid));
                ql_ret = ql_mqtt_connect(TCPIDX, clientid,NULL,NULL);
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt connect succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt connect error,ret:%d -->\r\n",ql_ret);
                }
			}
			else if (NULL != strstr((char*)uart_buf,"mqtt subscribe"))
			{
				ql_ret = ql_mqtt_subscribe(TCPIDX,PKTID,topic,1);
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt sub succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt sub error,ret:%d -->\r\n",ql_ret);
                }
			}
			else if (NULL != strstr((char*)uart_buf,"mqtt publish"))
			{
                uint8 send_payload[25];
                
                memset(send_payload,0,sizeof(send_payload));
                memcpy(send_payload,"This is test example",strlen("This is test example"));
                
				ql_ret = ql_mqtt_publish(TCPIDX,PKTID,1,0,topic,send_payload,(uint16)strlen((char*)send_payload));
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt pub succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt pub error,ret:%d -->\r\n",ql_ret);
                }
			}
            else if (NULL != strstr((char*)uart_buf,"mqtt disconnect"))
			{
				ql_ret = ql_mqtt_disconnect(TCPIDX);
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt disconnect succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt disconnect error,ret:%d -->\r\n",ql_ret);
                }
			}
            else if (NULL != strstr((char*)uart_buf,"mqtt unsubscribe"))
			{
				ql_ret = ql_mqtt_unsubscribe(TCPIDX,PKTID,topic);
                if(QL_RET_OK == ql_ret)
                {
                    APP_DEBUG("\r\n<-- mqtt unsubscribe succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- mqtt unsubscribe error,ret:%d -->\r\n",ql_ret);
                }
			}
			else
			{
				APP_DEBUG("\r\n<-- unknown input-->\r\n");
			}
       }
       (void)osThreadYield(); 
    }
}
#endif // __EXAMPLE_API_MQTT__