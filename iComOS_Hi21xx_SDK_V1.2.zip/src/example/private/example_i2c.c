/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_i2c.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral equipment using I2C interface 
*   in OpenCPU.In this example ,we use the I2C(EEPROM:AT24C02)serials chip;you can direct use this example
*   to read , write AT24C02;
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_I2C__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "write <data>" via uart1 to write the <data> to AT24C02, data is less than 247 characters. 
*     2.Input "read"           via uart1 to read the data you write from AT24C02. 
*
* Author: Evan.Wu
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_I2C__
#include "ql_common.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_gpio.h"
#include "ql_string.h"
#include "ql_io_bank.h"
#include "ql_i2c.h"
#include "example.h"


/****** slave device:  AT24C02 **********/
/****** slave address: 0x50 *************/
#define I2C_SLAVE_ADDR          0x50
#define I2C_CHNNLNO             0
#define I2C_WRITE_CMD           0x301
#define I2C_READ_CMD            0x302

#define UART_QUEUE_LEN  5
static osMessageQueueId_t uart_queue = NULL;
static uint8 uart_buf[255]={0};
static uint16 buf_len=0;
static uint8 receBuff[255]={0};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 data_len)
{
    buf_len=0;
    memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,data_len);
    buf_len=data_len;
    if (NULL != strstr((char*)uart_buf,"write"))
    {
        uart_send_to_incoming_queue_from_isr(I2C_WRITE_CMD);
    }
    else if (NULL != strstr((char*)uart_buf,"read"))
    {
        uart_send_to_incoming_queue_from_isr(I2C_READ_CMD);
    }
    else 
    {
        uart_send_to_incoming_queue_from_isr(1);
    }
}

static QL_RET i2c_write_data (uint16 slaveaddr, uint8 registeraddr, uint8* pdata, uint8 length)
{
    uint8 i = 0;
    QL_RET ret = 0;
    uint8 buffer[256];
    uint8 num_page=0;
    uint8 remain_data=0;
    uint8 head_add=0;
    
    if (pdata == NULL || length <= 0)
    {
        return QL_RET_ERR_PARAM;
    }
    head_add=8-(registeraddr%8);
    if(head_add<length)
    {
        if(head_add>0)
        {
            buffer[0]=registeraddr;
            memcpy(&buffer[1],pdata,head_add);
            ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, buffer, head_add+1);
            if (ret != QL_RET_OK)
            {
                return ret;
            }
            registeraddr+=head_add;
            pdata=pdata+head_add;
            length=length-head_add;
            osDelay(100);
        }
        num_page=length/8;
        remain_data=length%8;
        if(num_page>0)
        {   
            for(i=0;i<num_page;i++)
            {        
                buffer[0]=registeraddr+i*8;
                memcpy(&buffer[1],pdata+i*8,8);
                ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, buffer, 9);
                if (ret != QL_RET_OK)
                {
                    return ret;
                }
                osDelay(100);
            }
        }
        if(remain_data>0)
        {
            buffer[0]=registeraddr+i*8;
            memcpy(&buffer[1],pdata+i*8,remain_data);
            ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, buffer, remain_data+1);
            if (ret != QL_RET_OK)
            {
              return ret;
            }
        }        
        osDelay(100);
    }  
    else
    {
        buffer[0]=registeraddr;
        memcpy(&buffer[1],pdata,length);
        ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, buffer,length+1);
        if (ret!= QL_RET_OK)
        {
            return ret;
        }
        osDelay(100);        
    }        
    return ret;
}
static QL_RET i2c_read_data (uint16 slaveaddr, uint8 registeraddr, uint8* pdata, uint8 length)
{
    QL_RET ret = 0;
    uint8 num_page=0;
    uint8 remain_data=0;
    uint8 offset_addres=0;
    uint8 i=0;
    
    if (pdata == NULL || length <= 0)
    {
        return QL_RET_ERR_PARAM;
    }
    num_page=length/8;
    remain_data=length%8;
    if(num_page>0) 
    {
        for(i=0;i<num_page;i++)
        {
            offset_addres=registeraddr+i*8;   
            ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, &offset_addres, sizeof(uint8));
            if (ret != QL_RET_OK)
            {
                return ret;
            }
            ret = ql_i2c_read(I2C_CHNNLNO, slaveaddr, pdata+i*8, 8);
            if (ret != QL_RET_OK)
            {
                return ret;
            }
            osDelay(100);
        }
    }
    if(remain_data>0)
    {
        offset_addres=registeraddr+i*8; 
        ret = ql_i2c_write(I2C_CHNNLNO, slaveaddr, &offset_addres, sizeof(uint8));
        if (ret != QL_RET_OK)
        {
            return ret;
        }
        ret = ql_i2c_read(I2C_CHNNLNO, slaveaddr, pdata+i*8, remain_data);
        if (ret != QL_RET_OK)
        {
            return ret;
        }
        osDelay(100);
    }
    osDelay(100);
    return ret;
}

static QL_RET i2c_program(void)
{   
    QL_RET ret = 0;
#if defined _MODULE_BC35_G_ 
    ret = ql_i2c_init(I2C_CHNNLNO,PINNAME_I2C_SCL,PINNAME_I2C_SDA,true);
#elif defined _MODULE_BC28_
    ret = ql_i2c_init(I2C_CHNNLNO,PINNAME_GPIO1,PINNAME_GPIO2,true);
#endif
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<---I2C init failed!,ret=%d --->\r\n",ret);
        return ret;
    }

    ret = ql_i2c_config(I2C_CHNNLNO,true,I2C_Config_Addr_Type_7bit,I2C_Config_Half_Speed_100kbit);
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<---I2C config failed!,ret=%d --->\r\n",ret);
        return ret;
    }    
    
    return ret;
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void) unused;
    ql_uart_config uart1_config;    
    uint32 msg = 0;
    QL_RET ret = 0;
	uint8 tmp_len = 0;	
    
    uart_create_queue();
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if (ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    
    if (ql_io_bank_open(IO_BANK_L1,VDD_IO_LEVEL_3V0) != QL_RET_OK )
    {
        QDEBUG_TRACE("user open IO_BANK_L1 err");
    }
    else
    {
        QDEBUG_TRACE("user open IO_BANK_L1 succe");
    }
  
    ret = i2c_program();
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<-- I2C program error,ret=%d -->\r\n",ret);
    }
    else
    {
        APP_DEBUG("<-- I2C program succeed -->\r\n");
    } 

    APP_DEBUG("\r\n<-- OpenCPU: I2C Example -->\r\n");
    APP_DEBUG("<-- cmd: write <data> (data is less than 247 characters)-->\r\n");
    APP_DEBUG("<-- cmd: read -->\r\n");
    for (;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            uint8 data[255]={0};
			APP_DEBUG("\r\n>>>>input: %s ",uart_buf);
            switch(msg)
            {      
                case I2C_WRITE_CMD:
                    memcpy(data, uart_buf+6,buf_len-6);
					tmp_len = (uint8)strlen((char*)data) - 2;
                	
                    ret = i2c_write_data(I2C_SLAVE_ADDR ,0x00, data, tmp_len);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<-- I2C write data error,ret=%d -->\r\n",ret);
                    }
                    else
                    {
                        APP_DEBUG("<-- I2C write data succeed -->\r\n");
                    }
                    break;
                case I2C_READ_CMD: 
					if(0 == tmp_len)
					{
						APP_DEBUG("<-- No data, please write first -->\r\n");
						break;
					}
                    memset(receBuff,0,sizeof(receBuff));
                    ret = i2c_read_data(I2C_SLAVE_ADDR ,0x00, receBuff, tmp_len);
                    if (ret == QL_RET_OK)
                    {
                        APP_DEBUG("-->>I2C read data succeed,receBuff=%s \r\n",receBuff);
                    }
                    else
                    {
                        APP_DEBUG("<-- I2C read data failed, check code,ret=%d -->\r\n",ret);
                    }
                    break;
                default :
                    APP_DEBUG("<--Error: unknown input-->\r\n");
                    break;
            }
        }
        (void)osThreadYield();      
    }
}
#endif // __EXAMPLE_I2C__