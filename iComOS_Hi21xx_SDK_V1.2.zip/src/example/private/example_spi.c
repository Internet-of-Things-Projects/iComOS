/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_spi.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral equipment using spi interface 
*   in OpenCPU.In this example ,we use the spi flash(W25Q32XX)serials chip;you can direct use this example
*   to read , write,or erase the flash;
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_SPI__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1. Input "write"          via uart1 to write the data to FLASH ,before you write operation,you need execute the erase conmand first
*     2. Input "read"           via uart1 to read the data  which you write from flash,then send back to uart1
*     3. Input "read id"        via uart1 to read the ID of FLASH
*     4. Input "erase sector"   via uart1 to erase the flash sector 
*     5. Input "erase block"    via uart1 to erase the flash block
*
* Author: Evan.Wu
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_SPI__
#include "ql_common.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_gpio.h"
#include "ql_string.h"
#include "ql_io_bank.h"
#include "ql_spi.h"
#include "example.h"

/****** slave device:  W25QXX ***********/
#if  defined _MODULE_BC35_G_
#define FLASH_PINNAME_SPI_CLK            PINNAME_SPI2_CLK
#define FLASH_PINNAME_SPI_SO             PINNAME_SPI2_SO
#define FLASH_PINNAME_SPI_SI             PINNAME_SPI2_SI
#define FLASH_PINNAME_SPI_CS             PINNAME_SPI2_CS

#elif defined _MODULE_BC28_

#define FLASH_PINNAME_SPI_CLK            PINNAME_SPI_CLK
#define FLASH_PINNAME_SPI_SO             PINNAME_SPI_SO
#define FLASH_PINNAME_SPI_SI             PINNAME_SPI_SI
#define FLASH_PINNAME_SPI_CS             PINNAME_SPI_CS
#endif

#define SPI_CHNNLNO                       0
#define SPI_WRITE_CMD                     0x400
#define SPI_READ_CMD                      0x401
#define SPI_READ_ID_CMD                   0x402
#define SPI_ERASE_SECTOR_CMD              0x403
#define SPI_ERASE_32KBLOCK_CMD            0x404
#define SPI_ERASE_CHIP_CMD                0x405

#define SPI_Interface_Type                SPI_Interface_Type_Single_Unidir
#define SPI_CLK_Mode                      SPI_Clock_Mode3
#define SPI_Data_Size                     0x08
#define SPI_CLK_Speed                     0x04

#define SPI_BASE_SECTOR                   0x00

#define FLASH_WriteEnable_CMD             (0x06)
#define FLASH_WriteStatusReg_CMD          (0x01)
#define FLASH_WritePage_CMD               (0x02)

#define FLASH_ReadID_CMD                  (0x9F)
#define FLASH_ReadStatusReg_CMD           (0x05)
#define FLASH_ReadEnable_CMD              (0x03)
#define FLASH_ManufactDeviceID_CMD        (0x90)             

#define FLASH_ERASE_SECTOR_CMD            (0x20)
#define FLASH_ERASE_32K_CMD               (0x52)

#define FLASH_ADDR_MASK                   (0xFFFFFF)
#define FLASH_SECTOR_MAX_ERASEADDR        (4096)
#define FLASH_32KBLOCK_MAX_ERASEADDR      (512)
#define FLASH_PAGESIZE                    (256)

#define FLASH_SECTOR_SHIFT                (12)
#define FLASH_32KBLOCK_SHIFT              (15)
#define FLASH_MAX_ADDR                    (0x1000000)
#define SPI_R_MAX_LEN                     (128)            


#define UART_QUEUE_LEN  3
static osMessageQueueId_t uart_queue = NULL;
static uint8 uart_buf[255]={0};
static uint16 buf_len=0;
static uint8 receBuff[255]={0};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 data_len)
{
    buf_len=0;
    memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,data_len);
    buf_len=data_len;
    if (0 == strncmp((char*)uart_buf,"write",5))
    {
        uart_send_to_incoming_queue_from_isr(SPI_WRITE_CMD);
    }
    else if (0 == strncmp((char*)uart_buf,"read id",7))
    {
        uart_send_to_incoming_queue_from_isr(SPI_READ_ID_CMD);
    }
    else if (0 == strncmp((char*)uart_buf,"read",4))
    {
        uart_send_to_incoming_queue_from_isr(SPI_READ_CMD);
    }
    else if (0 == strncmp((char*)uart_buf,"erase sector",12))
    {
        uart_send_to_incoming_queue_from_isr(SPI_ERASE_SECTOR_CMD);
    }
    else if (0 == strncmp((char*)uart_buf,"erase block",11))
    {
        uart_send_to_incoming_queue_from_isr(SPI_ERASE_32KBLOCK_CMD);
    }
    else 
    {
        uart_send_to_incoming_queue_from_isr(1);
    }
}

/*************************************************************************************/
static QL_RET spi_flash_general_send_cmd(uint8* cmd, uint8 length)
{
    QL_RET ret = ql_spi_write(SPI_CHNNLNO, NULL, 0, cmd, length, 0);
    if (ret != QL_RET_OK)
    {
        return QL_RET_ERR_WRITE;
    }
    return ret;
}

static QL_RET spi_flash_exec_read_data_cmd(uint32 addr, uint8* buffer, uint16 length)
{
    uint8 cmd[4] = {FLASH_ReadEnable_CMD, (uint8)(addr>>16), (uint8)(addr>>8), (uint8)addr};
    QL_RET ret;
    for (uint8 count=0; count < length;)
    {
        if((length-count) > SPI_R_MAX_LEN)
        {
            ret = ql_spi_read(SPI_CHNNLNO, cmd, sizeof(cmd), buffer+count, SPI_R_MAX_LEN, 0, true);
            if (ret!=QL_RET_OK)
            {              
                return QL_RET_ERR_READ;
            }
            addr += SPI_R_MAX_LEN;
            count += SPI_R_MAX_LEN;        
        }
        else
        {
            ret = ql_spi_read(SPI_CHNNLNO, cmd, sizeof(cmd), buffer+count, length-count, 0, true);
            if (ret!=QL_RET_OK)
            {
                return QL_RET_ERR_READ;
            }
            count = length;
        }
    }
    return ret;
}

static QL_RET spi_flash_exec_read_status_register_cmd(uint8* state)
{
    uint8 cmd[1] = {FLASH_ReadStatusReg_CMD};
    QL_RET ret;
    if (NULL == state)
    {
        return QL_RET_ERR_PARAM;
    } 
    ret = ql_spi_read(SPI_CHNNLNO, cmd, sizeof(cmd), state, 1, 0, true);
    if(ret != QL_RET_OK)
    {
        return QL_RET_ERR_READ;
    }    
    return ret;
}

static QL_RET spi_flash_is_processing(void)
{
    uint8 state;
    QL_RET ret;
    ret = spi_flash_exec_read_status_register_cmd(&state);
    if(QL_RET_OK != ret)
    {
        return QL_RET_ERR_PROGRESS;
    }
    while((state & 0x01) == 0x01)
    {
        ret = spi_flash_exec_read_status_register_cmd(&state);
        if(QL_RET_OK != ret)
        {
            return QL_RET_ERR_PROGRESS;
        }   
        osDelay(1);
    }
    return ret;
}

static QL_RET spi_flash_exec_write_cmd_enable(void)
{
    uint8 cmd[1] = {FLASH_WriteEnable_CMD};
    return spi_flash_general_send_cmd(cmd, sizeof(cmd));
}

static QL_RET spi_flash_exec_sector_erase_cmd(uint32 addr)
{
    uint8 cmd[4] = {FLASH_ERASE_SECTOR_CMD, (uint8)(addr >> 16), (uint8)(addr >> 8), (uint8)addr};

    if(spi_flash_is_processing() != QL_RET_OK)
    {
        return QL_RET_ERR_PROGRESS;
    }
    
    if(spi_flash_exec_write_cmd_enable() != QL_RET_OK)
    {
        return QL_RET_ERR_READ;
    }
    
    if(spi_flash_is_processing() != QL_RET_OK)
    {
        return QL_RET_ERR_PROGRESS;
    }
    
    return spi_flash_general_send_cmd(cmd, sizeof(cmd));
}

static QL_RET spi_flash_exec_32k_block_erase_cmd(uint32 addr)
{
    uint8 cmd[4] = {FLASH_ERASE_32K_CMD, (uint8)(addr >> 16), (uint8)(addr >> 8), (uint8)addr};

    if(spi_flash_is_processing() != QL_RET_OK)
    {
        return QL_RET_ERR_PROGRESS;
    }
    
    if(spi_flash_exec_write_cmd_enable() != QL_RET_OK)
    {
        return QL_RET_ERR_READ;
    }
    
    if(spi_flash_is_processing() != QL_RET_OK)
    {
        return QL_RET_ERR_PROGRESS;
    }
    return spi_flash_general_send_cmd(cmd, sizeof(cmd));
}

static QL_RET spi_flash_page_write(uint32 addr, uint8* buffer, uint16 length)
{
	QL_RET ret;
	uint8 cmd[4] = {FLASH_WritePage_CMD, (uint8)(addr >> 16), (uint8)(addr >> 8), (uint8)addr};

	ret = spi_flash_is_processing();
    if(ret != QL_RET_OK)
    {
        return QL_RET_ERR_PROGRESS;
    }
	
	ret = spi_flash_exec_write_cmd_enable();
    if (ret != QL_RET_OK)
    {
        return QL_RET_ERR_WRITE;
    }
	
	ret = ql_spi_write(SPI_CHNNLNO, cmd, sizeof(cmd), buffer, length, 0);
	if (ret != QL_RET_OK)
    {
        return QL_RET_ERR_WRITE;
    }
	return ret;
}

static QL_RET spi_flash_exec_write_data_cmd(uint32 addr, uint8* buffer, uint16 length)
{
    QL_RET ret;
    uint8 *pbuff = buffer;
	uint32 start_addr = addr;
	uint16 remaining_length = length, tmp_len = length;
	
	if(start_addr/FLASH_PAGESIZE != (start_addr + remaining_length - 1)/FLASH_PAGESIZE)
	{
		while(remaining_length)
		{
			tmp_len = (FLASH_PAGESIZE - start_addr%FLASH_PAGESIZE);
			if(0 == tmp_len)
			{
				if(remaining_length >= FLASH_PAGESIZE)
					tmp_len = FLASH_PAGESIZE;
				else
					tmp_len = remaining_length;
			}
			else
			{
				if(tmp_len > remaining_length)
					tmp_len = remaining_length;
			}
			ret = spi_flash_page_write(start_addr, pbuff, tmp_len);
			if (ret != QL_RET_OK)
    		{
        		return QL_RET_ERR_WRITE;
			}
			start_addr += tmp_len;
			pbuff += tmp_len;
			if(tmp_len > remaining_length)
				return QL_RET_ERR_WRITE;
			remaining_length -= tmp_len;
		}
	}
	else
	{
    	ret = spi_flash_page_write(start_addr, pbuff, tmp_len);
    	if (ret != QL_RET_OK)
    	{
        	return QL_RET_ERR_WRITE;
    	}
	}
    return ret;
}

static QL_RET spi_flash_write_data(uint32 addr, uint8* buffer, uint16 length)
{
    QL_RET ret;
    
    ret = spi_flash_exec_write_data_cmd(addr, buffer, length);
    if (ret != QL_RET_OK)
	{
		return QL_RET_ERR_WRITE;
	}
    return ret;
}

static QL_RET spi_flash_read_data (uint32 addr, uint8* buffer, uint16 length)
{
    QL_RET ret;
    ret = spi_flash_is_processing();
    if (ret != QL_RET_OK)
    {    
        QDEBUG_TRACE("spi read busy");
        return QL_RET_ERR_PROGRESS;
    }
    ret = spi_flash_exec_read_data_cmd(addr, buffer, length);
    if (ret != QL_RET_OK)
    {
        QDEBUG_TRACE("spi read err");
        return QL_RET_ERR_READ;
    }
    return  ret;
}

static QL_RET spi_flash_read_id_data (uint8 *buffer,uint8 *len)
{
    uint8 cmd[1] = {FLASH_ReadID_CMD};
    uint8 flash_id[3] = {0};
    QL_RET ret;
    
    ret = ql_spi_read(SPI_CHNNLNO, cmd, sizeof(cmd), flash_id, sizeof(flash_id), 0, 1);        
    if(ret!=QL_RET_OK)
    {   
        QDEBUG_TRACE("SPI flash receive ID to failed !");
        return QL_RET_ERR_READ;
    }    
    memcpy(buffer,flash_id,3);
    *len=3;
    return ret ; 
}

static QL_RET spi_program(void)
{   
    QL_RET ret = 0;

    ret = ql_spi_init(SPI_CHNNLNO,FLASH_PINNAME_SPI_CLK,FLASH_PINNAME_SPI_SO,FLASH_PINNAME_SPI_SI,FLASH_PINNAME_SPI_CS,SPI_Interface_Type,true);
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<--- SPI init failed!,ret=%d --->\r\n",ret);
        return ret;
    }

    ret = ql_spi_config(SPI_CHNNLNO,true,SPI_CLK_Mode,SPI_Data_Size,SPI_CLK_Speed);
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<--- SPI config failed!,ret=%d --->\r\n",ret);
        return ret;
    }    

	ql_gpio_pull_config(FLASH_PINNAME_SPI_SO, PIN_PULL_UP);
	
    return ret;
}


/**************************************************************
* Main Task
***************************************************************/
void main_task (void *unused)
{
    (void)unused;
    ql_uart_config uart1_config;    
    uint32 msg = 0;
    QL_RET ret = 0;
    
    ql_wait_for_at_init();  //wait for modem ok
    
    uart_create_queue();
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if (ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    
    if (ql_io_bank_open(IO_BANK_L1,VDD_IO_LEVEL_3V0) != QL_RET_OK )
    {
        QDEBUG_TRACE("user open IO_BANK_L1 error");
    }
    else
    {
        QDEBUG_TRACE("user open IO_BANK_L1 succe");
    }
    
    ret = spi_program();
    if (ret != QL_RET_OK)
    {
        APP_DEBUG("<-- SPI program error,ret=%d -->\r\n",ret);
    }
    else
    {
        APP_DEBUG("<-- SPI program succeed -->\r\n");
    } 
    APP_DEBUG("\r\n<--- OpenCPU: SPI Example -->\r\n");
    APP_DEBUG("<--   write data cmd: write -->\r\n");
    APP_DEBUG("<--    read data cmd: read -->\r\n");
    APP_DEBUG("<--      read id cmd: read id -->\r\n");
    APP_DEBUG("<-- erase sector cmd: erase sector -->\r\n");
    APP_DEBUG("<--  erase block cmd: erase block -->\r\n");
    
    for (;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            uint8 data[255]={0};
            uint8 flashID[6]={0};
            uint8 flashID_len;
            uint16 i=0;
			APP_DEBUG("\r\n>>>>input: %s ",uart_buf);
            switch(msg)
            {      
                case SPI_WRITE_CMD:
                    /****** fill in data ****/
                    while(i<50)
                    {
                        data[i]=i*5;
                        i++;
                    }
                    ret = spi_flash_write_data(SPI_BASE_SECTOR,data,50);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<-- SPI write data failed, check code,ret=%d -->\r\n",ret);
                    }
                    else
                    {  
                        
                        APP_DEBUG("<-- SPI write data succeed, data:");
                        i=0;
                        while(i<50)
                        {
                            APP_DEBUG("%02x ",data[i++]);
                        }
                        APP_DEBUG(" -->\r\n");        
                    }
                    break;
                case SPI_READ_CMD: 
                    memset(receBuff,0,sizeof(receBuff));
                    ret = spi_flash_read_data(SPI_BASE_SECTOR, receBuff, 50);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<-- SPI read data failed, check code,ret=%d -->\r\n",ret);
                    }
                    else
                    {  
                        APP_DEBUG("<-- SPI read data succeed, recvBuff:");
                        i=0;
                        while(i<50)
                        {
                            APP_DEBUG("%02x ",receBuff[i++]);
                        }
                        APP_DEBUG(" -->\r\n");    
                    }
                    break;
                case SPI_READ_ID_CMD:
                    ret = spi_flash_read_id_data(flashID,&flashID_len);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<-- SPI read id failed, check code,ret=%d -->\r\n",ret);
                    }
                    else
                    {
                        
                        APP_DEBUG("<-- SPI read id succeed,flashID: 0x%x%x%x -->\r\n",flashID[0],flashID[1],flashID[2]);
                    }     
                    break;
                case SPI_ERASE_SECTOR_CMD:
                    ret = spi_flash_exec_sector_erase_cmd(SPI_BASE_SECTOR);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<-- SPI erase sector failed, check code,ret=%d -->\r\n",ret);
                    }
                    else
                    {
                        APP_DEBUG("<-- SPI erase sector succeed -->\r\n");
                    }
                 
                    break;
                case SPI_ERASE_32KBLOCK_CMD:
                    ret = spi_flash_exec_32k_block_erase_cmd(SPI_BASE_SECTOR);
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("--- SPI erase block failed, check code,ret=%d -->\r\n",ret);
                    }
                    else
                    {
                        APP_DEBUG("<-- SPI erase block succeed -->\r\n");
                    }
                 
                    break;
                default :
                    APP_DEBUG("<-- Input command error, input again! -->\r\n");
                    break;
            }
        }
        (void)osThreadYield();      
    }
}
#endif // __EXAMPLE_SPI__