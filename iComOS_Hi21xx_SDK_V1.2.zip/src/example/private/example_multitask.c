/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_multitask.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to program ADC interface in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_MULTITASK__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Operation:
*
* Author:
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_MULTITASK__
#include "ql_common.h"
#include "ql_uart.h"
#include "ql_string.h"
#include "ql_app_debug.h"
#include "example.h"

static uint8  cahce_buffer[256] =   {0};
static uint16 cahce_buffer_len  =   0;
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
    memcpy(cahce_buffer,buffer,len);
    cahce_buffer_len = len;
    QDEBUG_TRACE("rcv:%s",cahce_buffer);
}
  

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused)
{
    ql_uart_config uart1_config;
    UNUSED(unused);
    uint32 cnt =0;
    ql_wait_for_at_init();  //wait for modem ok  

    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle) != QL_RET_OK )
    {
        QDEBUG_TRACE("open uart1 error");
    }

    APP_DEBUG("\r\n<-- OpenCPU: Multitask Example -->\r\n");
    
    while(1)
    {
        APP_DEBUG("\r\n<-- Main task has run %d times -->\r\n",cnt++);

        //Add you own code here
		osDelay(5000);
        osThreadYield();
    }
}


/**************************************************************
* Sub Task1
***************************************************************/
void sub_task1( void *unused)
{
    UNUSED(unused);
    uint32 cnt =0;
    osDelay(10000);  //wait uart1 initialized 
    APP_DEBUG("\r\n<-- OpenCPU: Sub task1 start -->\r\n");

    while(1)
    {
        APP_DEBUG("\r\n<-- Sub task1 has run %d times -->\r\n",cnt++);
        //Add you own code here    
		osDelay(10000);
        osThreadYield();
    }
}


/**************************************************************
* Sub Task2
***************************************************************/
void sub_task2( void *unused)
{
    UNUSED(unused);
    uint32 cnt =0;
    osDelay(10000);  //wait uart1 initialized 
    APP_DEBUG("\r\n<-- OpenCPU: Sub task2 start -->\r\n");

    // Start message loop of this task
    while(1)
    {
        APP_DEBUG("\r\n<-- Sub task2 has run %d times -->\r\n",cnt++);
        //Add you own code here
		osDelay(20000);
        osThreadYield();
    }
}
#endif // __EXAMPLE_MULTITASK__