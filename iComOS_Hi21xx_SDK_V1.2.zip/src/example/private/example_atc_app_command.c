/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_atc_app_command.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral  using AT COMMAND ,via virtual uart port 
*   in OpenCPU.In this example ,we use the UART1 peripheral send AT conmand to virtual uart port,then the virtual
*   uart port send the result to uart1;you can direct use this example to develop;
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_ATC_PIPE__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*
*     1. Send AT+QCUSTOMERVER=<customer version> command to set the customer version use QCOM tool via uart1 port;
*     2. Send AT+QCUSTOMERVER?                   command to query the customer version use QCOM tool via uart1 port;
*     3. Send AT+QCUSTOMERHWVER=?                command to test the parameters of the command use QCOM tool via uart1 port;
*     4. Send AT+QCUSTOMERHWVER                  command to query the customer hardware version use QCOM tool via uart1 port;
*
*Author:
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_ATC_APP_COMMAND__
#include "ql_common.h"
#include "ql_uart.h"
#include "ql_string.h"
#include "ql_app_debug.h"
#include "ql_app_at.h"
#include "ql_system.h"
#include "example.h"

#define UART_QUEUE_LEN              3
#define UART_QUEUE_ITEM_SIZE        4

#define HARDWARE_VERSION            "APP_HARDWARE_V1.0"

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255] = {0};
static uint16 buf_len = 0;
static uint8  ver_string[20] = {0};

/* AT+QCUSTOMERVER=<customer version> */
static QL_RET at_handle_qcustomerver_cmd_set(uint8 *at_string)
{
    QL_RET ret;
    uint8  num_recvparams;
    memset(ver_string,0,sizeof(ver_string));
    ret = ql_at_create_param_array(at_string, &num_recvparams, 1, 1);
    if(QL_RET_OK != ret)
    {
        return ret;
    }

    if(QL_RET_OK != ql_at_get_string_param(QL_AT_PARSE_FIRST_PARAM_POS, ver_string, sizeof(ver_string), true))
    {
        return QL_RET_ERR_PARAM;
    }  
    if (strlen((char*)ver_string) > sizeof(ver_string))
    {
        return QL_RET_ERR_NOT_SUPPORT;
    }
    return QL_RET_OK;   
}
/* AT+QCUSTOMERVER? */
static QL_RET at_handle_qcustomerver_cmd_read(void)
{
    char   rsp_string[50] = {0};
    if (strlen((char *)ver_string) == 0)
    {
        return QL_RET_OK;
    }
    (void)snprintf(rsp_string, 50, "+QCUSTOMER:%s", ver_string); 
    ql_app_at_send_at_rsp_string_lines(rsp_string,true,QL_AT_FLAG_VISIABLE);
    return QL_RET_OK;
}


/* AT+QCUSTOMERHWVER=? */
static QL_RET at_handle_qcustomerhwver_cmd_test(void)
{
    char   rsp_string[50] = {0};
    
    (void)snprintf(rsp_string, 50, "+QCUSTOMERHWVER:%s", "<HARDWARE VERSION>");  
    ql_app_at_send_at_rsp_string_lines(rsp_string,true,QL_AT_FLAG_VISIABLE);
    return QL_RET_OK;

}
/* AT+QCUSTOMERHWVER */
static QL_RET at_handle_qcustomerhwver_cmd_exec(void)
{
    char   rsp_string[50] = {0};
    
    (void)snprintf(rsp_string, 50, "+QCUSTOMERHWVER:%s", HARDWARE_VERSION);  
    ql_app_at_send_at_rsp_string_lines(rsp_string,true,QL_AT_FLAG_VISIABLE);
    return QL_RET_OK;
}

static const QL_AT_CMD_CB_s at_cmd_customer_table[] = 
{
    /* AT+QCUSTOMERVER=<customer version> and  AT+QCUSTOMERVER? */
    {QL_AT_FLAG_VISIABLE,"+QCUSTOMERVER", at_handle_qcustomerver_cmd_set, at_handle_qcustomerver_cmd_read, NULL, NULL},
    /* AT+QCUSTOMERHWVER=?  and AT+QCUSTOMERHWVER */
    {QL_AT_FLAG_VISIABLE,"+QCUSTOMERHWVER", NULL, NULL, at_handle_qcustomerhwver_cmd_test, at_handle_qcustomerhwver_cmd_exec},
};


static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void vuart_recieve_handle(uint8 * buffer, uint32 len)
{
    ql_uart_write(UART_PORT1, buffer,len);
}

static void app_at_cmd_customer_callback(void)
{
    uint8 table_size;
    uint8 i;
    static bool initialed = false;

    if (initialed)
    {
        return;
    }

    table_size = sizeof(at_cmd_customer_table)/sizeof(QL_AT_CMD_CB_s);
    for (i = 0; i < table_size; i++)
    {
        (void)ql_at_cmd_register(&at_cmd_customer_table[i]);
    } 
    initialed = true;
    
    return;
}


/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    if(ql_uart_init(VIRTUAL_PORT) != QL_RET_OK)
    {
        QDEBUG_TRACE("vuart port init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    
    enable_virtual_port();
    ql_uart_open(VIRTUAL_PORT, &uart1_config, vuart_recieve_handle);


    ql_app_at_cmd_customer_init(app_at_cmd_customer_callback);

    
    APP_DEBUG("\r\n<-- OpenCPU: ATC_APP_COMMAND Example -->\r\n");
    APP_DEBUG("\r\n<-- cmd: AT+QCUSTOMERVER=<customer version>  -->");
    APP_DEBUG("\r\n<-- cmd: AT+QCUSTOMERVER?    -->");
    APP_DEBUG("\r\n<-- cmd: AT+QCUSTOMERHWVER=? -->");
    APP_DEBUG("\r\n<-- cmd: AT+QCUSTOMERHWVER   -->\r\n");
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            if(ql_uart_write(VIRTUAL_PORT ,uart_buf,buf_len)!=QL_RET_OK)
            {
            	APP_DEBUG("\r\n<-- Error: virtual port sent fail -->\r\n");
            }
       }
        (void)osThreadYield();       
    }
}
#endif // __EXAMPLE_ATC_APP_COMMAND__
