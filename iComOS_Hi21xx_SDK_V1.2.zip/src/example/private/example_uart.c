/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_uart.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral equipment using uart interface 
*   in OpenCPU.In this example ,we use the UART3 peripheral and use serials tool to debug;you can direct 
*   use this example to develop;
*
*   All debug information will be output through DEBUG port and UART port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_UART__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*     1.In this example,we use the uart3 port ;
*     2.you can send data via uart3 port;then it will feedback via uart3 port to your equiment
*
* Author:
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_UART__
#include "ql_common.h"
#include "ql_uart.h"
#include "ql_string.h"
#include "ql_system.h"
#include "ql_app_debug.h"
#include "ql_io_bank.h"
#include "example.h"


#define UART_QUEUE_LEN        3
#define UART_QUEUE_ITEM_SIZE  4

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static uint8 uart3_buf[255]={0};
static uint16 buf3_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(UART_PORT1);
}

static void uart3_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart3_buf,0,sizeof(uart3_buf));
    memcpy(uart3_buf,buffer,len);
    buf3_len = len;
	QDEBUG_TRACE("rcv3:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(UART_PORT3);
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
    ql_uart_config uart3_config;
   ( void) unused;
    uint32 msg = 0;
	uint8 echo_buf[512] = {0};

	
    ql_wait_for_at_init();  //wait for modem ok  
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    if(ql_uart_init(UART_PORT3) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port3 init error");
    } 
    if(ql_io_bank_open(IO_BANK_L1,VDD_IO_LEVEL_3V0) != QL_RET_OK )
    {
        QDEBUG_TRACE("user open IO_BANK_L1 err\r\n");
    }  

	/*note: Disable the system to enter deep sleep mode*/
    ql_add_stop_clocksveto();  
	
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;

    uart3_config.baudrate=115200;
    uart3_config.data_bits=QL_UART_DATA_BITS_8;
    uart3_config.parity=QL_UART_PARITY_NONE;
    uart3_config.stopbits=QL_UART_STOP_BITS_1;
    
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle) != QL_RET_OK )
    {
        QDEBUG_TRACE("user open uart1 fail\r\n");
    }    
    if( ql_uart_open(UART_PORT3, &uart3_config, uart3_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open uart3 fail\r\n");
    }
    APP_DEBUG("\r\n<-- OpenCPU: UART Example -->\r\n");
    for(;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            switch(msg)
            {
                case UART_PORT1:
                    APP_DEBUG("\r\n<--uart1 recieve data-->\r\n");  
					sprintf((char*)echo_buf,"from uart1:%s\r\n",uart_buf);
					
                    if(ql_uart_write(UART_PORT1,echo_buf,strlen((char*)echo_buf))==QL_RET_OK)
                    {
                        APP_DEBUG("\r\n<--write uart1 success-->\r\n");
                    }
                    else
                    {
                        APP_DEBUG("\r\n<--write uart1 fail-->\r\n");
                    }

                    if(ql_uart_write(UART_PORT3,echo_buf,strlen((char*)echo_buf))==QL_RET_OK)
                    {
                        APP_DEBUG("\r\n<--write uart3 success-->\r\n");
                    }
                    else
                    {
                        APP_DEBUG("\r\n<--write uart3 fail-->\r\n");
                    }

                    break;
                 case UART_PORT3:
					 APP_DEBUG("\r\n<--uart3 recieve data-->\r\n");  
					 sprintf((char*)echo_buf,"from uart3:%s\r\n",uart3_buf);
					 
					 if(ql_uart_write(UART_PORT1,echo_buf,strlen((char*)echo_buf))==QL_RET_OK)
					 {
						 APP_DEBUG("\r\n<--write uart1 success-->\r\n");
					 }
					 else
					 {
						 APP_DEBUG("\r\n<--write uart1 fail-->\r\n");
					 }
					 
					 if(ql_uart_write(UART_PORT3,echo_buf,strlen((char*)echo_buf))==QL_RET_OK)
					 {
						 APP_DEBUG("\r\n<--write uart3 success-->\r\n");
					 }
					 else
					 {
						 APP_DEBUG("\r\n<--write uart3 fail-->\r\n");
					 }

                    break; 
                 default:
                    break;
            }        
        }
        (void)osThreadYield();       
    }
}

#endif

