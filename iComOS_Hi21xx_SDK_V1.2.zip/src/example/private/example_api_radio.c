/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2018
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_network.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral  using AT COMMAND ,via virtual uart port 
*   in OpenCPU.In this example ,we use the UART1 peripheral send AT conmand to virtual uart port,then the virtual
*   uart port send the result to uart1;you can direct use this example to develop;
*
*   All debug information will be output through DEBUG port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_RADIO__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*     1. send AT COMMAND use QCOM tool 

* Author:
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_API_RADIO__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "example.h"

#define API_NETWORK_QUEUE_LEN  5

typedef enum
{
    CFUN_EXE  = 1,
    CGATT_EXE,
    GETIP_EXE,
    GETCEREG_EXE,
} NETWORK_STEP;


const uint32 API_NETWORK_QUEUE_ITEM_SIZE=1;

static osMessageQueueId_t api_network_incoming_queue = NULL;


static void api_network_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(api_network_incoming_queue, (void*)&msg, 0, osWaitForever);
}


static void api_network_create_queue(void)
{
    api_network_incoming_queue = osMessageQueueNew(API_NETWORK_QUEUE_LEN, API_NETWORK_QUEUE_ITEM_SIZE, NULL);
    if(NULL == api_network_incoming_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	uint32 msg = 0;
	
	APP_DEBUG("\r\n<-- input len:%d input character:%s -->\r\n", len, buffer);
	if(NULL != strstr((char*)buffer,"set cfun"))
    {
		msg = CFUN_EXE;
	} 
	else if(NULL != strstr((char*)buffer,"set cgatt"))
	{
        msg = CGATT_EXE;
	}
	else if(NULL != strstr((char*)buffer,"get ip address"))
	{
	    msg = GETIP_EXE;
	}
	else if(NULL != strstr((char*)buffer,"get cereg"))
	{
	    msg = GETCEREG_EXE;
	}
	else
	{
	    APP_DEBUG("\r\n<-- Unrecognized command -->\r\n");
	    return;
	}
	api_network_send_to_incoming_queue_from_isr(msg);
}
static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		api_network_send_to_incoming_queue_from_isr(GETIP_EXE);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
		APP_DEBUG("\r\n<-- please  manually trigger the setting cgatt value -->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
		APP_DEBUG("\r\n<-- please  manually trigger the setting cfun value -->\r\n");
	}
}


/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16 autocon = 0;
    QL_CEREG cereg = {0};
    QL_RET ql_ret  = 0;
    char  ip[50] = {0};

	ql_wait_for_at_init();  //ike 20190524 wait for modem ok
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    api_network_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API Radio Example -->\r\n");
    APP_DEBUG("\r\n<-- 1. set cfun  -->\r\n");
    APP_DEBUG("\r\n<-- 2. set cgatt  -->\r\n");
    APP_DEBUG("\r\n<-- 3. get ip address  -->\r\n");
    APP_DEBUG("\r\n<-- 4. get cereg  -->\r\n");

    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disenable AUTOCONNECT and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(500);
		ql_reboot();
    }
    ql_set_cfun(1,cfun_callback);
    ql_set_cereg_callback(cereg_callback);
    for(;;)
    {
       if(osMessageQueueGet(api_network_incoming_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
			switch (msg)
			{
				case CFUN_EXE:
					 ql_ret = ql_set_cfun(1,cfun_callback);
					 APP_DEBUG("\r\n<-- set cfun function, result:%d -->\r\n",ql_ret);
					break;
				case CGATT_EXE:
					ql_ret = ql_set_cgatt_state(1,cgatt_callback);
					APP_DEBUG("\r\n<-- set cfun function, result:%d -->\r\n",ql_ret);
					break;
				case GETCEREG_EXE:
					ql_ret = ql_get_cereg_state(&cereg);
					APP_DEBUG("\r\n<-- get cereg state:%d -->\r\n",cereg.state);
					break;
				case GETIP_EXE:
					ql_ret = ql_get_device_ip(ip,sizeof(ip));
					APP_DEBUG("\r\n<-- get ip:%s, result:%d -->\r\n",ip,ql_ret);
					break;
				default: 
					APP_DEBUG("\r\n<-- error: unknown input -->\r\n");
					break;
			}
       }
       (void)osThreadYield(); 
    }

}

#endif
