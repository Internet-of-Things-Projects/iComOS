/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_fota.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example introduces the FOTA upgrade on the IoT platform through API mode, 
*   FOTA upgrade mode is controlled by default.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_KV__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Prepare:
*     1. Prepare the delta firmware package in advance, and create a delta firmware upgrade 
*        package between the two firmware versions by making a tool for the delta firmware package.
*     2. After making the differential package file, upload the delta firmware package to the IoT platform    
*     3. Create a FoTA upgrade task on the IoT platform.
*     4. After registering the module to the IoT platform, send a packet of data to the IoT 
*        platform to trigger the FOTA upgrade.
*
*   Operation:
*     1. Input "fota init" command via uart1 to initialize some initial test status of the fota 
*        upgrade and register to the IOT platform.
*     2. Input "fota trigger" command via uart1 to send a packet of data to the IoT platform to trigger 
*        the FOTA task established by the platform.   
*     3. Input "control fota:<state>" command via uart1 to control whether to download or upgrade firmware.
*
* Author: 
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_FOTA__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_occloud_api.h"
#include "cmsis_os2.h"
#include "example.h"

#if 0
#define APP_ATCDBG      APP_DEBUG
#else
#define APP_ATCDBG(x,...);     
#endif

#define UART_QUEUE_LEN                  25
#define ATCMD_TABLE_ITEM_MAX            sizeof(atcmd_table)/sizeof(AT_CMD)
#define ATRET_TABLE_ITEM_MAX            sizeof(atret_table)/sizeof(char*)
#define URC_TABLE_ITEM_MAX              sizeof(urc_handle_table)/sizeof(URC_HANDLE)
#define IOT_VERSION                     48

static osMessageQueueId_t uart_queue = NULL;
static uint8  uart_buf[512] = {0};
static uint16 buf_len = 0;

typedef enum 
{
    FOTA_OC_STATUS_UNINIT,
    FOTA_OC_STATUS_INITED,  
    FOTA_OC_STATUS_REGISTERING,
    FOTA_OC_STATUS_REGISTERED,
    FOTA_OC_STATUS_MO_DATA_ENABLED,
}fota_status;

typedef struct _fota_init_params 
{
    QL_CLOUD_INIT_PARAMS oc_init_params;
    char* device_ip;
    char version[50];   
    fota_status status;    
}fota_init_params;

static fota_init_params fota_init_param = {
    {
        0,
    	5683,
    	"180.101.147.115",
    	NULL,
    	NULL,
    },
    NULL,
    {0},
    FOTA_OC_STATUS_UNINIT,    
};
static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void register_timeout_handle(void)
{
    APP_DEBUG("\r\n<-- register timeout, check register status -->\r\n");
    fota_init_param.status = FOTA_OC_STATUS_MO_DATA_ENABLED;
}

static void occloud_notify_fota_callback(char* state)
{
    APP_DEBUG("\r\n<-- OC fota state:%s -->\r\n",state);
}

static void occloud_recv_callback(uint16 data_len)
{
    uint8 recvbuf[255] = {0};
    char printbuf[255] = {0};
    uint16 len = sizeof(recvbuf);
    QL_RET ret;
    ret = ql_occloud_get_recv_data(&len,recvbuf);
    if (len != data_len)
    {
        APP_DEBUG("\r\n<-- Error: received fail,cb len:%d-->\r\n",data_len);
    }
    ql_util_hex_to_string(printbuf,sizeof(printbuf),recvbuf,len);
    APP_DEBUG("\r\n<-- OC received,data:%s,%d,ret:%d -->\r\n",printbuf,len,ret);
}

static void occloud_notify_cb(QL_OCCLOULD_EVTIND notify)
{
    APP_DEBUG("\r\n<-- OC notify:%d -->\r\n",notify);
    if (3 == notify)
    {
        fota_init_param.status = FOTA_OC_STATUS_REGISTERED;
    }
    else if (6 == notify)
    {
        //or <control fota:3> cancel version file download.
        APP_DEBUG("\r\n<-- please input <control fota:2> start downloading -->\r\n");
    }
    else if (7 == notify)
    {
        //or <control fota:5> cancel update
        APP_DEBUG("\r\n<-- please input <control fota:4> start update -->\r\n");
    }
}

static void cgatt_callback(uint8 result)
{
    char ip_string[16] = {0};
    QL_RET ret = 0;
    if (0 == result)
    {
        APP_DEBUG("\r\n<-- set cgatt succe -->\r\n",ip_string);
        do
        {
            ret = ql_get_device_ip(ip_string,sizeof(ip_string));
            APP_DEBUG("\r\n<-- waiting get ip... -->\r\n");
            osDelay(1000);  
        }while((ip_string[0]=='\0') && (0 == ret));
        APP_DEBUG("\r\n<-- get device ip succe,ip:%s -->\r\n",ip_string);
        
    }
    else
    {
        APP_DEBUG("\r\n<-- set cgatt failed,ret:%d -->\r\n",result);
    }    
}

static void cfun_callback(uint8 result)
{
    if (0 == result)
    {
        APP_DEBUG("\r\n<-- set cfun succe -->\r\n");
        ql_set_cgatt_state(1, cgatt_callback);
    }
    else
    {
        APP_DEBUG("\r\n<-- set cfun failed,ret:%d -->\r\n",result);
    }
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void)unused;
    ql_uart_config uart1_config;
    uint32 msg = 0;
    uint16 autocon = 0;
    QL_OCCLOULD_FOTA_MODE  fota_mode = OCCLOULD_FOTA_MODE_MANUAL;
    uint16 reg_mode = 0;//manual register iot platform
    uint16 appversion_len;
    uint8 non_seq_num = 0x10;
    osTimerId_t timer_id = NULL;
    uint16 timeout = 30;
    QL_RET ret = 0;

    ql_wait_for_at_init();  //wait for modem ok  
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    }  
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if(QL_RET_OK != ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle))
    {
        QDEBUG_TRACE("uart port1 init error");
    }  
    ret = ql_get_application_version(&appversion_len,fota_init_param.version,sizeof(fota_init_param.version));
    if (QL_RET_OK == ret)
    {
        APP_DEBUG("\r\n<-- Pre-upgrade version:%s -->\r\n",fota_init_param.version);
    }
    else
    {
        APP_DEBUG("\r\n<-- get app version error!,ret:%d -->\r\n",ret);
    }
    if (QL_RET_OK != ql_occloud_set_registration_mode(reg_mode))
    {
        APP_DEBUG("\r\n<-- set register mode failed,ret:%d -->\r\n");
    }
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION, &autocon);
    if (1 == autocon)
    {
        APP_DEBUG("\r\n<-- disable AUTOCONNECT and reboot -->\r\n");
        autocon = 0;
        ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,autocon);
        ql_reboot();
    }
    if (QL_RET_OK == ql_occloud_set_fota_mode(fota_mode,occloud_notify_fota_callback))
    {
        APP_DEBUG("\r\n<-- set fota mode:%d -->\r\n",fota_mode);
    }
    APP_DEBUG("\r\n<-- OpenCPU: API FOTA Example -->");
    APP_DEBUG("\r\n<-- step1: fota init -->");
    APP_DEBUG("\r\n<-- step2: fota trigger -->");
    APP_DEBUG("\r\n<-- step3: control fota:<state> -->\r\n");
    
    for(;;)
    {
        if (osMessageQueueGet(uart_queue,(void*)&msg, NULL, osWaitForever) == osOK)
        {
            char* puart = NULL;
            puart = (char* )uart_buf;
            APP_DEBUG("\r\n>>>>input: %s",puart);
            if (NULL != strstr(puart,"fota init"))
            {
                ql_set_cfun(1,cfun_callback);
                ql_occloud_set_recv_callback(occloud_recv_callback);
                ret = ql_occloud_init(&fota_init_param.oc_init_params);
                if (QL_RET_OK != ret)
                {
                    APP_DEBUG("\r\n<-- occloud init error!,ret:%d -->\r\n",ret);
                }
                else
                {
                    APP_ATCDBG("\r\n<-- occloud init succe -->\r\n");
                    fota_init_param.status = FOTA_OC_STATUS_INITED;
                }
            }
            else if (NULL != strstr(puart,"fota trigger"))
            {
                if (FOTA_OC_STATUS_INITED == fota_init_param.status)
                {
                    ret = ql_occloud_connect(OCCLOULD_REGISTRATION,occloud_notify_cb);
                    if (QL_RET_OK != ret) 
                    {
                        APP_DEBUG("\r\n<-- occloud connect error!,ret:%d -->\r\n",ret);
                    }
                    else
                    {
                        APP_ATCDBG("\r\n<-- occloud connect succe -->\r\n");
                        fota_init_param.status = FOTA_OC_STATUS_REGISTERING;
                    }
                }
                timer_id = osTimerNew((osTimerFunc_t)register_timeout_handle,osTimerOnce,NULL,NULL);  
                if (osOK == osTimerStart(timer_id,(uint32_t)osMs2Tick((uint64_t)timeout*1000)))
                {
                    APP_ATCDBG("\r\n<-- start register timer -->\r\n");
                }
                while (FOTA_OC_STATUS_REGISTERING == fota_init_param.status)
                {
                    APP_DEBUG("\r\n<-- waiting register... -->\r\n");
                    osDelay(5000);
                }
                if (osTimerIsRunning(timer_id))
				{
                    APP_ATCDBG("\r\n<-- stop register timer -->\r\n");
					osTimerStop(timer_id);
				}
                if ((FOTA_OC_STATUS_REGISTERED == fota_init_param.status)||   \
                    (FOTA_OC_STATUS_MO_DATA_ENABLED == fota_init_param.status))
                {
                    APP_ATCDBG("\r\n<-- starting send a packet of data to trigger FOTA upgrade -->\r\n");
                    fota_init_param.status = FOTA_OC_STATUS_MO_DATA_ENABLED;
                    ret = ql_occloud_send((uint8*)"AABBCCDDEEFF", strlen("AABBCCDDEEFF")/2,OCCLOULD_MSG_NON_NORAI, non_seq_num++, NULL);
                    if (QL_RET_OK != ret)
                    {
                        APP_DEBUG("\r\n<-- send data error!,ret:%d -->\r\n",ret);
                    }
                    else
                    {
                        APP_DEBUG("\r\n<-- send data succe -->\r\n");
                        APP_DEBUG("\r\n<-- waiting FOTA upgrade... -->\r\n");
                    }
                }
            }
            else if (NULL != strstr(puart,"control fota:"))
            {
                uint8 cmd = 0;
                puart = strstr(puart,"control fota:");
                puart += strlen("control fota:");
                cmd = atoi(puart);
                if (((0 == cmd)&&('0' != *puart))||(cmd > 5)||((cmd>0)&&(cmd<2)))
                {
                    APP_DEBUG("\r\n<-- Error: unknown input cmd -->\r\n");
                }
                if ((FOTA_OC_STATUS_MO_DATA_ENABLED == fota_init_param.status)||  \
                    (FOTA_OC_STATUS_REGISTERED== fota_init_param.status))
                {
                    ret = ql_occloud_fota_process((QL_OCCLOULD_FOTA_CONTROL)cmd);
                    if (QL_RET_OK != ret)
                    {
                        APP_DEBUG("\r\n<-- control fota state error!,ret:%d -->\r\n",ret);
                    }
                }
                else
                {
                    APP_DEBUG("\r\n<-- fota state error! -->\r\n");
                }
            }
            else 
            {
                APP_DEBUG("\r\n<-- Error: unknown input -->\r\n");
            }                
        }
        (void)osThreadYield();    
    }         
}
#endif // __EXAMPLE_API_FOTA__
