/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_tcp_fota.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use TCP FOTA API functions communication in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_TCP__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "cerate tcp"    conmand via uart1 to create TCP port. 
*     2.Input "tcp connect"   conmand via uart1 to connect the TCP server.
*     3.Input "send data"     conmand via uart1 to send data with TCP server communication.
*     4.Input "fota init"     conmand via uart1 to initialize FOTA parameters.
*     5.Input "start upgrade" conmand via uart1 to starting FOTA upgrade.
*
* Author:
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_TCP_FOTA__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "ql_fota_iflash.h"
#include "ql_occloud_api.h"
#include "ql_string.h"
#include "example.h"

#define UART_QUEUE_LEN                  10
#define SOCK_CLOSE_RSP_LEN              12
#define QL_MAX_SENT_DATA_RSP_LEN        20
#define TCP_BUFF_MAX_SIZE               1024
#define FOTA_PACKAGE_BUFF_SIZE          512

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[50]={0};
static uint16 buf_len=0;
static uint16 sockets = 0;
static uint32 sock_len=0;

static uint32 offset = 0x00;
static uint32 g_fota_package_cnt = 0;
static uint8 g_erase_flag = 0x00;
static uint8 tcp_buff[TCP_BUFF_MAX_SIZE] __attribute((aligned (4))) = {0};

static void ql_fota_flash_erase_callback(void);
static void ql_fota_flash_write_callback(uint8 result);

typedef enum
{
    QL_MSG_TYPE_UART,
    QL_MSG_TYPE_FOTA_ERASE,
    QL_MSG_TYPE_FOTA_TCP_DATA,
    QL_MSG_TYPE_FOTA_UPGRADE,
}QL_MSG_TYPE;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    if (NULL != strstr((char*)buffer,"start upgrade"))
    {
        uart_send_to_incoming_queue_from_isr(QL_MSG_TYPE_FOTA_UPGRADE);
    }
    else
    {
        uart_send_to_incoming_queue_from_isr(QL_MSG_TYPE_UART);
    }
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void ql_socket_recv_cb(int socket, ssize_t length)
{
	APP_DEBUG("\r\n<-- socket receive callback, socket:%d,length:%d -->\r\n",socket,length);
    char ip[50] = {0};
    uint16 port = 0;
	if (length > 0)
	{   
        sockets = socket;
        sock_len = length;
        if ( sock_len < TCP_BUFF_MAX_SIZE)
        {
            uart_send_to_incoming_queue_from_isr(QL_MSG_TYPE_FOTA_TCP_DATA);
            length = 0;
        }
        else
        {
            APP_DEBUG("\r\n<-- socket recv data to large!! -->\r\n");
            while(length > 0)
            {
                ql_soc_recvfrom((uint16)sockets,tcp_buff,sizeof(tcp_buff),ip,sizeof(ip),&port);
                ql_soc_remainlen((uint16)socket,(uint32*) &length);
            }
        }
    }
}

static void ql_socket_status_callback(int sock_num, QL_SOCKET_STATUS status, int arg)
{
    switch (status)
    {
        case QL_TCP_CONNECTED:
            APP_DEBUG("Socket %d had connected\r\n", sock_num);
            break;

        case QL_TCP_SENT:
            APP_DEBUG("Socket %d had acked %d bytes\r\n", sock_num, arg);
            break;

        case QL_TCP_RECV:
            APP_DEBUG("Socket %d had recved %d bytes\r\n", sock_num, arg);
            break;

        case QL_TCP_ERR:
            APP_DEBUG("Socket %d had closed by err %d\r\n", sock_num, arg);
            break;

        case QL_TCP_CONNECTION_CLOSED:
            APP_DEBUG("Socket %d had closed by server\r\n", sock_num);
            break;

        case QL_SOCKET_CLOSE_PASSIVE:
            APP_DEBUG("Socket %d had closed by protocol stack error\r\n", sock_num);
            break;

        case QL_SOCKET_CLOSE_PROACTIVE:
            APP_DEBUG("Socket %d had closed by user\r\n", sock_num);
            break;

        case QL_SOCKET_DATA_DROPPED:
            APP_DEBUG("Socket %d dropped %d bytes data due to cache full\r\n", sock_num, arg);
            break;

        default:
            break;
    }
}

static void ql_socket_sent_callback(int sock_num, uint8 seq_num, bool data_status)
{

    char rsp_string[QL_MAX_SENT_DATA_RSP_LEN] = {0};

    if (sock_num != 0xFF)
    {
        (void)sprintf(rsp_string, "\r\n%s%d,%d,%d", "+NSOSTR:", sock_num, seq_num, (uint8)data_status);
    }
    else
    {
        (void)sprintf(rsp_string, "\r\n%s%d,%d", "+NSOSTR:", seq_num, (uint8)data_status);
    }
	APP_DEBUG(rsp_string);
}

static void ql_fota_flash_write_callback(uint8 result)
{
    if (0 == result)
    {
        APP_DEBUG("\r\n<-- FOTA flash write callback succe -->\r\n");
    }
    else
    {
        APP_DEBUG("\r\n<-- FOTA flash write callback error!! ret:%d -->\r\n",result);
    }
}

static void ql_fota_flash_erase_callback(void)
{
    g_erase_flag = 0xAA;
    APP_DEBUG("\r\n<-- FOTA flash erase callback succe -->\r\n");
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16 soc_index = 0xFFFF, autocon;
    QL_RET ql_ret = 0;
    char ip[50] = {0};
    uint16 port = 0;
    uint8 data[512] __attribute((aligned (4))) = {0};
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 open error");
    }
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disable AUTOCONNECT network and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    ql_set_cfun(1,cfun_callback);
    ql_set_cereg_callback(cereg_callback);
    if (QL_RET_OK == ql_occloud_set_registration_mode(2))
    {
        QDEBUG_TRACE("set registration mode succ");
    }
    else
    {
        QDEBUG_TRACE("set registration mode error");
    }
    
    osDelay(5000);
    
    APP_DEBUG("\r\n<-- OpenCPU: API TCP Example old -->\r\n");
    APP_DEBUG("\r\n<-- step1: create tcp -->");
    APP_DEBUG("\r\n<-- step2: tcp connect -->");
    APP_DEBUG("\r\n<-- step3: send data -->");
    APP_DEBUG("\r\n<-- step4: init fota -->");
    APP_DEBUG("\r\n<-- start upgrade -->\r\n");
    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            switch(msg)
            {
                case QL_MSG_TYPE_UART:
                {
                    APP_DEBUG("\r\n>>>>input->: %s ",uart_buf);
        			if (NULL != strstr((char*)uart_buf,"create tcp"))
        			{
        				ql_ret = ql_soc_create(&soc_index,TCP,IPV4,NULL,0,ql_socket_recv_cb);
        				if (QL_RET_OK == ql_ret)
        				{
        					 APP_DEBUG("\r\n<-- create tcp socket success, socket:%d -->\r\n",soc_index);
        					 ql_ret = ql_soc_set_callback(soc_index,ql_socket_sent_callback,ql_socket_status_callback);
        					 if(QL_RET_OK == ql_ret)
        					 {
        					 	APP_DEBUG("\r\n<-- set tcp status callback success, socket:%d -->\r\n",soc_index);
        					 }
        					 else
        					 {
        					 	APP_DEBUG("\r\n<-- set tcp status callback fail, socket:%d -->\r\n",soc_index);
        					 }
        				}
        				else 
        				{
        					APP_DEBUG("\r\n<-- create tcp socket fail, ret:%d -->\r\n",ql_ret);
        				}
        			}
        			else if (NULL != strstr((char*)uart_buf,"tcp connect"))
        			{
        				ql_ret = ql_soc_connect(soc_index, "220.180.239.212", 8069);
        				if (QL_RET_OK == ql_ret)
        				{
        					 APP_DEBUG("\r\n<-- connecting....... -->\r\n");
        				}
        				else 
        				{
        					APP_DEBUG("\r\n<--tcp connect fail, ret:%d -->\r\n",ql_ret);
        				}
        			}
        			else if (NULL != strstr((char*)uart_buf,"send data"))
        			{
        				static uint8 seq_num =0;
        				uint32 sent_len = 0;
        				char *str = "hello, I am come from tcp client!";

        				sent_len = 0;
        				
        				ql_ret = ql_soc_send_with_ind(soc_index,seq_num++,str,strlen(str),QL_SOCMSG_NORMAL,&sent_len);
        				if (QL_RET_OK == ql_ret)
        				{
        					APP_DEBUG("\r\n<-- sent tcp data success, lenght:%d -->\r\n",sent_len);
        				}
        				else 
        				{
        					APP_DEBUG("\r\n<-- sent tcp data fail, ret:%d -->\r\n",ql_ret);
        				}
        			}
                    else if (NULL != strstr((char*)uart_buf,"init fota"))
                    {
                        uint32 capacity = ql_fota_iflash_get_capacity();
                        
                        APP_DEBUG("\r\n<-- get internal flash %d byte -->\r\n",capacity);

                        if (QL_RET_OK == ql_set_cpsms(0, 0, 0))
                        {
                            APP_DEBUG("\r\n<-- disable psm mode succe -->\r\n");
                        }
                        else
                        {
                            APP_DEBUG("\r\n<-- disable psm mode error -->\r\n");
                        }
                        
                        if (true == ql_initialise_fota(ql_fota_flash_erase_callback))
                        {
                            APP_DEBUG("\r\n<-- init fota succe -->\r\n");
                        }
                        else
                        {
                            APP_DEBUG("\r\n<-- init fota error -->\r\n");
                        }
                    }
                    else
                    {
                        APP_DEBUG("\r\n<-- Error: Unknown input -->\r\n");
                    }
                    break;
                }                
                case QL_MSG_TYPE_FOTA_TCP_DATA:
                { 
                    if (0xAA == g_erase_flag)
                    {
                        memset(tcp_buff,0,sizeof(tcp_buff));
                        memset(data,0,sizeof(data));

                        ql_ret = ql_soc_recvfrom(sockets,tcp_buff,sock_len,ip,sizeof(ip),&port);         
                        osDelay(1000);
                        if (QL_RET_OK == ql_ret)
                        {   
                            if (sock_len > FOTA_PACKAGE_BUFF_SIZE)
                            {
                                uint32 remain = sock_len - FOTA_PACKAGE_BUFF_SIZE;
                                uint8 temp = remain/FOTA_PACKAGE_BUFF_SIZE;
                                
                                memcpy(data,tcp_buff,FOTA_PACKAGE_BUFF_SIZE);
                                ql_ret = ql_fota_iflash_write(data,offset,FOTA_PACKAGE_BUFF_SIZE,ql_fota_flash_write_callback); 
                                if (QL_RET_OK == ql_ret)
                                {
                                    offset += FOTA_PACKAGE_BUFF_SIZE;
                                    g_fota_package_cnt++;
                                    APP_DEBUG("\r\n<--write fota package succ,fw:%d,len:%d -->\r\n",g_fota_package_cnt,sock_len);  
                                }
                                else
                                {
                                    APP_DEBUG("\r\n<--write fota package error!! ret:%d,fw:%d,len:%d -->\r\n",ql_ret,g_fota_package_cnt,sock_len);   
                                    break;
                                }
                                APP_DEBUG("\r\n<-- temp:%d -->\r\n",temp);
                                if (0 == temp)
                                {
                                    osDelay(1000);
                                    memset(data,0,sizeof(data));
                                    memcpy(data,tcp_buff+FOTA_PACKAGE_BUFF_SIZE,remain);
                                    ql_ret = ql_fota_iflash_write(data,offset,remain,ql_fota_flash_write_callback); 
                                    if (QL_RET_OK == ql_ret)
                                    {
                                        offset += remain;
                                        g_fota_package_cnt++;
                                        APP_DEBUG("\r\n<-- write fota package succ,fw:%d,len:%d -->\r\n",g_fota_package_cnt,remain);  
                                    }
                                    else
                                    {
                                        APP_DEBUG("\r\n<-- write fota package error!! ret:%d,fw:%d,len:%d -->\r\n",ql_ret,g_fota_package_cnt,remain);   
                                    }
                                }
                                else
                                {
                                    APP_DEBUG("\r\n<-- TCP recv package error!! temp:%d",temp);
                                    break;
                                }
                            }
                            else
                            {
                                memcpy(data,tcp_buff,sock_len);
                                ql_ret = ql_fota_iflash_write(data,offset,sock_len,ql_fota_flash_write_callback); 
                                if (QL_RET_OK == ql_ret)
                                {
                                    offset += sock_len;
                                    g_fota_package_cnt++;
                                    APP_DEBUG("\r\n<-- write fota package succ,fw:%d,len:%d -->\r\n",g_fota_package_cnt,sock_len);  
                                }
                                else
                                {
                                    APP_DEBUG("\r\n<-- write fota package error!! ret:%d,fw:%d,len:%d -->\r\n",ql_ret,g_fota_package_cnt,sock_len);   
                                }
                            }
                        }
                        else
                        {
                            APP_DEBUG("\r\n<-- TCP received data error!! -->\r\n");
                        }
                    }
                    else
                    {
                        APP_DEBUG("\r\n<-- Please send <init fota> to initialize FOTA parameters first -->\r\n"); 
                        memset(data,0,sizeof(data));
                        ql_ret = ql_soc_recvfrom((uint16)sockets,data,sizeof(data),ip,sizeof(ip),&port);
                        if (QL_RET_OK == ql_ret)
                        {
                            APP_DEBUG("<-- received data from:%s:%d,flag:%d -->\r\n",ip,port,g_erase_flag);
                        }
                        else
                        {
                            APP_DEBUG("<--Error: received data fail,flag:%d -->\r\n",g_erase_flag);
                        }
                    }
                    break; 
                } 
                case QL_MSG_TYPE_FOTA_UPGRADE:
                {
                    APP_DEBUG("\r\n<-- FOTA starting upgrade-->\r\n");
                    osDelay(3000);
                    ql_ret = ql_fota_package_upgrade_req();
                    if (QL_RET_OK == ql_ret)
                    {
                        APP_DEBUG("\r\n<-- waiting fota upgrade... -->\r\n");
                    }
                    else
                    {
                        APP_DEBUG("\r\n<-- upgrade fota package error,%d -->\r\n",ql_ret);
                    }
            		break;
                }
                default:
                    APP_DEBUG("\r\n<--Error: TCP received data fail-->\r\n");
                    break;
            }       
       }
       (void)osThreadYield(); 
    }
}
#endif // __EXAMPLE_API_TCP_FOTA__
