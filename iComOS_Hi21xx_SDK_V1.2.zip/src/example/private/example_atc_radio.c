/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_atc_radio.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral  using AT COMMAND ,via virtual uart port 
*   in OpenCPU.In this example ,we use the UART1 peripheral send AT conmand to virtual uart port,then the virtual
*   uart port send the result to uart1.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_ATC_RADIO__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*     
*     Send "cmd: <type>" conmand via uart1 to execute specified command in the showed table.
*     eg. Send "cmd: 0" via uart1 to execute AT+NCONFIG? command.
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_ATC_RADIO__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "example.h"

#if  0
#define APP_ATCDBG	APP_DEBUG
#else
#define APP_ATCDBG(x,...);   
#endif

#define UART_QUEUE_LEN        21

#define ATCMD_TABLE_ITEM_MAX   sizeof(atcmd_table)/sizeof(AT_CMD)
#define ATRET_TABLE_ITEM_MAX   sizeof(atret_table)/sizeof(char*)
#define URC_TABLE_ITEM_MAX     sizeof(urc_handle_table)/sizeof(URC_HANDLER)


typedef void (*urc_handle_fn) (char *);
typedef void (*atcmd_result_fn) (uint8 ret,uint8 err);
typedef bool (*atcmd_process_fn) (char *);


typedef enum
{
    UART1_MSG  = 1,
    VUART_MSG,
} NETWORK_STEP;

typedef enum
{
	AT_PRO_IDLE,
	AT_PRO_WAIT_FOR_OK,
	AT_PRO_WAIT_FOR_PREFIX,
	AT_PRO_WAIT_FOR_PREFIX_CONTINUE,
	AT_PRO_WAIT_FOR_SUFFIX,
	AT_PRO_WAIT_FOR_SUFFIX_CONTINUE,
	AT_PRO_GOT_RESULT,
}AT_PRO_STATE;

typedef struct
{
	const char *pcmd;
    char prefix[64];     //Expected prefix
    char suffix[64];     //Expected suffix
    AT_PRO_STATE at_current;  
    uint8 is_block;
    osTimerId_t timer_id;
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
    char result[100];
    uint8 ret;
    uint8 err;
}AT_PROCESS;

typedef struct
{
    char *ptip; 
    char *pcmd;  
    uint32 timeout;    //s
    char *pprefix;     //Expected prefix
    char *psuffix;     //Expected suffix 
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
}AT_CMD;

typedef struct
{
    char *urc_str;              //urc string
    urc_handle_fn urc_handle; //urc handle
    
}URC_HANDLER;

static void atcmd_general_result_handle(uint8 ret, uint8 err);
static void atcmd_cfun_result_handle(uint8 ret, uint8 err);
static void atcmd_cgatt_result_handle(uint8 ret, uint8 err);
static bool atcmd_query_autoconnect_process_handle(char* str);
static bool atcmd_query_cereg_process_handle(char* str);
static bool atcmd_query_cscon_process_handle(char* str);
static bool atcmd_query_cgpaddr_process_handle(char* str);


static void urc_cereg_handle(char* str);
static void urc_cscon_handle(char* str);
static void urc_nipinfo_handle(char* str);
static void urc_registernotify_handle(char* str);

static osMessageQueueId_t uart_queue = NULL;

AT_CMD atcmd_table[] = {
	{"Query network switch",           "AT+NCONFIG?", 10,  "+NCONFIG:AUTOCONNECT",NULL, atcmd_query_autoconnect_process_handle,atcmd_general_result_handle},
	{"Disnable auto attach function",  "AT+NCONFIG=AUTOCONNECT,FALSE", 10, NULL,  NULL,      NULL,							atcmd_general_result_handle},
	{"Enable CFUN function",           "AT+CFUN=1",   20,  NULL,                  NULL,      NULL,							atcmd_cfun_result_handle},
	{"Enable CEREG URC reporting",	   "AT+CEREG=5",  1,   NULL,				  NULL, 	 NULL,							atcmd_general_result_handle},
	{"Enable CSCON URC reporting",	   "AT+CSCON=1",  1,   NULL,				  NULL, 	 NULL,							atcmd_general_result_handle},
	{"Enable IP address URC reporting","AT+NIPINFO=1",1,   NULL,				  NULL,      NULL,							atcmd_general_result_handle},
	{"Trigger module attached network","AT+CGATT=1",  10,  NULL,                   NULL,      NULL,							atcmd_cgatt_result_handle},
	{"Query the value of CEREG",       "AT+CEREG?",   1,   "+CEREG",              NULL,  atcmd_query_cereg_process_handle,	atcmd_general_result_handle},
	{"Query the value of CSCON",       "AT+CSCON?",   1,   "+CSCON",              NULL,  atcmd_query_cscon_process_handle,	atcmd_general_result_handle},
	{"Get the module IP address",      "AT+CGPADDR",  1,   "+CGPADDR",            NULL,  atcmd_query_cgpaddr_process_handle,atcmd_general_result_handle},
};

char *atret_table[]={
	"OK",
	"ERROR",
	"+CME ERROR:"
};

URC_HANDLER urc_handle_table[] = {
	{"+CEREG",            urc_cereg_handle},
	{"+CSCON",            urc_cscon_handle},
	{"+NIPINFO",          urc_nipinfo_handle},
	{"REGISTERNOTIFY",    urc_registernotify_handle},
};

AT_PROCESS current_atcmd = {0};

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf+1,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s,len:%d", uart_buf,len);
    uart_buf[0] = UART1_MSG;
    uart_send_to_incoming_queue_from_isr((int32)&uart_buf);
}

static void vuart_recieve_handle(uint8 * buffer, uint32 len)
{
	uint8* p = NULL;
	uint32 i = 0,j = 0;;

	p = ql_malloc(len+2);
	if (NULL == p)
	{
		APP_DEBUG("\r\n<-- Error: malloc fail!, len:%d -->\r\n",len);
		return;
	}
	memset(p,0,len+1);
	for (i = 0,j = 0; i < len; i++)
	{
		if (('\r' == buffer[i]) || ('\n' == buffer[i]))
		{
			continue;
		}
		*(p+j+1) = buffer[i];
		j++;
	}
	if (strlen((char*)(p+1)))
	{
	   	*p = VUART_MSG;
	   	uart_send_to_incoming_queue_from_isr((uint32)p);
	}
	else
	{
		ql_free(p);
	}
}

static void atcmd_send_timeout_handle(void)
{
	memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	osTimerStop(current_atcmd.timer_id);
	current_atcmd.ret = 0xff;
	current_atcmd.err = 0xff;
	current_atcmd.at_current = AT_PRO_IDLE;
	APP_DEBUG("\r\n<-- Error: cmd %s timeout! -->\r\n",current_atcmd.pcmd);
}

static int atcmd_send(const char* atcmd, char* prefix, char* suffix, uint32 timeout, atcmd_process_fn process_callback, atcmd_result_fn result_callback)
{
	
	if ((NULL == atcmd) || (AT_PRO_IDLE != current_atcmd.at_current))
	{
		return -1;
	}
	current_atcmd.pcmd = atcmd;
	if (NULL == prefix)
	{
		memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	}
	else
	{
		strcpy(current_atcmd.prefix,prefix);
	}
	
	if (NULL == suffix)
	{
		memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	}
	else
	{
		strcpy(current_atcmd.suffix,suffix);
	}

	current_atcmd.atcmd_process_callback = process_callback;
	current_atcmd.atcmd_result_callback  = result_callback;

	if (ql_uart_write(VIRTUAL_PORT,(uint8*)atcmd,strlen(atcmd))!=QL_RET_OK)
	{
		return -2;
	}
	if (NULL == strstr(atcmd,"\r\n"))
	{
		ql_uart_write(VIRTUAL_PORT,(uint8*)"\r\n",strlen("\r\n"));
	}

	
	if ((NULL == prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
	}
	else if ((NULL != prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_PREFIX;
	}
	else 
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_SUFFIX;
	}

	if (NULL == current_atcmd.timer_id)
	{
		current_atcmd.timer_id = osTimerNew((osTimerFunc_t)atcmd_send_timeout_handle, osTimerOnce, NULL, NULL);
	}

	if (timeout > 0)
	{
		osTimerStart(current_atcmd.timer_id, (uint32_t)osMs2Tick((uint64_t)timeout*1000));
		APP_ATCDBG("\r\n<-- Normal start timeout timer -->\r\n");
	}
	
	return 0;
}


static void atcmd_general_result_handle(uint8 ret, uint8 err)
{
	if (ret < 2)
	{
		APP_DEBUG("\r\n<-- at cmd %s return: %s-->\r\n",current_atcmd.pcmd,atret_table[ret]);
	}
	else
	{
		APP_DEBUG("\r\n<-- at cmd %s return error code, %s:%d-->\r\n",current_atcmd.pcmd,atret_table[ret],err);
	}
}

static void atcmd_result_process_handle(char* str)
{
	char* p = NULL;
	uint8 i = 0;
	
	if (AT_PRO_IDLE == current_atcmd.at_current)
	{
		return;
	}

	if (AT_PRO_WAIT_FOR_OK == current_atcmd.at_current)
	{
		for (i = 0; i < ATRET_TABLE_ITEM_MAX; i++)
		{
			p = strstr(str,atret_table[i]);
			if (NULL != p)
			{	
				if (0 == i)
				{
					if (osTimerIsRunning(current_atcmd.timer_id))
					{
						osTimerStop(current_atcmd.timer_id);
						APP_ATCDBG("\r\n<-- Normal stop timeout timer -->\r\n");
					}						
				}
				else
				{
					APP_DEBUG("\r\n<-- at cmd %s process fail!-->\r\n",current_atcmd.pcmd);
				}
				if (NULL != current_atcmd.atcmd_result_callback)
				{
					current_atcmd.atcmd_result_callback(i,0xff);
				}
				current_atcmd.ret = i;
				if (2 ==  i)
				{
					p += (strlen(atret_table[i])+1);
					current_atcmd.err = atoi(p);
				}
				current_atcmd.at_current = AT_PRO_IDLE;
				break;
			}
		}
	}
	else
	{
		if (NULL != current_atcmd.atcmd_process_callback)
		{
			if (AT_PRO_WAIT_FOR_PREFIX != current_atcmd.at_current)
			{
				APP_DEBUG("\r\n<-- at cmd %s  status error! -->\r\n",current_atcmd.pcmd);
				return;
			}
			if (NULL != strstr(str,":"))
			{
				current_atcmd.atcmd_process_callback(str);
			}
			else
			{
				APP_ATCDBG("\r\n<-- unexpected return value: %s-->\r\n",str);
			}
		}
		else
		{
			APP_ATCDBG("\r\n<-- no callback function found -->\r\n");
		}
	}
}

static void atcmd_cfun_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	if (0 == ret)
	{
		APP_DEBUG("\r\n<-- cfun success-->\r\n");
		APP_DEBUG("\r\n<-- you can enable URC report of CEREG and CSCON-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cfun fail-->\r\n");
	}
}

static void atcmd_cgatt_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	if (0 == ret)
	{
		APP_DEBUG("\r\n<-- cgatt success-->\r\n");
		APP_DEBUG("\r\n<-- you can get the module address-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cgatt fail-->\r\n");
	}
}

static bool atcmd_query_autoconnect_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/autoconnect:%s -->\r\n",p);
	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;
}

static bool atcmd_query_cereg_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/cerg:%s -->\r\n",p);
	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;

}

static bool atcmd_query_cscon_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/cscon:%s -->\r\n",p);
	
	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;

}
static bool atcmd_query_cgpaddr_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/cgpaddr:%s -->\r\n",p);

	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;
}

static void urc_process_handle(char* str)
{
	uint8 i = 0;
	char* p = NULL;
	
	for(i = 0; i < URC_TABLE_ITEM_MAX; i++)
	{
		p = strstr(str,urc_handle_table[i].urc_str);	
		if (NULL != p)
		{
			urc_handle_table[i].urc_handle(str);
			break;
		}
	}
}

static void urc_cereg_handle(char* str)
{

	APP_DEBUG("\r\n<-- urc/cerg:%s -->\r\n",str);
}

static void urc_cscon_handle(char* str)
{
	APP_DEBUG("\r\n<-- urc/cscon:%s -->\r\n",str);
}

static void urc_nipinfo_handle(char* str)
{
	UNUSED(str);
	APP_DEBUG("\r\n<-- urc/ip report:%s -->\r\n",str);
}

static void urc_registernotify_handle(char* str)
{
	UNUSED(str);
	APP_DEBUG("\r\n<-- urc/registernotify:%s -->\r\n",str);
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0, i =0;
    uint8* pmsg = NULL;

	ql_wait_for_at_init();  //ike 20190524 wait for modem ok
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    enable_virtual_port();
    ql_uart_init(VIRTUAL_PORT);
    ql_uart_open(VIRTUAL_PORT, &uart1_config, vuart_recieve_handle);

    APP_DEBUG("\r\n<-- OpenCPU: ATC radio Example -->\r\n");
    APP_DEBUG("\r\n<-- Command format,cmd:0~%d-->\r\n",ATCMD_TABLE_ITEM_MAX-1);
	for (i = 0; i < ATCMD_TABLE_ITEM_MAX; i++)
	{
		APP_DEBUG("<--cmd type %d.%s-->\r\n",i,atcmd_table[i].ptip);
	}

    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
       	pmsg = (uint8*)msg;
		switch(*pmsg)
		{
			case UART1_MSG:
				{
					char* p = NULL;
					uint8 cmd = 0xFF;
					int ret = 0;
					
					pmsg++;
					p = strstr((char*)pmsg,"cmd:");
					if(NULL == p)
					{
					    APP_DEBUG("\r\n<-- Unrecognized command -->\r\n");
					    break;
					}
					p += 4;
					if((*p < '0') || (*p > '9'))
					{
					    APP_DEBUG("\r\n<-- Unrecognized command -->\r\n");
					    break;
					}
					cmd = atoi(p);
					APP_DEBUG("\r\n<-- run at cmd type:%d -->\r\n",cmd);
					if ((NULL != p) && (cmd < ATCMD_TABLE_ITEM_MAX))
					{
						ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,
										atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
										
						APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
					}
					else
					{
						APP_DEBUG("\r\n<-- at cmd process fail-->\r\n");
					}
				
				}
				break;
			case VUART_MSG:
			{
				pmsg++;
				APP_ATCDBG("\r\n<-- process handle string:%s  -->\r\n",pmsg);
				atcmd_result_process_handle((char*)pmsg);
				if (AT_PRO_IDLE == current_atcmd.at_current)
				{
					urc_process_handle((char*)pmsg);
				}

				pmsg = (uint8*)msg;
				ql_free(pmsg);
			}	
				break;
			default:
				APP_DEBUG("\r\n<-- Error: unknown msg type,type:%d  -->\r\n",*pmsg);
				break;
		}
       }
       (void)osThreadYield(); 
    }

}
#endif // __EXAMPLE_ATC_PIPE__