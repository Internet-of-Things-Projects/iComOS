/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_atc_tcp.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral  using AT COMMAND ,via virtual uart port 
*   in OpenCPU.In this example ,we use the UART1 peripheral send AT conmand to virtual uart port,then the virtual
*   uart port send the result to uart1;you can direct use this example to develop;
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_ATC_TCP__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*     1.Input "tcp init"      conmand via uart1 to initialization module related configuration. 
*     2.Input "create tcp"    conmand via uart1 to create TCP port. 
*     3.Input "connect tcp"   conmand via uart1 to connect TCP server.
*     4.Input "send data"     conmand via uart1 to send data with TCP server communication.
*	
*
* Author: Ike.Zeng
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_ATC_TCP__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "example.h"

#if  0
#define APP_ATCDBG	APP_DEBUG
#else
#define APP_ATCDBG(x,...);   
#endif

#define UART_QUEUE_LEN          30

#define ATCMD_TABLE_ITEM_MAX    sizeof(atcmd_table)/sizeof(AT_CMD)
#define ATRET_TABLE_ITEM_MAX    sizeof(atret_table)/sizeof(char*)
#define URC_TABLE_ITEM_MAX      sizeof(urc_handle_table)/sizeof(URC_HANDLER)


typedef void (*urc_handle_fn) (char *);
typedef bool (*atcmd_process_fn) (char *);
typedef void (*atcmd_result_fn) (uint8 ret,uint8 err);

typedef enum
{
    TCP_STATE_INIT_START,
	TCP_STATE_REGISTRATION_ENABLED,
	TCP_STATE_REGISTRATION_DISABLED,
	TCP_STATE_INIT_WAITING_AUTOCONNECT_DISABLED,
	TCP_STATE_INIT_AUTOCONNECT_DISABLED,
	TCP_STATE_INIT_AUTOCONNECT_ENABLED,
	TCP_STATE_INIT_AUTOCONNECT_TO_DISABLED,
    TCP_STATE_INIT_NRB,
    TCP_STATE_INIT_CFUN_OK,
    TCP_STATE_INIT_CGATT_OK,
    TCP_STATE_INIT_CGPADDR_OK,
    TCP_STATE_INITED,
    TCP_STATE_CREATED_SOCKET,
    TCP_STATE_CONNECTED,
    TCP_STATE_NONE,
} tcp_STATE;

typedef enum
{
	TCP_INIT = 0,
    CREATE_TCP,
    CONNECT_TCP,
    SEND_DATA,                
    VUART_MSG,
} TCP_STEP;

typedef enum
{
	AT_PRO_IDLE,
	AT_PRO_WAIT_FOR_OK,
	AT_PRO_WAIT_FOR_PREFIX,
	AT_PRO_WAIT_FOR_PREFIX_CONTINUE,
	AT_PRO_WAIT_FOR_SUFFIX,
	AT_PRO_WAIT_FOR_SUFFIX_CONTINUE,
	AT_PRO_GOT_RESULT,
}AT_PRO_STATE;

typedef struct
{
	const char *pcmd;
    char prefix[64];     //Expected prefix
    char suffix[64];     //Expected suffix
    AT_PRO_STATE at_current;  
    uint8 is_block;
    osTimerId_t timer_id;
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
}AT_PROCESS;

typedef struct
{
    char *ptip; 
    char *pcmd;  
    uint32 timeout;     //s
    char *pprefix;     //Expected prefix
    char *psuffix;     //Expected suffix 
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;//atcmd_result_callback
}AT_CMD;

typedef struct
{
    char *urc_str;           //urc string
    urc_handle_fn urc_handle; //urc handle
    
}URC_HANDLER;

char *atret_table[]={
	"OK",
	"ERROR",
	"+CME ERROR:"
};

typedef enum
{
	AT_OK,
	AT_ERROR,
	AT_CME_ERROR,
	AT_NONE,

}AT_RET;

static void atcmd_nconfig_result_handle(uint8 ret, uint8 err);
static void atcmd_disable_autoconnect_result_handle(uint8 ret, uint8 err);
static bool atcmd_query_autoconnect_process_handle(char* str);
static void atcmd_general_result_handle(uint8 ret, uint8 err);
static void urc_registernotify_handle(char* str);
static void urc_tcp_nnmi_handle(char* str);
static void urc_tcp_socket_close(char* str);
static void atcmd_cgatt_result_handle(uint8 ret, uint8 err);
static void atcmd_cfun_result_handle(uint8 ret, uint8 err);
static bool atcmd_query_nsocr_process_handle(char* str);
static bool atcmd_query_cgpaddr_process_handle(char* str);
static void atcmd_cgpaddr_result_handle(uint8 ret, uint8 err);
static bool atcmd_query_qregswt_process_handle(char* str);
static void atcmd_nsocr_result_handle(uint8 ret, uint8 err);
static void atcmd_nsoco_result_handle(uint8 ret, uint8 err);
static void atcmd_qregswt_result_handle(uint8 ret, uint8 err);
static void atcmd_disable_qregswt_result_handle(uint8 ret, uint8 err);

static osMessageQueueId_t uart_queue = NULL;
AT_CMD atcmd_table[] = {
	{"Query UE config",					"AT+NCONFIG?", 						5, 	"+NCONFIG:AUTOCONNECT",	NULL,	atcmd_query_autoconnect_process_handle,	atcmd_nconfig_result_handle},
    {"Disnable auto attach function",	"AT+NCONFIG=AUTOCONNECT,FALSE",		10,	NULL,  					NULL, 	NULL,									atcmd_disable_autoconnect_result_handle},
    {"Reboot the UE",					"AT+NRB",   						2,	NULL,  					NULL,	NULL,									atcmd_general_result_handle},
    {"Enable CFUN function",			"AT+CFUN=1", 						10,	NULL,  					NULL,	NULL,									atcmd_cfun_result_handle},
    {"Trigger module attached network",	"AT+CGATT=1",  						2,	NULL,  					NULL,	NULL,									atcmd_cgatt_result_handle},
    {"Show PDP addresses",				"AT+CGPADDR",  						1,	"+CGPADDR:", 			NULL,	atcmd_query_cgpaddr_process_handle, 	atcmd_cgpaddr_result_handle},
    {"Create TCP socket",				"AT+NSOCR=STREAM,6,0",				10,	"0123456",  			NULL,	atcmd_query_nsocr_process_handle,		atcmd_nsocr_result_handle},
    {"Connnect TCP server",				"AT+NSOCO=x,220.180.239.212,8052",	10,	NULL,  					NULL, 	NULL,									atcmd_nsoco_result_handle},
    {"Send data to TCP server",			"AT+NSOSD=x,5,3031323334",			20,	NULL,  					NULL,	NULL,									atcmd_general_result_handle},
    {"Query Registration mode",			"AT+QREGSWT?",						2,	"+QREGSWT:", 			NULL,	atcmd_query_qregswt_process_handle,		atcmd_qregswt_result_handle},
    {"Disnable Registration",			"AT+QREGSWT=2",						2,	NULL,					NULL,	NULL,									atcmd_disable_qregswt_result_handle},
};  

URC_HANDLER urc_handle_table[] = {
    {"REGISTERNOTIFY",    urc_registernotify_handle},
    {"+NNMI",             urc_tcp_nnmi_handle},
    {"+NSOCLI",           urc_tcp_socket_close},
};

AT_PROCESS current_atcmd = {0};
static uint8 stateFlag = TCP_STATE_NONE;
static uint8 uart_buf[255]={0};
static uint16 buf_len=0;
static uint16 socket_index = 0;
static char tmp_pcmd[128] = {0};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
    uint8* msg = NULL;
    
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s,len:%d", uart_buf,len);
    if (NULL != strstr((char*)uart_buf,"tcp init"))
    {
        msg = ql_malloc(1);
        memset(msg,0,1);
        *msg = TCP_INIT;
        uart_send_to_incoming_queue_from_isr((uint32)msg);
        return;
    }
	else if (NULL != strstr((char*)uart_buf,"create tcp"))
    {
        msg = ql_malloc(1);
        memset(msg,0,1);
        *msg = CREATE_TCP;
        uart_send_to_incoming_queue_from_isr((uint32)msg);
        return;
    }
	else if (NULL != strstr((char*)uart_buf,"connect tcp"))
    {
        msg = ql_malloc(1);
        memset(msg,0,1);
        *msg = CONNECT_TCP;
        uart_send_to_incoming_queue_from_isr((uint32)msg);
        return;
    }
    else if (NULL != strstr((char*)uart_buf,"send data"))
    {
        msg = ql_malloc(1);
        memset(msg,0,1);
        *msg = SEND_DATA;
        uart_send_to_incoming_queue_from_isr((uint32)msg);
        return;
    }
    else
    {
        APP_DEBUG("\r\n<-- Error: input command failed! uart_buf=%s -->\r\n",uart_buf);
        return;
    }
}

static void vuart_recieve_handle(uint8 * buffer, uint32 len)
{
	uint8* p = NULL;
	uint32 i = 0,j = 0;;

	p = ql_malloc(len+2);
	if (NULL == p)
	{
		APP_DEBUG("\r\n<-- Error: malloc failed!, len:%d -->\r\n",len);
		return;
	}
	memset(p,0,len+1);
	for (i = 0,j = 0; i < len; i++)
	{
		if (('\r' == buffer[i]) || ('\n' == buffer[i]))
		{
			continue;
		}
		*(p+j+1) = buffer[i];
		j++;
	}
	if (strlen((char*)(p+1)))
	{
	   	*p = VUART_MSG;
	   	uart_send_to_incoming_queue_from_isr((uint32)p);
	}
	else
	{
		ql_free(p);
	}
}

static void atcmd_send_timeout_handle(void)
{
	memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	osTimerStop(current_atcmd.timer_id);
	current_atcmd.at_current = AT_PRO_IDLE;
	APP_DEBUG("\r\n<-- Error: cmd %s timeout! -->\r\n",current_atcmd.pcmd);
}

static int atcmd_send(const char* atcmd, char* prefix, char* suffix, uint32 timeout, atcmd_process_fn process_callback, atcmd_result_fn result_callback)
{
	
	if ((NULL == atcmd) || (AT_PRO_IDLE != current_atcmd.at_current))
	{
        APP_DEBUG("\r\n Don't operation at_current:%d\r\n", current_atcmd.at_current);
		return -1;
	}
	current_atcmd.pcmd = atcmd;
	if (NULL == prefix)
	{
		memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	}
	else
	{
		strcpy(current_atcmd.prefix,prefix);
	}
	
	if (NULL == suffix)
	{
		memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	}
	else
	{
		strcpy(current_atcmd.suffix,suffix);
	}

	current_atcmd.atcmd_process_callback = process_callback;
	current_atcmd.atcmd_result_callback  = result_callback;

	if (ql_uart_write(VIRTUAL_PORT,(uint8*)atcmd,strlen(atcmd))!=QL_RET_OK)
	{
		return -2;
	}
	if (NULL == strstr(atcmd,"\r\n"))
	{
		ql_uart_write(VIRTUAL_PORT,(uint8*)"\r\n",strlen("\r\n"));
	}

	
	if ((NULL == prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
	}
	else if ((NULL != prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_PREFIX;
	}
	else 
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_SUFFIX;
	}

	if (NULL == current_atcmd.timer_id)
	{
		current_atcmd.timer_id = osTimerNew((osTimerFunc_t)atcmd_send_timeout_handle, osTimerOnce, NULL, NULL);
	}
    osTimerStart(current_atcmd.timer_id, (uint32_t)osMs2Tick((uint64_t)timeout*1000));
    APP_ATCDBG("\r\n<-- Normal start timeout timer -->\r\n");
	return 0;
}

static void atcmd_general_result_handle(uint8 ret, uint8 err)
{
	if (ret < 2)
	{
		APP_DEBUG("\r\n<-- at cmd %s return: %s-->\r\n",current_atcmd.pcmd,atret_table[ret]);
	}
	else
	{
		APP_DEBUG("\r\n<-- at cmd %s return error code, %s:%d-->\r\n",current_atcmd.pcmd,atret_table[ret],err);
	}
}

static void atcmd_result_process_handle(char* str)
{
	char* p = NULL;
	uint8 i = 0;
	
	if (AT_PRO_IDLE == current_atcmd.at_current)
	{
		return;
	}

	if (AT_PRO_WAIT_FOR_OK != current_atcmd.at_current)
	{
		if (NULL != current_atcmd.atcmd_process_callback)
		{
			if (AT_PRO_WAIT_FOR_PREFIX != current_atcmd.at_current)
			{
				APP_DEBUG("\r\n<-- at cmd %s  status error! -->\r\n",current_atcmd.pcmd);
				return;
			}
			current_atcmd.atcmd_process_callback(str);

		}
		else
		{
			APP_ATCDBG("\r\n<-- no callback function found -->\r\n");
		}
	}

	if (AT_PRO_IDLE != current_atcmd.at_current)
	{
		for (i = 0; i < ATRET_TABLE_ITEM_MAX; i++)
		{
			p = strstr(str,atret_table[i]);
			if (NULL != p)
			{	
				if (AT_OK == i)
				{
					if (osTimerIsRunning(current_atcmd.timer_id))
					{
						osTimerStop(current_atcmd.timer_id);
						APP_ATCDBG("\r\n<-- Normal stop timeout timer -->\r\n");
					}						
					APP_ATCDBG("\r\n<-- at cmd %s process success!-->\r\n",current_atcmd.pcmd);
				}
				else
				{
					APP_ATCDBG("\r\n<-- at cmd %s process fail!-->\r\n",current_atcmd.pcmd);
				}
                current_atcmd.at_current = AT_PRO_IDLE;
				current_atcmd.atcmd_result_callback(i,0xff);	
				break;
			}
		}
	}
}

static void urc_process_handle(char* str)
{
	uint8 i = 0;
	char* p = NULL;
	for(i = 0; i < URC_TABLE_ITEM_MAX; i++)
	{
		p = strstr(str,urc_handle_table[i].urc_str);	
		if (NULL != p)
		{
			urc_handle_table[i].urc_handle(str);
			break;
		}
	}
}

static void urc_tcp_nnmi_handle(char* str)
{
	UNUSED(str);
	APP_DEBUG("\r\n<-- urc/recv:%s -->\r\n",str);
}

static void urc_tcp_socket_close(char* str)
{
	UNUSED(str);
	APP_DEBUG("\r\n<-- urc/socket close:%s -->\r\n",str);
	stateFlag = TCP_STATE_INITED;
}

static void urc_registernotify_handle(char* str)
{
	UNUSED(str);
	APP_DEBUG("\r\n<-- urc/registernotify:%s -->\r\n",str);
}

static bool atcmd_query_autoconnect_process_handle(char* str)
{
	char* p = NULL;
	int32 ret;
	UNUSED(p);
	
	p = strstr(str, current_atcmd.prefix);
	if(NULL != p) // ike, 20190527, Compatible echo mode ON(ATE1)
	{
		APP_ATCDBG("\r\n<-- atcmd/autoconnect:%s -->\r\n", p);
		p += strlen(current_atcmd.prefix);
		ret = strncmp(p, ",FALSE", 6);
		if(0 == ret)
		{
			stateFlag = TCP_STATE_INIT_AUTOCONNECT_DISABLED;
		}
		else
		{
			stateFlag = TCP_STATE_INIT_AUTOCONNECT_ENABLED;
		}
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;  // ike, 20190527, Compatible echo mode ON(ATE1)
	}
	return true;
}

static bool atcmd_query_nsocr_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	uint8 i;
	int ret;
	for(i = 0; i < strlen(current_atcmd.prefix); i++)
	{
		ret = strncmp(str, &current_atcmd.prefix[i], 1);
		if(0 == ret)
		{
			socket_index = i;
			break;
		}
	}
	if(i < strlen(current_atcmd.prefix))
	{
		APP_DEBUG("\r\n<-- socket index:%d -->\r\n",i);
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;  // ike, 20190527, Compatible echo mode ON(ATE1)
	}

    return true;
}

static bool atcmd_query_cgpaddr_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	
	if(NULL != p)// ike, 20190531, Prevent accidents from causing pointers to be non-empty
	{
		APP_ATCDBG("\r\n<-- atcmd/cgpaddr:%s,%d -->\r\n",p,*(p+9));
        if (*(p+11) !='0')
        {
             stateFlag = TCP_STATE_INIT_CGPADDR_OK;
        }

		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
    return true;
}

static bool atcmd_query_qregswt_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	
	if(NULL != p)// ike, 20190531, Prevent accidents from causing pointers to be non-empty
	{
		APP_ATCDBG("\r\n<-- atcmd/qregswt:%s -->\r\n", p);
        if (*(p+9) == '2')
        {
             stateFlag = TCP_STATE_REGISTRATION_DISABLED;
        }

		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
    return true;
}

static void atcmd_nconfig_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	uint8 cmd;
 
	if (0 == ret)
	{
		if(TCP_STATE_INIT_AUTOCONNECT_ENABLED == stateFlag)
		{
			stateFlag = TCP_STATE_INIT_AUTOCONNECT_TO_DISABLED;
			APP_DEBUG("\r\n<--  To disable AUTOCONNECT network -->\r\n");
			cmd = 1;
			/* AT+NCONFIG=AUTOCONNECT,FALSE */
			ret = atcmd_send(atcmd_table[cmd].pcmd, atcmd_table[cmd].pprefix, atcmd_table[cmd].psuffix, atcmd_table[cmd].timeout, \
                        atcmd_table[cmd].atcmd_process_callback, atcmd_table[cmd].atcmd_result_callback);
			APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, ret);
			if (QL_RET_OK != ret)
        	{
            	APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, ret);
        	}
		}
	}
	else
	{
		APP_ATCDBG("\r\n<--Error: nconfig failed-->\r\n");
	}
}

static void atcmd_disable_autoconnect_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	uint8 cmd;
 
	if (0 == ret)
	{
		if(TCP_STATE_INIT_AUTOCONNECT_TO_DISABLED == stateFlag)
		{
			APP_DEBUG("\r\n<-- To Reboot -->\r\n");
			cmd = 2;
			/* AT+NRB */
			ret = atcmd_send(atcmd_table[cmd].pcmd, atcmd_table[cmd].pprefix, atcmd_table[cmd].psuffix, atcmd_table[cmd].timeout, \
                        atcmd_table[cmd].atcmd_process_callback, atcmd_table[cmd].atcmd_result_callback);
			APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, ret);
			if (QL_RET_OK != ret)
        	{
            	APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, ret);
        	}
		}
	}
	else
	{
		APP_ATCDBG("\r\n<--Error: nconfig failed-->\r\n");
	}
}

static void atcmd_cfun_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
    QL_RET ql_ret;
	uint8 cmd = 0x04;
	if (0 == ret)
	{
		stateFlag = TCP_STATE_INIT_CFUN_OK;
		APP_DEBUG("\r\n<-- AT+CFUN=1 succeeded-->\r\n");
        /* AT+CGATT=1 */
        ql_ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	    APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ql_ret);

        if (ql_ret != QL_RET_OK)
        {
            APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ql_ret);
        }	
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cfun failed-->\r\n");
	}
}

static void atcmd_cgatt_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
 
	if (0 == ret)
	{
		stateFlag = TCP_STATE_INIT_CGATT_OK;
	    APP_DEBUG("\r\n<-- AT+CGATT=1 succeeded -->\r\n");
		uint8 cmd = 5;
		/* AT+CGPADDR */
		ret = atcmd_send(atcmd_table[cmd].pcmd, atcmd_table[cmd].pprefix, atcmd_table[cmd].psuffix, atcmd_table[cmd].timeout, \
                        atcmd_table[cmd].atcmd_process_callback, atcmd_table[cmd].atcmd_result_callback);
		APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, ret);

        if (QL_RET_OK != ret)
        {
            APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, ret);
        }
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cgatt failed-->\r\n");
	}
}

static void atcmd_cgpaddr_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
 
	if (0 == ret)
	{
		if(stateFlag <= TCP_STATE_INIT_CGPADDR_OK)
		{
			stateFlag = TCP_STATE_INITED;
		}
		APP_DEBUG("\r\n<-- TCP init OK -->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cgpaddr failed-->\r\n");
	}
}

static void atcmd_nsocr_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
 
	if (0 == ret)
	{
		if(stateFlag <= TCP_STATE_INITED)
		{
			stateFlag = TCP_STATE_CREATED_SOCKET;
		}
		APP_DEBUG("\r\n<-- Create socket succeeded -->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- Create socket failed -->\r\n");
	}
}

static void atcmd_nsoco_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
 
	if (0 == ret)
	{
		if(stateFlag <= TCP_STATE_CREATED_SOCKET)
		{
			stateFlag = TCP_STATE_CONNECTED;
		}
		APP_DEBUG("\r\n<-- Connect tcp server succeeded -->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- Connect tcp server failed -->\r\n");
	}
}

static void atcmd_qregswt_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	int32 tmp_ret;

	if((TCP_STATE_REGISTRATION_DISABLED == stateFlag) || (AT_OK != ret))
	{
		uint8 cmd = 0x00;
		APP_ATCDBG("\r\n<-- Registration Disabled -->\r\n");
		stateFlag = TCP_STATE_INIT_WAITING_AUTOCONNECT_DISABLED;
	    /* AT+NCONFIG? */
	    tmp_ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
	                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
		APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, tmp_ret);

    	if (QL_RET_OK != tmp_ret)
    	{
        	APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, tmp_ret);
    	}
	}
	else if((AT_OK == ret) && (TCP_STATE_REGISTRATION_DISABLED != stateFlag))
	{
		uint8 cmd = 0x0A; // Ike, 2019/05/28, Subscript error fix
		APP_DEBUG("\r\n<-- Registration ENABLED -->\r\n");
		stateFlag = TCP_STATE_REGISTRATION_ENABLED;
	    /* AT+QREGSWT=2 */
	    tmp_ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
	                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
		APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, tmp_ret);

    	if (QL_RET_OK != tmp_ret)
    	{
        	APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, tmp_ret);
    	}
	}
}

static void atcmd_disable_qregswt_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	int32 tmp_ret;
 
	if (0 == ret)
	{
		uint8 cmd = 0x02;
		stateFlag = TCP_STATE_REGISTRATION_DISABLED;
		APP_DEBUG("\r\n<-- To Reboot -->\r\n");
		/* AT+NRB */
		tmp_ret = atcmd_send(atcmd_table[cmd].pcmd, atcmd_table[cmd].pprefix, atcmd_table[cmd].psuffix, atcmd_table[cmd].timeout, \
                       atcmd_table[cmd].atcmd_process_callback, atcmd_table[cmd].atcmd_result_callback);
		APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n", atcmd_table[cmd].pcmd, tmp_ret);
		if (QL_RET_OK != tmp_ret)
        {
            APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd, tmp_ret);
        }
	}
	else
	{
		APP_DEBUG("\r\n<--Error: disable qregswt failed -->\r\n");
	}
}

static QL_RET close_autocommect_registration(void)
{
	QL_RET ret;   
	uint8 cmd = 0x09;
	stateFlag = TCP_STATE_INIT_START;
    /* AT+QREGSWT? */
    ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);

    if (ret != QL_RET_OK)
    {
        APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
    }
	return ret;
}

static QL_RET tcp_init(void)
{
    QL_RET ret;   
	uint8 cmd = 0x03;
	if(TCP_STATE_INIT_AUTOCONNECT_DISABLED != stateFlag)
	{
		return QL_RET_ERR_NO_INIT;
	}
	/* AT+CFUN=1 */
	ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	APP_ATCDBG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);

    if (ret != QL_RET_OK)
    {
        APP_ATCDBG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
    }
    return ret;
}


static QL_RET tcp_create(void)
{
    QL_RET ret;
	uint8 cmd = 0x06;
	if (stateFlag < TCP_STATE_INITED)
    {
        APP_DEBUG("\r\n<-- Please init first -->\r\n");
        return QL_RET_ERR_PARAM_UNCONFIG; 
    }
    /* AT+NSOCR=STREAM,6,0 */
    ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);

    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
    }
    return ret;
}

static QL_RET connect_tcp(void)
{
    if (stateFlag < TCP_STATE_CREATED_SOCKET)
    {
        APP_DEBUG("\r\n<-- Please create an socket first -->\r\n");
        return QL_RET_ERR_PARAM_UNCONFIG; 
    }

    QL_RET ret;
	uint8 cmd = 0x07;
    /* AT+NSOCO=x,220.180.239.212,8052 */
	memset(tmp_pcmd, 0, sizeof(tmp_pcmd));
	memcpy(tmp_pcmd, atcmd_table[cmd].pcmd, strlen(atcmd_table[cmd].pcmd));
	tmp_pcmd[9] = socket_index + '0';
    ret = atcmd_send(tmp_pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",tmp_pcmd,ret);

    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",tmp_pcmd,ret);
    }
    return ret;
    return QL_RET_OK; 
}

static QL_RET tcp_send_data(void)
{
    QL_RET ret;
	uint8 cmd = 0x08;
	if(stateFlag < TCP_STATE_CONNECTED)
	{
		APP_DEBUG("\r\n<-- Please connect tcp server first -->\r\n");
		return QL_RET_ERR_PARAM_UNCONFIG;
	}
    /* AT+NSOSD=x,5,3031323334 */
	memset(tmp_pcmd, 0, sizeof(tmp_pcmd));
	memcpy(tmp_pcmd, atcmd_table[cmd].pcmd, strlen(atcmd_table[cmd].pcmd));
	tmp_pcmd[9] = socket_index + '0';
    ret = atcmd_send(tmp_pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,\
                        atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
	APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",tmp_pcmd,ret);

    if (ret != QL_RET_OK)
    {
        APP_DEBUG("\r\n<-- at cmd sent:%s, ERROR, ret:%d  -->\r\n",tmp_pcmd,ret);
    }
    return ret;
    return QL_RET_OK; 
}


/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    (void) unused;
    ql_uart_config uart1_config;
    uint32 msg = 0, i =0;
    uint8* pmsg = NULL;
    QL_RET ret  = 0;
    osDelay(1000);
   
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    enable_virtual_port();
    ql_uart_init(VIRTUAL_PORT);
    ql_uart_open(VIRTUAL_PORT, &uart1_config, vuart_recieve_handle);

	close_autocommect_registration();
    APP_DEBUG("\r\n<-- OpenCPU: ATC TCP Example -->\r\n");
    APP_DEBUG("\r\n<-- Command format,cmd:0~%d-->\r\n",ATCMD_TABLE_ITEM_MAX-1);
	for (i = 0; i < ATCMD_TABLE_ITEM_MAX; i++)
	{
		APP_DEBUG("<-- Command %s. %s-->\r\n",atcmd_table[i].ptip,atcmd_table[i].pcmd);
	}

	APP_DEBUG("<-- step1: tcp init -->\r\n");
    APP_DEBUG("<-- step2: create tcp -->\r\n");
	APP_DEBUG("<-- step3: connect tcp -->\r\n");
    APP_DEBUG("<-- step4: send data -->\r\n");
    
    for(;;)
    {
        if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
        {
            pmsg = (uint8*)msg;
            APP_ATCDBG("\r\n>>>>input:  msg:%d \r\n",*pmsg);
            switch(*pmsg)
            {
            	case TCP_INIT:
                    ret = tcp_init();
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("\r\n<-- tcp init failed, ret=%d -->\r\n", ret);
                    }
                    ql_free(pmsg);	
                    break;
                case CREATE_TCP:
                    ret = tcp_create();
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<--Error: create tcp socket failed, ret:%d -->\r\n", ret);
                    }
                    ql_free(pmsg);	
                    break;
				case CONNECT_TCP:
                    ret = connect_tcp();
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("<--Error: connect tcp server failed, ret:%d -->\r\n", ret);
                    }
                    ql_free(pmsg);	
                    break;
                case SEND_DATA:
                    ret = tcp_send_data();
                    if (ret != QL_RET_OK)
                    {
                        APP_DEBUG("\r\n<-- tcp send failed, ret=%d -->\r\n",ret);
                    }
                    ql_free(pmsg);	
                    break;
    			case VUART_MSG:
    				pmsg++;
    				APP_ATCDBG("\r\n<-- process handle string:%s, state=%d -->\r\n",pmsg,current_atcmd.at_current);
    				atcmd_result_process_handle((char*)pmsg);
    				if (AT_PRO_IDLE == current_atcmd.at_current)
    				{
    					urc_process_handle((char*)pmsg);
    				}
    				pmsg = (uint8*)msg;
    				ql_free(pmsg);	
    				break;
    			default:
    				APP_DEBUG("\r\n<-- Error: unknown msg type,type:%x  -->\r\n",*pmsg);
    				break;             
            }
       }
       (void)osThreadYield(); 
    }
}
#endif // __EXAMPLE_ATC_TCP__