/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_operator_registration.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to configure operator registration function.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_OPERATOR_REG__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*     
*     Send "cmd: <type>" command via uart1 to execute specified command in the showed table.
*     eg. Send "cmd2" via uart1 to read all operator registration parameters.
*
* Author: Gary.Tang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_OPERATOR_REG__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "example.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_operator_registration.h"

#if  0
#define APP_ATCDBG	APP_DEBUG
#else
#define APP_ATCDBG(x,...);   
#endif

#define UART_QUEUE_LEN        21

typedef enum
{
    UART1_MSG  = 1,
    VUART_MSG,
} NETWORK_STEP;


static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len = 0;


static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf+1,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s,len:%d", uart_buf,len);
    uart_buf[0] = UART1_MSG;
    uart_send_to_incoming_queue_from_isr((int32)&uart_buf);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}

static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void show_all_reg_configuration(void)
{
	APP_DEBUG("\r\n<-- show reg configuration-->\r\n");
    bool ct_reg_mode = true;
    bool cu_reg_mode = true;
    bool cm_reg_mode = true;
    uint32 period = 0;
    QL_DMP_ADDR cm_dmp_addr ;
    QL_DMP_ONFO cm_dmp_info ;
    memset(&cm_dmp_addr,0,sizeof(QL_DMP_ADDR));
    memset(&cm_dmp_info,0,sizeof(QL_DMP_ONFO));
    
    ct_reg_mode = ql_get_chinatelcom_sreg_mode();
    cu_reg_mode = ql_get_chinaunicom_sreg_mode();
    APP_DEBUG("\r\n<-- ChinaTelcom Registration mode:%d-->\r\n",ct_reg_mode);
    APP_DEBUG("\r\n<-- ChinaUnicom Registration mode:%d-->\r\n",cu_reg_mode);
    if(QL_RET_OK != ql_get_chinaunicom_sreg_period(&period))
    {
        APP_DEBUG("\r\n<-- error:get ChinaUnicom sreg period-->\r\n");
    }
    APP_DEBUG("\r\n<-- ChinaUnicom Registration Period:%d-->\r\n",period);

    if(QL_RET_ERR_NOT_SUPPORT ==ql_get_chinamobile_dm_mode(&cm_reg_mode))
    {
        APP_DEBUG("\r\n<-- Not support ChinaMobile Registraion -->\r\n");
        return;
    }
    APP_DEBUG("\r\n<-- ChinaMobile Registration mode:%d -->\r\n",cm_reg_mode);

    if(QL_RET_OK == ql_get_chinamobile_dm_configuration(&cm_dmp_addr,&cm_dmp_info))
    {
        APP_DEBUG("\r\n<-- DM Server Address:%s,%d -->\r\n",cm_dmp_addr.host,cm_dmp_addr.port);
        if(QL_DMP_TYPE_INTERFACE == cm_dmp_info.interface_type)
        {
            APP_DEBUG("\r\n<-- DM Device Platform Type:Interface -->\r\n");
        }
        else if(QL_DMP_TYPE_LINUX == cm_dmp_info.interface_type)
        {
            APP_DEBUG("\r\n<-- DM Device Platform Type:Linux -->\r\n");
        }
        else if(QL_DMP_TYPE_LINUX == cm_dmp_info.interface_type)
        {
            APP_DEBUG("\r\n<-- DM Device Platform Type:Android -->\r\n");
        }
        else
        {
            APP_DEBUG("\r\n<-- DM Device Platform Type:Unknown -->\r\n");
        }
        
        APP_DEBUG("\r\n<-- DM Update Period:%d -->\r\n",cm_dmp_info.updatePeriod);
        APP_DEBUG("\r\n<-- DM Appkey:%s -->\r\n",cm_dmp_info.AppKey);
        APP_DEBUG("\r\n<-- DM Password:%s -->\r\n",cm_dmp_info.Pwd);
        return;
    }
    else
    {
        APP_DEBUG("\r\n<-- Error:Get ChinaMobile Registraion Configuration -->\r\n");
        return;
    }
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
    (void) unused;
    uint32 msg = 0;
    uint16  autocon;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate   =  9600;
    uart1_config.data_bits  =   QL_UART_DATA_BITS_8;
    uart1_config.parity     =   QL_UART_PARITY_NONE;
    uart1_config.stopbits   =   QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }

    APP_DEBUG("\r\n<-- OpenCPU: Operator Registration Example -->");
    APP_DEBUG("\r\n<-- cmd01: attach -->");
    APP_DEBUG("\r\n<-- cmd02: read configure -->");
    APP_DEBUG("\r\n<-- cmd03: disable CT reg -->");
    APP_DEBUG("\r\n<-- cmd04: disable CU reg -->");
    APP_DEBUG("\r\n<-- cmd05: disable CM reg -->");
    APP_DEBUG("\r\n<-- cmd06: enable CT reg -->");
    APP_DEBUG("\r\n<-- cmd07: enable CU reg -->");
    APP_DEBUG("\r\n<-- cmd08: enable CM reg -->");
    APP_DEBUG("\r\n<-- cmd09: change CM configure -->");
    APP_DEBUG("\r\n<-- cmd10: query CM reg state -->");
    APP_DEBUG("\r\n<-- cmd11: reset CM configure -->");
    APP_DEBUG("\r\n<-- cmd12: reboot -->");
    
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disenable AUTOCONNECT and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s \r\n",uart_buf);

			if (NULL != strstr((char*)uart_buf,"cmd01"))
			{
				ql_set_cfun(1,cfun_callback);
				ql_set_cereg_callback(cereg_callback);
			}
			else if (NULL != strstr((char*)uart_buf,"cmd02"))
			{	
				show_all_reg_configuration();
			}
            else if (NULL != strstr((char*)uart_buf,"cmd03"))
			{
				 if(QL_RET_OK != ql_set_chinatelcom_sreg_mode(false))
				 {
                    APP_DEBUG("\r\n<-- Disable CT reg failed -->\r\n");
				 }
                 else
                {
                    APP_DEBUG("\r\n<-- Disable CT reg success -->\r\n");
                }
			}
			else if (NULL != strstr((char*)uart_buf,"cmd04"))
			{
                if(QL_RET_OK != ql_set_chinaunicom_sreg_mode(false))
                {
                    APP_DEBUG("\r\n<-- Disable CU reg failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Disable CU reg success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd05"))
			{
                if(QL_RET_OK != ql_set_chinamobile_dm_mode(false))
                {
                    APP_DEBUG("\r\n<-- Disable CM reg failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Disable CM reg success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd06"))
			{
				 if(QL_RET_OK != ql_set_chinatelcom_sreg_mode(true))
				 {
                    APP_DEBUG("\r\n<-- Enable CT reg failed -->\r\n");
				 }
                 else
                {
                    APP_DEBUG("\r\n<-- Enable CT reg success -->\r\n");
                }
			}
			else if (NULL != strstr((char*)uart_buf,"cmd07"))
			{
                if(QL_RET_OK != ql_set_chinaunicom_sreg_mode(true))
                {
                    APP_DEBUG("\r\n<-- Enable CU reg failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Enable CU reg success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd08"))
			{
                if(QL_RET_OK != ql_set_chinamobile_dm_mode(true))
                {
                    APP_DEBUG("\r\n<-- Enable CM reg failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Enable CM reg success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd09"))
			{
                QL_DMP_ADDR set_dmp_addr = {"117.161.2.7",5683};
                QL_DMP_ONFO set_dmp_info = {QL_DMP_TYPE_LINUX,300,"867724030000423","M100000089","95GozTUi33nUK05ha526100QFbk0Y38M"};
                if(QL_RET_OK != ql_set_chinamobile_dm_configuration(&set_dmp_addr,&set_dmp_info))
                {
                    APP_DEBUG("\r\n<-- Change DM configuration failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Change DM configuration success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd10"))   
			{
                QL_DMP_STATE state;
                if(QL_RET_OK != ql_get_chinamobile_dm_state(&state))
                {
                    APP_DEBUG("\r\n<-- Get CM registration state failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- CM registration state:%d -->\r\n",state);
                }
			}
			else if (NULL != strstr((char*)uart_buf,"cmd11"))
			{
                if(QL_RET_OK != ql_reset_chinamobile_dm_configuration())
                {
                    APP_DEBUG("\r\n<-- Reset DM configuration failed -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- Reset DM configuration success -->\r\n");
                }
			}
            else if (NULL != strstr((char*)uart_buf,"cmd12"))
			{
                osDelay(3000);
		        ql_reboot();
			}
			else
			{
				APP_DEBUG("\r\n<-- unknown input-->\r\n");
			}

       }
       (void)osThreadYield(); 
    }
}

#endif // __EXAMPLE_OPERATOR_REG__