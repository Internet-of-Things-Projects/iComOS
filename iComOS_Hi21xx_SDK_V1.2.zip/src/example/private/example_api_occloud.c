/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_api_occloud.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to use API function communication with oceanConnect platform in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_API_OCCLOUD__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
*
*   Operation:
*
*     1.Input "oc init"     via uart1 to initialization module related configuration. 
*     2.Input "oc connect"  via uart1 to connect the iot platform. 
*     3.Input "oc send non" via uart1 to send the non-confirm data to the iot platform. 
*     3.Input "oc send con" via uart1 to send the confirm data to the iot platform.
*     4.Input "oc status"   via uart1 to get the registion status with iot platform.
*     5.Input "oc deinit"   via uart1 to unnitialize from the iot platform.
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_API_OCCLOUD__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_radio.h"
#include "ql_system.h"
#include "ql_socket.h"
#include "ql_app_debug.h"
#include "ql_occloud_api.h"
#include "example.h"

#define UART_QUEUE_LEN        3
#define UART_QUEUE_ITEM_SIZE  4

static const char *occloud_reg_labels[] = {
    "UNINITIALISED",
    "MISSING_CONFIG",
    "INIITIALISING",
    "INIITIALISED",
    "INIT_FAILED",
    "REGISTERING",
    "REGISTERED",
    "DEREGISTERED",
    "MO_DATA_ENABLED",
    "NO_UE_IP",
    "REJECTED_BY_SERVER",
    "TIMEOUT_AND_RETRYING",
    "REG_FAILED",
    "DEREG_FAILED",
};
static QL_CLOUD_INIT_PARAMS init_patams = {
	0,
	5683,
	"180.101.147.115",
	NULL,
	NULL,
};

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, UART_QUEUE_ITEM_SIZE, NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

static void cereg_callback(uint8 state)
{
	APP_DEBUG("\r\n<-- cereg callback:%d -->\r\n",state);
}


static void cgatt_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cgatt callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<--set cgatt success-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cgatt fail-->\r\n");
	}
}

static void cfun_callback(uint8 result)
{
	APP_DEBUG("\r\n<-- cfun callback:%d -->\r\n",result);
	if (0 == result)
	{
		APP_DEBUG("\r\n<-- set cfun success-->\r\n");
		ql_set_cgatt_state(1,cgatt_callback);
	}
	else
	{
		APP_DEBUG("\r\n<-- error: set cfun fail-->\r\n");
	}
}

static void ql_occloud_recv_cb(uint16 data_len)
{
	uint8 revbuf[513] = {0};
	char printbuf[1024] = {0};
	uint16 len = sizeof(revbuf);
	QL_RET ql_ret;

	ql_ret = ql_occloud_get_recv_data(&len,revbuf);

	if (len != data_len)
	{
		APP_DEBUG("\r\n<-- Error: received fail,cb len:%d-->\r\n",data_len);
	}
	ql_util_hex_to_string(printbuf,sizeof(printbuf),revbuf,len);
	APP_DEBUG("\r\n<-- received,ret:%d,data:%d,%s -->\r\n",ql_ret,len,printbuf);
}

static void ql_occloud_notify_cb(QL_OCCLOULD_EVTIND notify)
{
	APP_DEBUG("\r\n<-- OC notify:%d -->\r\n",notify);
}

static void ql_occloud_sent_cb(uint8 type,uint8 status,uint8 seq_num)
{
	if (OCCLOULD_MESSAGE_CON == type)
	{
		APP_DEBUG("\r\n<-- OC con data sent status:%d,seq:%d-->\r\n",status,seq_num);
	}
	else if (OCCLOULD_MESSAGE_NON == type)
	{
		APP_DEBUG("\r\n<-- OC non data sent status:%d,seq:%d-->\r\n",status,seq_num);
	}
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0;
    uint16  autocon;
    char * p = NULL;
    QL_RET ql_ret  = 0;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    APP_DEBUG("\r\n<-- OpenCPU: API OC Cloud Example -->");
    APP_DEBUG("\r\n<-- step1: oc init:regswt -->");
    APP_DEBUG("\r\n<-- step2: oc connect:reg/dereg -->");
    APP_DEBUG("\r\n<-- step3: oc send NON:xxx -->");
    APP_DEBUG("\r\n<-- step3: oc send CON:xxx -->");
    APP_DEBUG("\r\n<-- step4: oc status -->");
    APP_DEBUG("\r\n<-- step5: oc deinit -->\r\n");
    
    ql_get_nconfig(QL_AUTOCONNECT_FUNCTION,&autocon);
    if (1 == autocon)
    {
    	APP_DEBUG("\r\n<-- Disenable AUTOCONNECT and reboot -->\r\n");
		ql_set_nconfig(QL_AUTOCONNECT_FUNCTION,0);
		osDelay(3000);
		ql_reboot();
    }
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       {
       		p = (char*)uart_buf;
            APP_DEBUG("\r\n>>>>input: %s",p);

			if (NULL != strstr((char*)uart_buf,"oc init:"))
			{
				uint32 type = 0;
				char  buf[64]= {0};

				p += strlen("oc init:");

				if (ql_util_get_substring_split_by_comma(p,1,buf,sizeof(buf))>0)
				{
				   type = atoi(buf);
				}
				
				if (ql_util_get_substring_split_by_comma(p,3,buf,sizeof(buf))>0)
				{
					init_patams.iot_server_port = atoi(buf);
				}
				else
				{
					init_patams.iot_server_port = 5683;
				}
				
				if (ql_util_get_substring_split_by_comma(p,2,buf,sizeof(buf)) >0)
				{
					init_patams.iot_server_ip = buf;
				}
				else
				{
					init_patams.iot_server_ip = "180.101.147.115";
				}
				
                APP_DEBUG("\r\n<-- init set:%d,%s,%d-->\r\n",type,init_patams.iot_server_ip,init_patams.iot_server_port);
				
				ql_occloud_set_registration_mode((type>0)?1:0);
				
				ql_ret = ql_occloud_init(&init_patams);
				
				ql_set_cfun(1,cfun_callback);
				ql_set_cereg_callback(cereg_callback);
				ql_occloud_set_recv_callback(ql_occloud_recv_cb);
			}
			else if (NULL != strstr((char*)uart_buf,"oc connect:"))
			{
				uint8 type = 0xFF;
				p += strlen("oc connect:");
                // ike, 20190603, [fixed bug833] Add     deregister
				if(0 == strncmp(p, "dereg", 5))
				{
				    type = OCCLOULD_DEREGISTER;
				}
				else if(0 == strncmp(p, "reg", 3))
				{
				    type = OCCLOULD_REGISTRATION;
				}
				else
				{
				    APP_DEBUG("\r\n<-- unknown input-->\r\n");
				    ql_ret = QL_RET_ERR_PARAM;
				}
				
				if(type <= OCCLOULD_DEREGISTER)
				{
				    APP_DEBUG("\r\n<-- connect type:%s-->\r\n",type?"Deregister":"Register");
				    ql_ret = ql_occloud_connect(type, ql_occloud_notify_cb);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"oc send NON:"))
			{
				static uint8 non_seq_num = 0;
				uint8 hexbuf[512] = {0};
				uint8 pArr[512] = {0};
				
				p += strlen("oc send NON:");
                if ((NULL!=strstr(p,"\r"))||(NULL!=strstr(p,"\n")))
                {
                    memcpy(pArr,p,strlen(p)-2);
                }
				if (QL_RET_OK != ql_util_hexstring_to_hex(hexbuf,(uint8*)p,strlen(p)-2))
				{
					APP_DEBUG("\r\n<-- Error: hex string conversion failed-->\r\n");
					continue;
				}
			
				ql_ret = ql_occloud_send(hexbuf, strlen(p)/2,OCCLOULD_MSG_NON_NORAI, non_seq_num++, NULL);
				APP_DEBUG("\r\n<-- non data:%s,ret:%d-->\r\n",pArr,ql_ret);
			}
			else if (NULL != strstr((char*)uart_buf,"oc send CON:"))
			{
				static uint8 con_seq_num = 0;
				uint8 hexbuf[512] = {0};
				uint8 pArr[512] = {0};
				
				p += strlen("oc send CON:");
				if ((NULL!=strstr(p,"\r"))||(NULL!=strstr(p,"\n")))
                {
                    memcpy(pArr,p,strlen(p)-2);
                }
				if (QL_RET_OK != ql_util_hexstring_to_hex(hexbuf,pArr,strlen(p)-2))
				{
					APP_DEBUG("\r\n<-- Error: hex string conversion failed-->\r\n");
					continue;
				}

				ql_ret = ql_occloud_send(hexbuf, strlen(p)/2,OCCLOULD_MSG_CON_NORAI, con_seq_num++, ql_occloud_sent_cb);
				APP_DEBUG("\r\n<-- con data:%s,ret:%d-->\r\n",pArr,ql_ret);
			}
			else if (NULL != strstr((char*)uart_buf,"oc status"))
			{
				QL_OCCLOULD_CLIENT_STATE status;
				uint32 s[3] = {0};
				
				ql_ret = ql_occloud_get_registration_status(&status);
				APP_DEBUG("\r\n<-- OC reg status:%s,ret = %d-->\r\n",occloud_reg_labels[status],ql_ret);
				ql_ret = ql_occloud_get_send_statistics(&s[0],&s[1],&s[2]);
				APP_DEBUG("\r\n<-- OC sent status,pending:%d,sent:%d,err:%d,ret = %d-->\r\n",s[0],s[1],s[2],ql_ret);
				memset(s,0,sizeof(s));
				ql_ret = ql_occloud_get_rev_statistics(&s[0],&s[1],&s[2]);
				APP_DEBUG("\r\n<-- OC recv status,buffered:%d,received:%d,dropped:%d,ret = %d-->\r\n",s[0],s[1],s[2],ql_ret);
			}
			else if (NULL != strstr((char*)uart_buf,"oc deinit"))
			{

				ql_ret = ql_occloud_deinit();
				osDelay(3000);
				ql_set_cfun(0,cfun_callback);
				ql_set_cereg_callback(cereg_callback);

                if (QL_RET_OK == ql_ret)
				{
                    APP_DEBUG("\r\n<-- oc cloud deinit succe -->\r\n");
                }
                else
                {
                    APP_DEBUG("\r\n<-- oc cloud deinit error -->\r\n");
                }
			}
			else
			{
				APP_DEBUG("\r\n<-- unknown input-->\r\n");
				ql_ret = QL_RET_ERR_PARAM;
			}
			APP_DEBUG("\r\n<-- api occloud example return:%d -->\r\n",ql_ret);

       }
       (void)osThreadYield(); 
    }
}
#endif // __EXAMPLE_API_OCCLOUD__
