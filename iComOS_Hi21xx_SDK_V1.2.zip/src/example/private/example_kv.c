/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_kv.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to program kv save data in OpenCPU.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_KV__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download image bin to module to run.
*
*   Operation:
*     1. Input "write,<id>,<data>"  via uart1 to save data in kv;
*     2. Input "read,<id>"          via uart1 to read the saved data of kv;
*     3. Input "erase,<id>"         via uart1 to erase the saved data of kv;
*
*    eg. Input "write,1,1234567890" via uart1 to save data=1234567890 in kv;
*        Input "read,1"             via uart1 to read saved data in kv ID1;
*        Input "erase,1"            via uart1 to erase saved data in kv ID1;
*
* Author: Hayden.Wang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
* 
****************************************************************************/
#ifdef __EXAMPLE_KV__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_kv_storage.h"
#include "example.h"

#define UART_QUEUE_LEN  3

const uint32 UART_QUEUE_ITEM_SIZE = 4;

static osMessageQueueId_t uart_queue = NULL;

static uint8 uart_buf[255]={0};
static uint16 buf_len=0;

static uint8 kv_buff[255] = {0}; 

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}

static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	if (len > KEY_VALUE_MAX_LEN) 
	{
		return;
	}
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf,buffer,len);
    buf_len = len;
    QDEBUG_TRACE("rcv:%s", uart_buf);
    uart_send_to_incoming_queue_from_isr(1);
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
    ( void) unused;
    uint32 msg = 0;
    uint8 kv_id = QL_CUSTOM_KV_IDMAX;
    QL_RET ret;
    
    ql_wait_for_at_init();  //wait for modem ok  
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    uart_create_queue();
    uart1_config.baudrate=9600;
    uart1_config.data_bits=QL_UART_DATA_BITS_8;
    uart1_config.parity=QL_UART_PARITY_NONE;
    uart1_config.stopbits=QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("uart port1 init succe");
    }
    APP_DEBUG("\r\n<-- OpenCPU: KV Example -->\r\n");
    APP_DEBUG("\r\n<-- save data cmd: write,<id>,<data> (0 =< id =< 6)-->");
    APP_DEBUG("\r\n<-- get  data cmd: read,<id>         (0 =< id =< 6)-->");
    APP_DEBUG("\r\n<-- erase     cmd: erase,<id>        (0 =< id =< 6)-->\r\n");

    for(;;)
    {
       if(osMessageQueueGet(uart_queue,(void*)&msg, NULL, osWaitForever) == osOK)
       {
            APP_DEBUG("\r\n>>>>input: %s ",uart_buf);
            
            memset(kv_buff,0,sizeof(kv_buff));
            kv_id = QL_CUSTOM_KV_IDMAX;
            
			if (NULL != strstr((char*)uart_buf,"write,"))
			{
				uint8 *p = NULL, l = 0;
				
				p = uart_buf + strlen("write,");
				l = buf_len - strlen("write,")-strlen("\r\n");

				ql_util_char_to_hex(*p,&kv_id);

				p += 2, l -= 2;
				
				ret = ql_set_kv(kv_id,p,l);
				
				if (QL_RET_OK == ret)
				{
					APP_DEBUG("\r\n<-- Write data to kv success -->\r\n");
				}
				else 
				{
					APP_DEBUG("\r\n<--Error: Write data to kv fail,ret:%d -->\r\n",ret);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"read,"))
			{
				uint8 *p = NULL;
				uint16 kvalue_length = 0;
				
				p = uart_buf + strlen("read,");

				ql_util_char_to_hex(*p,&kv_id);

				ret = ql_get_kv(kv_id,sizeof(kv_buff),&kvalue_length,kv_buff);

				if ((QL_RET_OK == ret) && (kvalue_length > 0)) 
				{
					APP_DEBUG("\r\n<--read data from kv success,ret:%d -->\r\n",ret);
					APP_DEBUG("\r\n<--data:%s,len:%d -->\r\n",kv_buff,kvalue_length);
				}
				else 
				{
					APP_DEBUG("\r\n<--Error: read data from kv fail,ret:%d -->\r\n",ret);
				}
			}
			else if (NULL != strstr((char*)uart_buf,"erase"))
			{
				uint8 *p = NULL;
				
				p = uart_buf + strlen("erase,");

				ql_util_char_to_hex(*p,&kv_id);
				
				ret = ql_erase_kv(kv_id);

				if (QL_RET_OK == ret)
				{
					APP_DEBUG("\r\n<--erase kv success-->\r\n");
				}
				else 
				{
					APP_DEBUG("\r\n<--Error: erase kv fail,ret:%d -->\r\n",ret);
				}
			}
       }
       (void)osThreadYield();       
    }
}
#endif // __EXAMPLE_KV__