/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
*
* Filename:
* ---------
*   example_atc_onenet.c
*
* Project:
* --------
*   OpenCPU
*
* Description:
* ------------
*   This example demonstrates how to communicate with other peripheral  using AT COMMAND ,via virtual uart port 
*   in OpenCPU.In this example ,we use the UART1 peripheral send AT conmand to virtual uart port,then the virtual
*   uart port send the result to uart1.
*
*   All debug information will be output through DEBUG port and UART1 port.
*
* Usage:
* ------
*   Compile & Run:
*
*     Set "env.Append( CPPDEFINES=["__EXAMPLE_ATC_ONENET__"])" in SConscript file. And compile the 
*     app using "scons".
*     Download fwpkg file to module to run.
* 
*   Operation:
*     
*     Send "cmd: <type>" conmand via uart1 to execute specified command in the showed table.
*     eg. Send "cmd: 0" via uart1 to execute AT+NCONFIG? command.
*     The commands should be issued following OneNET access AT commands sequence,please refer to <BC35-G&BC28 R2.0 OneNET Application Note>
*     When registered success, you can send string type data with prefix "send:" via uart1.
*     You can recieve downlink data on resource 3311/0/5706 by write operation on OneNET platform.
*
* Author: Gary.Tang
* -------
* -------
*
*============================================================================
*             HISTORY
*----------------------------------------------------------------------------
*               V1.0
****************************************************************************/
#ifdef __EXAMPLE_ATC_ONENET__
#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_malloc.h"
#include "ql_app_debug.h"
#include "example.h"

#if  0
#define APP_ATCDBG	APP_DEBUG
#else
#define APP_ATCDBG(x,...);   
#endif

#define UART_QUEUE_LEN        21

#define ATCMD_TABLE_ITEM_MAX   sizeof(atcmd_table)/sizeof(AT_CMD)
#define ATRET_TABLE_ITEM_MAX   sizeof(atret_table)/sizeof(char*)
#define URC_TABLE_ITEM_MAX     sizeof(urc_handle_table)/sizeof(URC_HANDLER)


typedef void (*urc_handle_fn) (char *);
typedef void (*atcmd_result_fn) (uint8 ret,uint8 err);
typedef bool (*atcmd_process_fn) (char *);


typedef enum
{
    UART1_MSG  = 1,
    VUART_MSG,
} NETWORK_STEP;

typedef enum
{
	AT_PRO_IDLE,
	AT_PRO_WAIT_FOR_OK,
	AT_PRO_WAIT_FOR_PREFIX,
	AT_PRO_WAIT_FOR_PREFIX_CONTINUE,
	AT_PRO_WAIT_FOR_SUFFIX,
	AT_PRO_WAIT_FOR_SUFFIX_CONTINUE,
	AT_PRO_GOT_RESULT,
}AT_PRO_STATE;

typedef struct
{
	const char *pcmd;
    char prefix[64];     //Expected prefix
    char suffix[64];     //Expected suffix
    AT_PRO_STATE at_current;  
    uint8 is_block;
    osTimerId_t timer_id;
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
    char result[100];
    uint8 ret;
    uint8 err;
}AT_PROCESS;

typedef struct
{
    char *ptip; 
    char *pcmd;  
    uint32 timeout;    //s
    char *pprefix;     //Expected prefix
    char *psuffix;     //Expected suffix 
    atcmd_process_fn atcmd_process_callback;
    atcmd_result_fn  atcmd_result_callback;
}AT_CMD;

typedef struct
{
    char *urc_str;              //urc string
    urc_handle_fn urc_handle; //urc handle   
}URC_HANDLER;

typedef enum
{
    ONT_INIT  = 1,
    ONT_REGISTERING,
    ONT_REGISTERED,
    ONT_REGISTER_FAILED,
} ONT_REG_STATE;

static void atcmd_general_result_handle(uint8 ret, uint8 err);
static void atcmd_cfun_result_handle(uint8 ret, uint8 err);
static void atcmd_cgatt_result_handle(uint8 ret, uint8 err);
static bool atcmd_query_autoconnect_process_handle(char* str);
static bool atcmd_query_cgpaddr_process_handle(char* str);
static bool atcmd_create_suite_process_handle(char* str);


static void urc_ont_event_handle(char* str);
static void urc_ont_write_handle(char* str);
static void urc_ont_observe_handle(char* str);
static void urc_ont_discover_handle(char* str);

static osMessageQueueId_t uart_queue = NULL;

AT_CMD atcmd_table[] = {
	{"0","AT+NCONFIG?", 10,  "+NCONFIG:AUTOCONNECT",NULL, atcmd_query_autoconnect_process_handle,atcmd_general_result_handle},
	{"1","AT+NCONFIG=AUTOCONNECT,FALSE", 10, NULL,  NULL,      NULL,							atcmd_general_result_handle},
	{"2","AT+CFUN=1",   20,  NULL,                  NULL,      NULL,							atcmd_cfun_result_handle},
	{"3","AT+CGATT=1",  10,  NULL,                   NULL,      NULL,							atcmd_cgatt_result_handle},
	{"4","AT+CGPADDR",  1,   "+CGPADDR",            NULL,  atcmd_query_cgpaddr_process_handle,atcmd_general_result_handle},
    {"5","AT+MIPLCONFIG=0,183.230.40.40,5683",  1, NULL,            NULL,  NULL,atcmd_general_result_handle},
    {"6","AT+MIPLCREATE",  1,"+MIPLCREATE:0" ,     NULL,  atcmd_create_suite_process_handle, atcmd_general_result_handle},
    {"7","AT+MIPLADDOBJ=0,3311,1,\"1\",2,1",  1, NULL,     NULL,  NULL, atcmd_general_result_handle},
    {"8","AT+MIPLOPEN=0,86488,66",  1, NULL, NULL,  NULL, NULL},
    {"9","AT+MIPLUPDATE=0,0,0",  1, NULL,     NULL,  NULL,atcmd_general_result_handle},
    {"10","AT+MIPLCLOSE=0",  20, NULL,     NULL,  NULL,atcmd_general_result_handle},
    {"11","AT+MIPLDELETE=0", 20, NULL,     NULL,  NULL,atcmd_general_result_handle},
    {"12","AT+NUESTATS=APPSMEM", 1, NULL,     NULL,  NULL,atcmd_general_result_handle},
};

char *atret_table[]={
	"OK",
	"ERROR",
	"+CME ERROR:"
};

URC_HANDLER urc_handle_table[] = {
	{"+MIPLEVENT",            urc_ont_event_handle},
	{"+MIPLWRITE",            urc_ont_write_handle},
	{"+MIPLOBSERVE",          urc_ont_observe_handle},
	{"+MIPLDISCOVER",         urc_ont_discover_handle},
};

AT_PROCESS current_atcmd = {0};

static uint8 uart_buf[255]={0};
static uint16 buf_len = 0;
static char observed_msgid[10] = {0};

static void uart_send_to_incoming_queue_from_isr(uint32 msg)
{
    (void)osMessageQueuePut(uart_queue, (void*)&msg, 0, osNoWait);
}

static void uart_create_queue(void)
{
    uart_queue = osMessageQueueNew(UART_QUEUE_LEN, sizeof(uint32), NULL);
    if(NULL == uart_queue)
    {
        QDEBUG_TRACE("create_queue err");
    }
}
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	memset(uart_buf,0,sizeof(uart_buf));
    memcpy(uart_buf+1,buffer,len);
    buf_len = len;
    uart_buf[0] = UART1_MSG;
    uart_send_to_incoming_queue_from_isr((int32)&uart_buf);
    QDEBUG_TRACE("rcv1:%s,len:%d", uart_buf,len);
}

static void vuart_recieve_handle(uint8 * buffer, uint32 len)
{
	uint8* p = NULL;
	uint32 i = 0,j = 0;
    if(NULL == buffer)
    {
        APP_DEBUG("\r\n<-- Error: virtual Recv NULL -->\r\n");
    }
	p = ql_malloc(len+2);
	if (NULL == p)
	{
		APP_DEBUG("\r\n<-- Error: malloc fail!, len:%d -->\r\n",len);
		return;
	}
	memset(p,0,len+2);
	for (i = 0,j = 0; i < len; i++)
	{
		if (('\r' == buffer[i]) || ('\n' == buffer[i]))
		{
			continue;
		}
		*(p+j+1) = buffer[i];
		j++;
	}
	if (strlen((char*)(p+1)))
	{
	   	*p = VUART_MSG;
	   	uart_send_to_incoming_queue_from_isr((uint32)p);
	}
	else
	{
		ql_free(p);
	}
}

static void atcmd_send_timeout_handle(void)
{
	memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	osTimerStop(current_atcmd.timer_id);
	current_atcmd.ret = 0xff;
	current_atcmd.err = 0xff;
	current_atcmd.at_current = AT_PRO_IDLE;
	APP_DEBUG("\r\n<-- Error: cmd %s timeout! -->\r\n",current_atcmd.pcmd);
}

static int atcmd_send(const char* atcmd, char* prefix, char* suffix, uint32 timeout, atcmd_process_fn process_callback, atcmd_result_fn result_callback)
{
	
	if ((NULL == atcmd) || (AT_PRO_IDLE != current_atcmd.at_current))
	{
		return -1;
	}
	current_atcmd.pcmd = atcmd;
	if (NULL == prefix)
	{
		memset(current_atcmd.prefix,0,sizeof(current_atcmd.prefix));
	}
	else
	{
		strcpy(current_atcmd.prefix,prefix);
	}
	
	if (NULL == suffix)
	{
		memset(current_atcmd.suffix,0,sizeof(current_atcmd.suffix));
	}
	else
	{
		strcpy(current_atcmd.suffix,suffix);
	}

	current_atcmd.atcmd_process_callback = process_callback;
	current_atcmd.atcmd_result_callback  = result_callback;

	if (ql_uart_write(VIRTUAL_PORT,(uint8*)atcmd,strlen(atcmd))!=QL_RET_OK)
	{
		return -2;
	}
	if (NULL == strstr(atcmd,"\r\n"))
	{
		ql_uart_write(VIRTUAL_PORT,(uint8*)"\r\n",strlen("\r\n"));
	}

	
	if ((NULL == prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
	}
	else if ((NULL != prefix) && (NULL == suffix))
	{	
		current_atcmd.at_current = AT_PRO_WAIT_FOR_PREFIX;
	}
	else 
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_SUFFIX;
	}

	if (NULL == current_atcmd.timer_id)
	{
		current_atcmd.timer_id = osTimerNew((osTimerFunc_t)atcmd_send_timeout_handle, osTimerOnce, NULL, NULL);
	}

	if (timeout > 0)
	{
		osTimerStart(current_atcmd.timer_id, (uint32_t)osMs2Tick((uint64_t)timeout*1000));
		APP_ATCDBG("\r\n<-- Normal start timeout timer -->\r\n");
	}
	
	return 0;
}


static void atcmd_general_result_handle(uint8 ret, uint8 err)
{
    uint8 Arr[255] = {0};
    if ((strstr((char*)current_atcmd.pcmd,"\r")!= NULL)||(strstr((char*)current_atcmd.pcmd,"\n")!= NULL))
    {            
        memcpy(Arr,current_atcmd.pcmd,strlen((char*)current_atcmd.pcmd)-strlen("\r\n"));
    }
	if (ret < 2)
	{
		APP_DEBUG("\r\n<-- at cmd %s return: %s-->\r\n",Arr,atret_table[ret]);
	}
	else
	{
		APP_DEBUG("\r\n<-- at cmd %s return error code, %s:%d-->\r\n",Arr,atret_table[ret],err);
	}
}

static void atcmd_result_process_handle(char* str)
{
	char* p = NULL;
	uint8 i = 0;
	
	if (AT_PRO_IDLE == current_atcmd.at_current)
	{
		return;
	}

	if (AT_PRO_WAIT_FOR_OK == current_atcmd.at_current)
	{
		for (i = 0; i < ATRET_TABLE_ITEM_MAX; i++)
		{
			p = strstr(str,atret_table[i]);
			if (NULL != p)
			{	
				if (0 == i)
				{
					if (osTimerIsRunning(current_atcmd.timer_id))
					{
						osTimerStop(current_atcmd.timer_id);
						APP_ATCDBG("\r\n<-- Normal stop timeout timer -->\r\n");
					}						
				}
				else
				{
					APP_DEBUG("\r\n<-- at cmd %s process fail!-->\r\n",current_atcmd.pcmd);
				}
				if (NULL != current_atcmd.atcmd_result_callback)
				{
					current_atcmd.atcmd_result_callback(i,0xff);
				}
				current_atcmd.ret = i;
				if (2 ==  i)
				{
					p += (strlen(atret_table[i])+1);
					current_atcmd.err = atoi(p);
				}
				current_atcmd.at_current = AT_PRO_IDLE;
				break;
			}
		}
	}
	else
	{
		if (NULL != current_atcmd.atcmd_process_callback)
		{
			if (AT_PRO_WAIT_FOR_PREFIX != current_atcmd.at_current)
			{
				APP_DEBUG("\r\n<-- at cmd %s  status error! -->\r\n",current_atcmd.pcmd);
				return;
			}
			if (NULL != strstr(str,":"))
			{
				current_atcmd.atcmd_process_callback(str);
			}
			else
			{
				APP_ATCDBG("\r\n<-- unexpected return value: %s-->\r\n",str);
			}
		}
		else
		{
			APP_ATCDBG("\r\n<-- no callback function found -->\r\n");
		}
	}
}

static void atcmd_cfun_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	if (0 == ret)
	{
		APP_DEBUG("\r\n<-- cfun success-->\r\n");
		APP_DEBUG("\r\n<-- you can enable URC report of CEREG and CSCON-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cfun fail-->\r\n");
	}
}

static void atcmd_cgatt_result_handle(uint8 ret, uint8 err)
{
	UNUSED(err);
	if (0 == ret)
	{
		APP_DEBUG("\r\n<-- cgatt success-->\r\n");
		APP_DEBUG("\r\n<-- you can get the module address-->\r\n");
	}
	else
	{
		APP_DEBUG("\r\n<--Error: cgatt fail-->\r\n");
	}
}

static bool atcmd_query_autoconnect_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/autoconnect:%s -->\r\n",p);
	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;
}

static bool atcmd_query_cgpaddr_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/cgpaddr:%s -->\r\n",p);

	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;
}

static bool atcmd_create_suite_process_handle(char* str)
{
	char* p = NULL;
	UNUSED(p);
	
	p = strstr(str,current_atcmd.prefix);
	APP_DEBUG("\r\n<-- atcmd/miplcreate:%s -->\r\n",p);

	if (NULL != p)
	{
		current_atcmd.at_current = AT_PRO_WAIT_FOR_OK;
		return false;
	}
	return true;
}

static void urc_process_handle(char* str)
{
	uint8 i = 0;
	char* p = NULL;
	if(NULL == str)
	{
        return;
	}
    
	for(i = 0; i < URC_TABLE_ITEM_MAX; i++)
	{
		p = strstr(str,urc_handle_table[i].urc_str);	
		if (NULL != p)
		{
			urc_handle_table[i].urc_handle(str);
			break;
		}
	}
}

static void urc_ont_event_handle(char* str)
{
	APP_DEBUG("\r\n<-- urc/onenet event:%s -->\r\n",str);  
}

static void urc_ont_write_handle(char* str)
{
	APP_DEBUG("\r\n<-- urc/write:%s -->\r\n",str);
        //AT+MIPLWRITERSP=0,msgid,2
    char cmd_head[] = "AT+MIPLWRITERSP=0,";
    char cmd_tail[] = ",2";
    char writersp_cmd[100] = {0};
    char msgid[10] = {0};
    memset(writersp_cmd,0,100);
    memset(msgid,0,10);
    memcpy(writersp_cmd,cmd_head,strlen(cmd_head));
    uint32 len = 10;
    if(0 < ql_util_get_substring_split_by_comma(str,2,msgid,len))
    {
        memcpy(writersp_cmd+strlen(writersp_cmd),msgid,strlen(msgid));
    }
    else
    {
        APP_DEBUG("\r\n<-- discover/get msgid fail -->\r\n");
        return;
    }

    memcpy(writersp_cmd+strlen(writersp_cmd),cmd_tail,strlen(cmd_tail));
    int ret = atcmd_send(writersp_cmd,NULL,NULL,1,NULL,atcmd_general_result_handle);
										
    APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",writersp_cmd,ret);
}

static void urc_ont_observe_handle(char* str)
{
	APP_DEBUG("\r\n<-- urc/observe:%s -->\r\n",str);
    memset(observed_msgid,0,10);
    uint32 len = 10;
    if(0 < ql_util_get_substring_split_by_comma(str,2,observed_msgid,len))
    {
        APP_DEBUG("\r\n<-- observe/get msgid:%s -->\r\n",observed_msgid);
    }
    else
    {
        APP_DEBUG("\r\n<-- observe/get msgid fail -->\r\n");
        return;
    }
}

static void urc_ont_discover_handle(char* str)
{
	//UNUSED(str);
	APP_DEBUG("\r\n<-- urc/discover:%s -->\r\n",str);
    //AT+MIPLDISCOVERRSP=0,msgid,1,9,"5700;5701"
    
    char cmd_head[] = "AT+MIPLDISCOVERRSP=0,";
    char cmd_tail[] = ",1,9,\"5701;5706\"";
    char discoverrsp_cmd[100] = {0};
    char msgid[10] = {0};
    memset(discoverrsp_cmd,0,100);
    memset(msgid,0,10);
    memcpy(discoverrsp_cmd,cmd_head,strlen(cmd_head));
    uint32 len = 10;
    if(0 < ql_util_get_substring_split_by_comma(str,2,msgid,len))
    {
        memcpy(discoverrsp_cmd+strlen(discoverrsp_cmd),msgid,strlen(msgid));
    }
    else
    {
        APP_DEBUG("\r\n<-- discover/get msgid fail -->\r\n");
        return;
    }

    memcpy(discoverrsp_cmd+strlen(discoverrsp_cmd),cmd_tail,strlen(cmd_tail));
    int ret = atcmd_send(discoverrsp_cmd,NULL,NULL,2,NULL,atcmd_general_result_handle);
	uint8 discovArr[30] = {0};
    if ((strstr((char*)discoverrsp_cmd,"\r")!= NULL)||(strstr((char*)discoverrsp_cmd,"\n")!= NULL))
    {            
        memcpy(discovArr,discoverrsp_cmd,strlen((char*)discoverrsp_cmd)-strlen("\r\n"));
    }																		
    APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",discovArr,ret);
}

/**************************************************************
* Main Task
***************************************************************/
void main_task( void *unused )
{
    ql_uart_config uart1_config;
   ( void) unused;
    uint32 msg = 0, i = 0;
    uint8* pmsg = NULL;
    
    if(ql_uart_init(UART_PORT1) != QL_RET_OK)
    {
        QDEBUG_TRACE("uart port1 init error");
    } 
    
    uart_create_queue();
    uart1_config.baudrate   =   9600;
    uart1_config.data_bits  =   QL_UART_DATA_BITS_8;
    uart1_config.parity     =   QL_UART_PARITY_NONE;
    uart1_config.stopbits   =   QL_UART_STOP_BITS_1;
    if( ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle)!=QL_RET_OK )
    {
        QDEBUG_TRACE("user open  err\r\n");
    }
    enable_virtual_port();
    ql_uart_init(VIRTUAL_PORT);
    ql_uart_open(VIRTUAL_PORT, &uart1_config, vuart_recieve_handle);

    APP_DEBUG("\r\n<-- OpenCPU: ATC onenet Example -->\r\n");
    for (i = 0; i < ATCMD_TABLE_ITEM_MAX; i++)
	{
		APP_DEBUG("<-- Command %s. %s-->\r\n",atcmd_table[i].ptip,atcmd_table[i].pcmd);
	}
    APP_DEBUG("\r\n<-- Execute Command: cmd:0~%d-->",ATCMD_TABLE_ITEM_MAX-1);
    APP_DEBUG("\r\n<-- Execute Command: send:<data>-->\r\n");
    
    for(;;)
    {
       if(osMessageQueueGet(uart_queue, (void*)&msg, NULL, osWaitForever) == osOK)
       { 
       	pmsg = (uint8*)msg;
		switch(*pmsg)
		{
			case UART1_MSG:
				{
                    APP_DEBUG("\r\n>>>>input: %s",++msg);
					char* p = NULL;
					uint8 cmd = 0xFF;
                    pmsg++;
                    if(NULL != (p = strstr((char*)pmsg,"cmd:")))
                    {
    					p += 4;
    					cmd = atoi(p);
                        if ((cmd==0) && (*p!='0'))
                        {
                            APP_DEBUG("\r\n<-- Error: unknown input -->\r\n");
                            break;
                        }
    					APP_DEBUG("\r\n<-- run at cmd type:%d -->\r\n",cmd);
    					if ((NULL != p) && (cmd < ATCMD_TABLE_ITEM_MAX))
    					{
    						int ret = atcmd_send(atcmd_table[cmd].pcmd,atcmd_table[cmd].pprefix,atcmd_table[cmd].psuffix,atcmd_table[cmd].timeout,
    										atcmd_table[cmd].atcmd_process_callback,atcmd_table[cmd].atcmd_result_callback);
    										
    						APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",atcmd_table[cmd].pcmd,ret);
    					}
    					else
    					{
    						APP_DEBUG("\r\n<-- at cmd process fail-->\r\n");
    					}
                    }
                    else if(NULL != (p = strstr((char*)pmsg,"AT")))
                    {
                        if(ql_uart_write(VIRTUAL_PORT ,pmsg,strlen((char *)pmsg))!= QL_RET_OK)
                        {
                        	APP_DEBUG("\r\n<-- Error: virtual port sent fail -->\r\n");
                        }
                        else
                        {
                            uint8 cmdArr[20] = {0};
                            if ((strstr((char*)pmsg,"\r")!= NULL)||(strstr((char*)pmsg,"\n")!= NULL))
                            {            
                                memcpy(cmdArr,pmsg,strlen((char*)pmsg)-strlen("\r\n"));
                            }
                            APP_DEBUG("\r\n<-- run at cmd:%s -->\r\n",cmdArr);
                        }
                        break;
                    }
                    
                    else if(NULL != (p = strstr((char*)pmsg,"send:")))
                    {
                        p += 5;
    					APP_DEBUG("\r\n<-- run at cmd type:%d -->\r\n",cmd);
                        if(0 == strlen(observed_msgid)) 
                        {
                           APP_DEBUG("\r\n<-- no observed-->\r\n"); 
                           break;
                        }
                        //AT+MIPLNOTIFY=0,msgid,3311,0,5701,1,len,data,0,0,0x01
    					char cmd_head[] = "AT+MIPLNOTIFY=0,";
                        char cmd_middle[] = ",3311,0,5701,1,";
                        char cmd_tail[] = ",0,0,0x01\r\n";
                        char notify_cmd[255] = {0};
                        char lenstr[10] = {0};
                        uint32 len = strlen(p);
                        if(len > 2)
                        {
                            memset(notify_cmd,0,255);
                            memset(lenstr,0,10);
                            memcpy(notify_cmd,cmd_head,strlen(cmd_head));

                            memcpy(notify_cmd+strlen(notify_cmd),observed_msgid,strlen(observed_msgid));
                            memcpy(notify_cmd+strlen(notify_cmd),cmd_middle,strlen(cmd_middle));
                            (void)sprintf(lenstr, "%d", len-2);
                            memcpy(notify_cmd+strlen(notify_cmd),lenstr,strlen(lenstr));
                            notify_cmd[strlen(notify_cmd)] = ',';
                            notify_cmd[strlen(notify_cmd)] = '\"';
                            memcpy(notify_cmd+strlen(notify_cmd),p,strlen(p)-2);
                            notify_cmd[strlen(notify_cmd)] = '\"';
                            memcpy(notify_cmd+strlen(notify_cmd),cmd_tail,strlen(cmd_tail));
                            int ret = atcmd_send(notify_cmd,NULL,NULL,1,NULL,atcmd_general_result_handle);
                        	uint8 notifyArr[255] = {0};
                            if ((strstr((char*)notify_cmd,"\r")!= NULL)||(strstr((char*)notify_cmd,"\n")!= NULL))
                            {            
                                memcpy(notifyArr,notify_cmd,strlen((char*)notify_cmd)-strlen("\r\n"));
                            }								
                            APP_DEBUG("\r\n<-- at cmd sent:%s,ret:%d  -->\r\n",notifyArr,ret);
                        }
                        else
                        {
                            APP_DEBUG("\r\n<-- no send data-->\r\n");
                        }
                    }
				}
				break;
			case VUART_MSG:
    			{
    				pmsg++;
    				APP_ATCDBG("\r\n<-- process handle string:%s  -->\r\n",pmsg);
    				atcmd_result_process_handle((char*)pmsg);
    				if (AT_PRO_IDLE == current_atcmd.at_current)
    				{
    					urc_process_handle((char*)pmsg);
    				}

    				pmsg = (uint8*)msg;
    				ql_free(pmsg);
    			}	
				break;
			default:
				APP_DEBUG("\r\n<-- Error: unknown msg type,type:%d  -->\r\n",*pmsg);
				break;
		}
       }
       (void)osThreadYield(); 
    }

}
#endif // __EXAMPLE_ATC_ONENET__
