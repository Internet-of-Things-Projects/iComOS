/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_task_def.c
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   The file is for some common system definition. Developer don't have to
 *   care.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
/*
*--------------------------
* Task Configuration
*--------------------------
* TaskStackSize:
*    The stack size of task. Range from 1K to 10K.
*    If there are any file operations to do in task, 
*    the stack size of this task must be set to at least 4K.
*****************************************************************/
#include "ql_task_def.h"
#include "ql_system_cfg.h"

#ifdef TASK_ID_DEF
#undef TASK_ID_DEF
#endif
#ifdef TASK_DEFINITION
#undef TASK_DEFINITION
#endif
#define TASK_FUNC_DECLARATION
#include "ql_task_def.h"
TASK_DEFINITION_BEGIN
#include "ql_task_cfg.h"
TASK_DEFINITION_END
#undef TASK_FUNC_DECLARATION



#ifdef TASK_FUNC_DECLARATION
#undef TASK_FUNC_DECLARATION
#endif
#ifdef TASK_ID_DEF
#undef TASK_ID_DEF
#endif
#define TASK_DEFINITION
#include "ql_task_def.h"
TASK_DEFINITION_BEGIN
#include "ql_task_cfg.h"
TASK_DEFINITION_END
#undef TASK_DEFINITION


void* ql_get_task_enter(void)
{
	return (void*)custom_tasks;
}
