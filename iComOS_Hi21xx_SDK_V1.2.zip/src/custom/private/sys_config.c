/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2018
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   sys_config.c
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   The file is for some common system definition. Developer don't have to
 *   care.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
/*
*--------------------------
* Task Configuration
*--------------------------
* TaskStackSize:
*    The stack size of task. Range from 1K to 10K.
*    If there are any file operations to do in task, 
*    the stack size of this task must be set to at least 4K.
*****************************************************************/

#include "ql_common.h"
#include "ql_system_cfg.h"
#include "ql_app_debug.h"
#include "ql_uart.h"
#include "ql_gpio.h"


extern void opencpu_set_at_handle_callback(void* func);
extern void at_main(void);

char const user_version[10]="UV003";


Hs_DebugPortConfig debugportcfg = {
    
    ADVANCE_MODE//use by application core and other core debug log
    //LIGHT_ADVANCE_MODE//only used for appliction core
};

void enable_virtual_port(void)
{
	opencpu_set_at_handle_callback(at_main);
}

void disenable_virtual_port(void)
{
	opencpu_set_at_handle_callback(NULL);
}


