/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_system_cfg.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   SYSTEM API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifdef _QUECTEL_OPEN_CPU_ 
#ifndef _QL_SYSTEM_CFG_H_
#define _QL_SYSTEM_CFG_H_

extern const char user_version[10];

typedef enum{
    LIGHT_ADVANCE_MODE,
    ADVANCE_MODE,// as a system debug port
    ILLEGAL_MODE,
}DebugPortMode;

typedef struct {
    
    DebugPortMode mode;

}Hs_DebugPortConfig;

extern Hs_DebugPortConfig debugportcfg; 

void enable_virtual_port(void);

void disenable_virtual_port(void);

#ifdef TASK_ENTRYFUNC_DEF
#undef TASK_ENTRYFUNC_DEF
#endif
#ifdef TASK_DEFINITION
#undef TASK_DEFINITION
#endif
#define TASK_ID_DEF
#include "ql_task_def.h"
TASK_DEFINITION_BEGIN
#include "ql_task_cfg.h"
TASK_DEFINITION_END
#undef TASK_ID_DEF

#endif
#endif  //__QL_STRING_CFG_H__
