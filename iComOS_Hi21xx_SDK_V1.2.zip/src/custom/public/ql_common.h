/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_common.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   COMMON API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef    _QL_COMMON_H_
#define    _QL_COMMON_H_
#include "ql_type.h"
#include "ql_util.h"
#include "cmsis_os2.h"

#ifdef EXC_HANDLER
#include "exc_handler.h"
#endif

#ifndef UNUSED
#define UNUSED(var) do { (void)var; } while(0)
#endif

extern int atoi(const char *nptr);

extern int sprintf(char *s, const char *format, ...);

extern int sscanf(const char *s, const char *format, ...);

extern void enable_virtual_port(void);

extern void disenable_virtual_port(void);

#endif  //__QL_COMMON_H__
