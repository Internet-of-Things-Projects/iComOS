/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_app_debug.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   DEBUG API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifdef _QUECTEL_OPEN_CPU_ 
#ifndef _QL_APP_DEBUG_H_
#define _QL_APP_DEBUG_H_

#include "ql_uart.h"

void uart_prinf(uart_port uart,const char *buff,...);

void ql_dbg_trace(const char *buff,...);


#ifdef APP_DEBUG
#undef APP_DEBUG
#endif


#define DEBUG_ENABLE 1
#if DEBUG_ENABLE > 0
#define DEBUG_PORT UART_PORT1
#define DBG_BUF_LEN   512
#define APP_DEBUG(FORMAT,...) {\
    if (UART_PORT1 != (DEBUG_PORT)) \
    {\
        ql_dbg_trace(FORMAT,##__VA_ARGS__);\
    } else {\
        uart_prinf((DEBUG_PORT), FORMAT, ##__VA_ARGS__);\
    }\
}
#else
#define APP_DEBUG(FORMAT,...) 
#endif


#define QDEBUG_TRACE(s, args...)   ql_dbg_trace(s, ## args)

#endif
#endif  //__QL_APP_DEBUG_H__
