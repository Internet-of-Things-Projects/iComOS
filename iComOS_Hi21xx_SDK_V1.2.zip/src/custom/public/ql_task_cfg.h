/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/

/*------------------------------------------------------------------------------------------------------------
|		    Task Name     |Stack Size (Bytes)*4 |       Task Priority     |   Task Entry Function | Task Init |
*-------------------------------------------------------------------------------------------------------------*/

TASK_ITEM("main task",          1000,               CUSTOM_TASK_PRIORITY_0,      main_task,           NULL) 

#ifdef __EXAMPLE_MULTITASK__
TASK_ITEM("sub_task1",			300,			   CUSTOM_TASK_PRIORITY_1,		sub_task1,			 NULL) 
TASK_ITEM("sub_task2",			300,			   CUSTOM_TASK_PRIORITY_2,		sub_task2,			 NULL) 
#endif
