/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_type.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   DATA type defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef    _QL_TYPE_H_
#define    _QL_TYPE_H_

#ifndef true
#define true 1
#define false 0

typedef int bool;
#endif


typedef signed char             int8;
typedef short                   int16;
typedef long                    int32;
typedef long long               int64;

typedef unsigned char           uint8;
typedef unsigned short          uint16;
typedef unsigned long           uint32;
typedef unsigned long long      uint64;

typedef unsigned int            size_t;
typedef int32                   ssize_t;
typedef unsigned long           time_t;

#endif  //__QL_TYPE_H__
