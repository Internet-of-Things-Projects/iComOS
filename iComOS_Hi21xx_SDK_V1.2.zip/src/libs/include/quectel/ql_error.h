/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_error.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   ERROR code defines.
 *
 * Author:Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QOCPU_ERROR_H__
#define __QOCPU_ERROR_H__

/****************************************************************************
 * Error Code Definition
 ***************************************************************************/

typedef enum
{
    QL_RET_OK                         = 0,
    
    QL_RET_ERR_PARAM                  = 1,
    QL_RET_ERR_INIT                   = 2,
	QL_RET_ERR_NO_INIT                = 3,
	QL_RET_ERR_RE_INIT                = 4,  
    QL_RET_ERR_USED                   = 5,
    QL_RET_ERR_BUSY                   = 6,
    QL_RET_ERR_PROGRESS               = 7,
	QL_RET_ERR_NOT_SUPPORT            = 8,
	QL_RET_ERR_MEMORY                 = 9,
	QL_RET_ERR_FLOW_CONTROL           = 10,
	QL_RET_ERR_SET_IP                 = 11,
	QL_RET_ERR_GET_IMEI               = 12,
	QL_RET_ERR_BUFFER_SIZE            = 13, 
	QL_RET_ERR_PARAM_UNCONFIG         = 14,

	QL_RET_ERR_CHANNEL_NOT_FOUND      = 30,
	QL_RET_ERR_WRITE                  = 31,
	QL_RET_ERR_READ                   = 32,
	
	QL_RET_ERR_I2C_STATE_FAIL         = 40,//I2C
	QL_RET_ERR_I2C_NOT_CLAIM          = 41,
	QL_RET_ERR_I2C_SLAVE_NOT_RESPONSE = 42,
	QL_RET_ERR_I2C_RELEASE_FAIL       = 43,
	QL_RET_ERR_I2C_DEACTIVATE_FAIL    = 44,
	
    QL_RET_ERR_SPI_STATE_FAIL         = 50,//SPI
	QL_RET_ERR_SPI_NOT_CLAIM          = 51,
	QL_RET_ERR_SPI_BUS_BUSY           = 52,
	QL_RET_ERR_SPI_RELEASE_FAIL       = 53,
	QL_RET_ERR_SPI_DEACTIVATE_FAIL    = 54,

	QL_RET_ERR_UART_INVALID           = 60, //uart
	
	QL_RET_ERR_OC_NO_INIT             = 70,
	QL_RET_ERR_OC_NO_REGISTERED       = 71,
	QL_RET_ERR_OC_PARAM_UNCONFIG      = 72,
	QL_RET_ERR_OC_NO_DATA             = 73,
	QL_RET_ERR_OC_SET_ADDRESS_FAIL    = 74,
	QL_RET_ERR_OC_SET_PSK_FAIL        = 75,
	QL_RET_ERR_OC_NO_CONTEXT          = 76,
	QL_RET_ERR_OC_FOTA_UPDATING       = 77,

	QL_RET_ERR_SOC_ERROR              = 90,
	QL_RET_ERR_SOC_FLOWCONTROL        = 91,
	QL_RET_ERR_SOC_DATA_SEQUENCE_REPEAT = 92,
	QL_RET_ERR_SOC_NO_NETWORK_SERVICE = 93,	
	QL_RET_ERR_SOC_INVALID            = 94,

    QL_RET_ERR_FOTA_WRITE             = 100,
    QL_RET_ERR_FOTA_ERASE             = 101,
    QL_RET_ERR_FOTA_UPGRADE           = 102,

    QL_RET_ERR_MQTT_UNINITIALIZED     = 116,//MQTT
    QL_RET_ERR_MQTT_IDX_INVALID       = 117,
    QL_RET_ERR_MQTT_SYNTAX_ERROR      = 118,
    QL_RET_ERR_MQTT_STATUS_ERROR      = 119,
    QL_RET_ERR_MQTT_CLIENTID          = 120,
    QL_RET_ERR_MQTT_CONNECTPKT        = 121,
    QL_RET_ERR_MQTT_PACKSUB_FAIL      = 122,
    QL_RET_ERR_MQTT_PACKUNSUB_FAIL    = 123,
    QL_RET_ERR_MQTT_SENDPKT           = 124,
    QL_RET_ERR_MQTT_RELEASE_FAIL      = 125,
    
    
    QL_RET_ERR_UNKNOWN = 255,
} QL_RET;

#endif  //__QL_ERROR_H__
