/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_radio.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   RADIO API defines.
 *
 * Author: Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_RADIO_H__
#define __QL_RADIO_H__
#include "ql_common.h"
#include "ql_error.h"

	
#define QCFUN_MIN           0
#define QCFUN_FULL          1	
#define QMAX_IMSI_LEN      16
#define QAT_MAX_CID        10

#define QL_MAX_APN_SIZE               101
#define QL_CGAUTH_MAX_USERNAME_LEN    60
#define QL_CGAUTH_MAX_PASSWORD_LEN    60

#define QL_POWER_CLASS_3              3
#define QL_POWER_CLASS_5              5
#define QL_POWER_CLASS_6              6


typedef enum
{
    QL_AUTOCONNECT_FUNCTION,
    QL_CR_0354_0338_SCRAMBLING_FUNCTION,
    QL_CR_0859_SI_AVOID_FUNCTION,
    QL_COMBINE_ATTACH,
    QL_CELL_RESELECTION,
    QL_ENABLE_BIP,
    QL_MULTITONE_FUNCTION, /* When writing, use user preference;
                                when reading, return true only if user allows MT and HW supports it for current band */
    QL_NAS_SIM_POWER_SAVING_ENABLE,
    QL_BARRING_RELEASE_DELAY,
    QL_RELEASE_VERSION,
    QL_RPM_FUNCTION,
    QL_SYNC_TIME_PERIOD,
    QL_IPV6_GET_PREFIX_TIME,
    QL_NB_CATEGORY,
    QL_ENABLE_RAI,
    QL_HEAD_COMPRESS,
    QL_RLF_UPDATE,
    QL_CONNECTION_REEST,
    QL_PCO_TYPE,
	
    QL_NUM_NCONFIG_FUNCTION,
} QL_NCONFIG_FUNCTION;

/**
 * @brief PDN Type: IPv4, IPv6 or Dual
 */
typedef enum
{
    QL_PDN_TYPE_INVALID    = 0x0,
    QL_PDN_TYPE_IPV4       = 0x1,
    QL_PDN_TYPE_IPV6       = 0x2,
    QL_PDN_TYPE_IPV4V6     = 0x3,
    QL_PDN_UNUSED          = 0x4,  // shall be interpreted as "IPv6" if received by the network
    QL_PDN_TYPE_NON_IP     = 0x5
} QL_PDN_TYPE;

typedef struct {
    uint8           state;
    uint16          tac;
    uint16          active_time;
    uint16          periodic_tau;
    uint32          ci;
    bool            cause_type;
    uint8           reject_cause;
}QL_CEREG;


typedef struct  {
    uint16  version;             // structure version: will increment on any change.
    uint16  pci;                 // physical cell id
    int32   signal_power;        // Signal power: <signal power in centibels>
    int32   total_power;         // Total power: <total power in centibels>
    int32   tx_power;            // TX power: <current Tx power level in centibels>
    uint32  tx_time;             // TX time<total Tx time since last reboot in millisecond>
    uint32  rx_time;             // RX time: <total Rx time since last reboot in millisecond>
    uint32  cell_id;             // Cell ID:<last cell ID>
    uint8   dl_mcs;              // DL MCS: <last DL MCS value>
    uint8   ul_mcs;              // UL MCS: <last UL MCS value>
    uint8   dci_mcs;             // DCI_MCS: <last DCI MCS value>    
    uint8   current_ecl;         // Current ECL: <Current Enhanced Coverage Level (0..2)>
    int32   snr;                 // snr
    uint32  earfcn;              // earfcn of serving cell
    int32   rsrq;               // rsrq
    int16   operation_mode;     // operator mode for SlB1
    uint8   current_band;       // band of serving cell 
    uint32  rlc_ul_bler;        // RLC UL throughput bler
    uint32  rlc_dl_bler;        // RLC DL throughput bler
    uint32  mac_ul_bler;        // MAC UL throughput bler
    uint32  mac_dl_bler;        // MAC DL throughput bler
    uint32  ll1_transmitted_bytes;
    uint32  ll1_received_bytes;
    uint16  total_tb_tx;
    uint16  total_tb_rx;
    uint16  total_tb_retx;
    uint16  total_harq_nack_received;
    uint32  rlc_ul_data_rate;   // RLC UL throughput
    uint32  rlc_dl_data_rate;   // RLC DL throughput
    uint32  mac_ul_data_rate;   // MAC UL throughput
    uint32  mac_dl_data_rate;   // MAC DL throughput    
} QL_UESTATS;

typedef struct 
{
    uint8  version;
    bool   primary_cell:1;
    bool   valid:1;
    uint16 pci;
    uint32 earfcn;
    int16  rsrp;
    int16  rsrq;
    int16  rssi;
    int16  snr;
} QL_UESTATS_CELL;

typedef struct
{
    uint8           version;            // structure version
    uint8           cid;
    uint8           d_comp;
    uint8           h_comp;
    QL_PDN_TYPE     pdp_type;
    bool            emergency;          // Not Used
    uint8           addr_alloc;         // Not Used
    uint8           nslpi;
    uint8           secure_pco;
    uint8           *apn;
    uint8           apn_nw[QL_MAX_APN_SIZE];
    uint8           state;
}QL_PDP_CONTEXT;


/**
 * @brief cfun callback
 * @param result cfun state 
 */
typedef void (*ql_cfun_callback)(uint8 result);

/**
 * @brief attach callback
 * @param result attach/detach result
 */
typedef void (*ql_cgatt_callback)(uint8 result);

/**
 * @brief 
 * @param 
 */
typedef void (*ql_cgact_callback)(uint8 result);


/**
 * @brief connection callback
 * @param connect status
 */
typedef void (*ql_cscon_callback)(uint8 connect_status);

/**
 * @brief registration callback
 * @param reg_state registration status
 */
typedef void (*ql_cereg_callback)(uint8 reg_status);
/**
 * @brief
 * @param
 */
typedef void (*ql_ptwedrxs_callback)(uint8 act_type, uint8 requested_edrx_value, uint8 nw_provided_edrx_value, uint8 paging_time_window, uint8 requested_paging_time_window);

/**
 * @brief psm status callback
 * @param psm status
 */
typedef void (*ql_psm_status_callback)(uint8 psm_status);


/*****************************************************************
 * Function:	 ql_set_nconfig
 *
 * Description:
 *               Configure UE Behaviour
 * Parameters:
 *				 function:
 *					  [In] function to set.
 *				 value:
 *					  [In] function value to set.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_nconfig(QL_NCONFIG_FUNCTION function,uint16 value);


/*****************************************************************
 * Function:	 ql_get_nconfig
 *
 * Description:
 *               Get nconfig value
 * Parameters:
 *				 function:
 *					  [In] function to get.
 *				 value:
 *					  [Out] function value to get.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_nconfig(QL_NCONFIG_FUNCTION function,uint16 *value);


/*****************************************************************
 * Function:	 ql_set_cfun
 *
 * Description:
 *               Select the level of functionality . Be similar to AT+CFUN=0/1
 * Parameters:
 *				 cfun:
 *					  [In]0:minimum functionality 1:full functionality.
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cfun(uint16 cfun,ql_cfun_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_cfun
 *
 * Description:
 *               Get the level of functionality . Be similar to AT+CFUN?
 * Parameters:
 *				 cfun:
 *					  [Out]0:minimum functionality 1:full functionality.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cfun(uint16* cfun);


/*****************************************************************
 * Function:	 ql_set_cgatt_state
 *
 * Description:
 *               attach the MT to, or detach the MT from, the Packet Domain service . Be similar to AT+CGATT=0/1
 * Parameters:
 *				 state:
 *					  [Out]0:detached, 1:attached.
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cgatt_state(uint8 state, ql_cgatt_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_cgatt_state
 *
 * Description:
 *                attach the MT to, or detach the MT from, the Packet Domain service . Be similar to AT+CGATT?
 * Parameters:
 *				 state:
 *					  [Out]0:detached, 1:attached.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cgatt_state(uint8 *state);


/*****************************************************************
 * Function:	 ql_set_cgact_state
 *
 * Description:
 *               activate pdp context
 * Parameters:
 *				 cid:
 *					  [In] cid to active .
 *               mode:
 *                    [In] active/deactive
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cgact_state(uint16 cid,uint8 mode, ql_cgact_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_cgact_state
 *
 * Description:
 *                
 * Parameters:
 *				 cid:
 *					  [In] cid to get .
 *               state:
 *                    [Out] active/deactive
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cgact_state(uint8 cid, uint8 *state);


/*****************************************************************
 * Function:	 ql_get_attach_reject_cause
 *
 * Description:
 *               Get the attach reject cause 
 * Parameters:
 *				 is_rejected:
 *					  [Out] flag to indicate attach reject.
 *               cause:
 *                    [Out] the cause of attach reject
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_attach_reject_cause(uint8 *is_rejected, uint8 *cause);


/*****************************************************************
 * Function:	 ql_set_cscon_callback
 *
 * Description:
 *               Enable SCSON status callback
 * Parameters:
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cscon_callback(ql_cscon_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_cscon_state
 *
 * Description:
 *               gives details of the terminal perceived radio connection status.Be similar to AT+CSCON?
 * Parameters:
 *				 connection_status:
 *					  [Out]  0: Idle, 1: Connected.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cscon_state(uint8 *connection_status);


/*****************************************************************
 * Function:	 ql_set_cereg_callback
 *
 * Description:
 *               Enable CEREG status callback
 * Parameters:
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cereg_callback(ql_cereg_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_cereg_state
 *
 * Description:
 *               gives details of the terminal perceived EPS attach status.Be similar to AT+CEREG?
 * Parameters:
 *				 cereg_val:
 *					  [Out] EPS attach status.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cereg_state(QL_CEREG *cereg_val);


 /*****************************************************************
 * Function:	 ql_get_imsi
 *
 * Description:
 *                Return the IMSI number of the installed SIM . Be similar to AT+CIMI
 * Parameters:
 *				 imsi_string:
 *					  [Out] buffer to save imsi number string.
 *				 input_length:
 *					  [In] length of input buffer..
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				QL_RET_ERR_PARAM:
 *						  Illegal parameter
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_imsi(char * imsi_string, uint8 buf_len);


/*****************************************************************
* Function: 	ql_get_signal_quality
*
* Description:
*				 Get signal strength indicator . Be similar to AT+CSQ
* Parameters:
*				csq:
*					 [Out] return signal strength in decimal of 0 to 99.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*			    QL_RET_ERR_PARAM:
*						 Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_signal_quality(uint8 *csq);


/*****************************************************************
* Function: 	ql_get_device_ip
*
* Description:
*				return the IP address of the device . Be similar to AT+CGPADDR
* Parameters:
*				ip_string:
*					 [Out]  buffer to save device IP address.
*				buf_len:
*					 [In] length of input buffer.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*			    QL_RET_ERR_PARAM:
*						 Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_device_ip(char * ip_string, uint8 buf_len);


/*****************************************************************
* Function: 	ql_get_uestats
*
* Description:
*				get UE status. Be similar to AT+NUESTATS
* Parameters:
*				uestats:
*					 [Out]  UE status.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*			    QL_RET_ERR_PARAM:
*						 Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_uestats(QL_UESTATS *uestats);


/*****************************************************************
* Function: 	ql_get_uestats_cell
*
* Description:
*				get UE status with cell information. Be similar to AT+NUESTATS=CELL
* Parameters:
*				cell_info:
*					 [Out] UE status with cell informatin.
*               cell_info_num:
*                    [Out] get cell information number.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*			    QL_RET_ERR_PARAM:
*						 Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_uestats_cell(QL_UESTATS_CELL *cell_info, uint8 *cell_info_num);


/*****************************************************************
* Function: 	ql_clear_earfcn
*
* Description:
*				Clear the EARFCN saved by the UE
* Parameters:
*				none
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_clear_earfcn(void);


/*****************************************************************
 * Function:	 ql_delete_pdp_context
 *
 * Description:
 *               delete PDP context
 * Parameters:
 *				 cid:
 *					  [In] cid to delete.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_delete_pdp_context(uint16 cid);


/*****************************************************************
 * Function:	 ql_delete_pdp_context
 *
 * Description:
 *               Activates a pdp context
 * Parameters:
 *				 context:
 *					  [In] Pointer type, PDP context.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_activate_pdp_context(const QL_PDP_CONTEXT* context);


/*****************************************************************
 * Function:	 ql_get_pdp_context
 *
 * Description:
 *               get a pdp context
 * Parameters:
 *               cid:
 *                    [In]cotext to get
 *				 context:
 *					  [Out] PDP context.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_pdp_context(uint8 cid, QL_PDP_CONTEXT *context);


/*****************************************************************
 * Function:	 ql_set_pdp_context_auth_param
 *
 * Description:
 *               Define PDP context authentication parameters
 * Parameters:
 *               cid:
 *                    [In]cotext to set
 *				 auth_prot:
 *					  [In] Authentication protocol used for this PDP context.
 *               login_str:
 *                    [In] User name for access to the IP network   max length is 60.
 *               password_str:
 *                    [In] Password for access to the IP network max length is 60.
 *                    
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_pdp_context_auth_param(uint8 cid, uint8 auth_port, uint8 *login_str, uint8 *password_str);


/*****************************************************************
 * Function:	 ql_get_pdp_context_auth_param
 *
 * Description:
 *               Get PDP context authentication parameters
 * Parameters:
 *               cid:
 *                    [In]cotext to set
 *				 auth_prot:
 *					  [Out] Authentication protocol used for this PDP context.
 *               login_str:
 *                    [Out] User name for access to the IP network, max length is 60.
 *               password_str:
 *                    [Out] Password for access to the IP network, max length is 60.
 *                    
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_pdp_context_auth_param(uint8 cid, uint8* auth_prot, uint8 *login_str, uint8 *password_str);


/*****************************************************************
 * Function:	 ql_set_cpsms
 *
 * Description:
 *               Set power saving mode
 * Parameters:
 *               mode:
 *                    [In]0: disable the use of psm,1: enable, 2: Disable the use of PSM and discard all parameters for PSM.
 *				 requested_periodic_tau:
 *					  [In] requested periodic tau value to set, 0xFFFF means not set.
 *               requested_active_time:
 *                    [In] requested active time value to set, 0xFFFF means not set.
 *                    
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_cpsms(uint8 mode, uint16 requested_periodic_tau, uint16 requested_active_time);


/*****************************************************************
 * Function:	 ql_get_cpsms
 *
 * Description:
 *               Get power saving mode
 * Parameters:
 *               mode:
 *                    [In]power saving mode to get
 *				 requested_periodic_tau:
 *					  [Out] requested periodic tau value to get.
 *               requested_active_time:
 *                    [Out] requested active time value to set.
 *                    
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cpsms(uint8 *mode, uint8 *requested_periodic_tau, uint8 *requested_active_time);


/*****************************************************************
 * Function:	 ql_set_npsmr_callback
 *
 * Description:
 *               Enable deepsleep status callback
 * Parameters:
 *				 pfunc:
 *					  [In] callback function.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_npsmr_callback(ql_psm_status_callback pfunc);


/*****************************************************************
 * Function:	 ql_get_npsmr_status
 *
 * Description:
 *               gives details of the terminal perceived deep sleep status.Be similar to AT+NPSMR?
 * Parameters:
 *				 npsmr:
 *					  [Out] 0: active mode, 1: deepsleep mode.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_npsmr_status(uint8* npsmr);


/*****************************************************************
 * Function:	 ql_set_ptwedrxs
 *
 * Description:
 *               Set the UEs eDRX parameters
 * Parameters:
 *				 mode:
 *					  [In] disable or enable the use of eDRX in the UE
 *               type:
 *                    [In] the type of access technology
 *				 edrx_value:
 *					  [In] the value of eDRX.
 *               paging_time_window:
 *                    [In] the value of paging_time_window
 *               ptwedrxcallback:
 *                    [In] callback function
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_ptwedrxs(uint8 mode, uint8 type, uint8 edrx_value, uint8 paging_time_window, ql_ptwedrxs_callback ptwedrxcallback);


/*****************************************************************
 * Function:	 ql_get_ptwedrxs
 *
 * Description:
 *               Get the UEs eDRX parameters
 * Parameters:
 *               type:
 *                    [Out] the type of access technology
 *				 edrx_value:
 *					  [Out] the value of eDRX.
 *               paging_time_window:
 *                    [In] the value of paging_time_window
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_ptwedrxs(uint8 *type, uint8 *edrx_value, uint8 *paging_time_window);


/*****************************************************************
 * Function:	 ql_get_ptwedrxs
 *
 * Description:
 *               Get the UEs eDRX parameters
 * Parameters:
 *               registered_state:
 *                    [Out] the UE registered state
 *				 act_type:
 *					  [Out] the type of access technology
 *               edrx_valid:
 *                    [Out] indicates if the information is valid or not
 *               edrx_value:
 *                    [Out] the eDRX value of UE request(edrx_value is 4-bit value)
 *				 nw_provided_edrx:
 *					  [Out] the eDRX value of NW provide(nw_provided_edrx is 4-bit value)
 *               paging_time:
 *                    [Out] the paging time window(paging_time is 4-bit value)
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_get_cedrxrdp(uint8 *registered_state, uint8 *act_type, uint8 *edrx_valid, uint8 *request_edrx, uint8 *nw_provided_edrx, uint8 *paging_time);


/*****************************************************************
 * Function:	 ql_set_band_power_class
 *
 * Description:
 *               Set the power class of band 
 * Parameters:
 *               band:
 *                    [In] band to set
 *				 power_class:
 *					  [In] Power class 3  5  6
 *                                dBm  23 20 14                
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PROGRESS:
 *						   Process processing failed
 *****************************************************************/
QL_RET ql_set_band_power_class(uint8 band, uint8 power_class);


 /*****************************************************************
  * Function:	  ql_set_band_power_class
  *
  * Description:
  * 			  read the map of band and power class
  * Parameters:
  * 			  band:
  * 				   [In] band to read
  * 			  power_class:
  * 				   [out] Power class 3  5  6
  * 							   dBm	23 20 14				
  * Return:
  * 			  QL_RET_OK:
  * 						Indicates this function successes.
  * 			  QL_RET_ERR_PROGRESS:
  * 						Process processing failed
  *****************************************************************/
QL_RET ql_get_band_power_class(uint8 band, uint8 *power_class);

#endif  //__QL_RADIO_H__
