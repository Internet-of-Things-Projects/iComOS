/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_i2c.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   I2C API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_I2C_H__
#define __QL_I2C_H__
#include "ql_type.h"
#include "ql_error.h "

typedef enum{    
    I2C_Config_Addr_Type_7bit,
    I2C_Config_Addr_Type_10bit,
}I2C_CONFIG_ADDR_TYPE;

typedef enum{    
    I2C_Config_Half_Speed_100kbit = 256,
    I2C_Config_Half_Speed_400kbit = 64,
}I2C_CONFIG_HALf_Speed;

/*****************************************************************
* Function:     ql_i2c_init 
* 
* Description:
*               This function initialize the configurations for an I2C channel.
*               including the specified pins for I2C, I2C type, and I2C channel No.
*
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the parameter support channel is 0 or 1.
*               pinSCL:
*                   [In] I2C SCL pin.
*               pinSDA:
*                   [In] I2C SDA pin.
*               IICtype:
*                   [In] I2C type, the parameter is reserved.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel.
*               QL_RET_ERR_PARAM, the parameter is invalide,you can check if the parameters are correct.
*               QL_RET_ERR_INIT, can't claim I2C contronller pin, maybe is I2C contronller not initialization.
*****************************************************************/
QL_RET ql_i2c_init(uint32 chnnlNo, Enum_PinName pinSCL, Enum_PinName pinSDA, bool I2Ctype);

/*****************************************************************
* Function:     ql_i2c_config 
* 
* Description:
*               This function configuration the I2C interface for one slave.
*         
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the No is specified by Ql_I2C_Init function
*               isHost:
*                   [In] must be ture, just support host mode.
*               addrType:
*                   [In] I2C address type.
*		        i2cSpeed:
*		            [In] just used for hardware I2C, the range is [100kbps,400kbps]. 
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel, make sure it is initialized already.
*               QL_RET_ERR_I2C_STATE_FAIL, I2C bus state is wrong.
*               QL_RET_ERR_I2C_NOT_CLAIM, the I2C is activate failed.
*               QL_RET_ERR_PARAM, the parameter is invalide,you can check if the parameters are correct.
*****************************************************************/
QL_RET  ql_i2c_config(uint32 chnnlNo, bool isHost, I2C_CONFIG_ADDR_TYPE addrType, I2C_CONFIG_HALf_Speed i2cSpeed);

/*****************************************************************
* Function:     ql_i2c_write 
* 
* Description:
*               This function  write data  to specified slave through I2C interface.
*               
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the No is specified by Ql_I2C_Init function.
*               slaveAddr:
*                   [In] slave address.
*               pData:
*                   [In] Setting value to slave
*               len:
*                   [In] Number of bytes to write. 
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, patameter error.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel, make sure it is initialized already.
*               QL_RET_ERR_I2C_STATE_FAIL, I2C bus state is wrong.
*               QL_RET_ERR_I2C_SLAVE_NOT_RESPONSE, slave device not response.
*               QL_RET_ERR_WRITE, write data failed.
*****************************************************************/
QL_RET ql_i2c_write(uint32 chnnlNo, uint8 slaveAddr, uint8 *pData, uint8 len);

/*****************************************************************
* Function:     ql_i2c_read 
* 
* Description:
*               This function read data from specified slave through I2C interface.
*               
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the No is specified by Ql_I2C_Init function.
*               slaveAddr:
*                   [In] slave address.
*               pBuffer:
*                   [Out] read buffer of reading the specified register from slave.
*               len:
*                   [In] Number of bytes to read.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, patameter error.
*               QL_RET_ERR_I2C_STATE_FAIL, I2C bus state is wrong.
*               QL_RET_ERR_I2C_SLAVE_NOT_RESPONSE, slave device not response.
*               QL_RET_ERR_READ, receive data failed.
*****************************************************************/
QL_RET ql_i2c_read(uint32 chnnlNo, uint8 slaveAddr, uint8 *pBuffer, uint8 len);

/*****************************************************************
* Function:     ql_i2c_write_read 
* 
* Description:
*               This function read data form the specified register(or address) of slave.
*               
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the No is specified by Ql_I2C_Init function.
*               slaveAddr:
*                   [In] slave address.
*               pData:
*                   [In] Setting value of the specified register of slave.
*               wrtLen:
*                   [In] Number of bytes to write.
*               pBuffer:
*                   [Out] read buffer of reading the specified register from slave.
*               rdLen:
*                   [In] Number of bytes to read.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, patameter error.
*               QL_RET_ERR_I2C_SLAVE_NOT_RESPONSE, slave device not response.
*               QL_RET_ERR_I2C_STATE_FAIL, I2C bus state is wrong.
*               QL_RET_ERR_WRITE, send data failed.
*               QL_RET_ERR_READ, receive data failed.
*****************************************************************/
QL_RET ql_i2c_write_read(uint32 chnnlNo, uint8 slaveAddr, uint8 * pData, uint8 wrtLen, uint8 * pBuffer, uint8 rdLen);

/*****************************************************************
* Function:     ql_i2c_uninit 
* 
* Description:
*               This function releases the pins.
*               
* Parameters:
*               chnnlNo:
*                   [In] I2C channel No, the No is specified by Ql_I2C_Init function.

* Return:       
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel, make sure it is initialized already.
*               QL_RET_ERR_I2C_NOT_RELEASE, is released some error, Whether the pin is being used.
*               QL_RET_ERR_I2C_NOT_DEACTIVATE, can't deactivate.
*****************************************************************/
QL_RET ql_i2c_uninit(uint32 chnnlNo);

#endif  //__QL_I2C_H__
