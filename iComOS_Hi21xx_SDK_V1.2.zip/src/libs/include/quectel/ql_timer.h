/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_timer.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *  Timer API defines.
 *
 * Author:Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
 

#ifndef __QL_TIMER_H__
#define __QL_TIMER_H__
#include "ql_type.h"

/**
 * Timer flag type
 */
typedef enum
{
    QL_TIMER_FLAG_NORMAL = 0,
    QL_TIMER_FLAG_PERMANENT,   //the flag to make sure there is enough resource for caller
}QL_TIMER_FLAG;


/*
 * The callback type for the timers
 */
typedef void (*ql_timer_callback)(void);


/*****************************************************************
* Function:     ql_timer_addms 
* 
* Description:
*               Register timer.
*
* Parameters:
*               delay_ms:
*                       [In] How many ms to wait.
*                            
*               time_callback:
*                       [Out] Notify the application when the time of the timer arrives.
*               flag:
*                       [In] the feature of timer.
* Return:
*               QL_RET_OK indicates register ok;
*               QL_RET_ERR_PARAM indicates the param error.
*               QL_RET_ERR_INVALID_TIMER 
*    
*****************************************************************/
void* ql_timer_addms(uint32 delay_ms, ql_timer_callback time_callback, QL_TIMER_FLAG flag);


/*****************************************************************
* Function:     ql_timer_resetms 
* 
* Description:
*               Start up a timer with the specified timer id.
*
* Parameters:
*               timer_id:
*                       [in] timer id, return from ql_timer_register().
*               callback_delay:
*                       [in] how many ms to wait
*               callback_func:
*                       [in] the function to call once the wait is done
* Return:
*               QL_RET_OK indicates register ok;
*               QL_RET_ERR_PARAM indicates the param error.
*               QL_RET_ERR_INVALID_TIMER indicates that the timer ID is already being used  
*               or the timer is started or stopped not in the same task with it registered.
*               QL_RET_ERR_TIMER_FULL indicates all timers are used up.
*               QL_RET_ERR_INVALID_TASK_ID indicates the task invalid.
*    
*****************************************************************/
QL_RET ql_timer_resetms(uint8* timer_id, uint32 callback_delay, ql_timer_callback callback_func);

/*****************************************************************
* Function:     ql_timer_stop 
* 
* Description:
*               Stop the QL_TIMER_FLAG_PERMANENT timer with the specified timer id.
*
* Parameters:
*               timerId:
*                   [in] timer id, return from ql_timer_register().
* Return:
*               QL_RET_OK indicates register ok;
*               QL_RET_ERR_PARAM indicates the param error.
*               QL_RET_ERR_INVALID_TIMER indicates that the timer ID is already being used  
*               or the timer is started or stopped not in the same task with it registered.
*****************************************************************/
QL_RET ql_timer_stop(uint8* timer_id);

/*****************************************************************
* Function:     ql_timer_delete 
* 
* Description:
*               Delete the QL_TIMER_FLAG_NORMAL timer with the specified timer id.
*
* Parameters:
*               timerId:
*                   [in] timer id, return from ql_timer_register().
* Return:
*               QL_RET_OK indicates register ok;
*               QL_RET_ERR_PARAM indicates the param error.
*               QL_RET_ERR_INVALID_TIMER indicates that the timer ID is already being used  
*               or the timer is started or stopped not in the same task with it registered.
*****************************************************************/
QL_RET ql_timer_delete(uint8* timer_id);

#endif  //__QL_TIMER_H__
