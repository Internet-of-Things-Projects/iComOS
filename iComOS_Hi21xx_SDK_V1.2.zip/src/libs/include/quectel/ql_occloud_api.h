/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_occloud_api.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   OCCLOUD API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifdef _QUECTEL_IOT_OPEN_

#ifndef __OPENCPU_CLOUD_API_H__
#define __OPENCPU_CLOUD_API_H__

#include "ql_common.h"
#include "ql_error.h"

#define OCCLOULD_MESSAGE_CON       0 /* confirmable message (requires ACK/RST)*/
#define OCCLOULD_MESSAGE_NON       1 /* non-confirmable message (one-shot message)*/

#define OCCLOULD_REGISTRATION      0 /* Trigger register operation */
#define OCCLOULD_DEREGISTER        1 /* Trigger deregister operation */


typedef enum
{
    OCCLOULD_STATE_UNINITIALISED = 0,
    OCCLOULD_STATE_MISSING_CONFIG,
    OCCLOULD_STATE_INIITIALISING,
    OCCLOULD_STATE_INIITIALISED,
    OCCLOULD_STATE_INIT_FAILED,
    OCCLOULD_STATE_REGISTERING,
    OCCLOULD_STATE_REGISTERED,
    OCCLOULD_STATE_DEREGISTERED,
    OCCLOULD_STATE_APP_DATA_ENABLED,
    OCCLOULD_STATE_NO_UE_IP,
    OCCLOULD_STATE_REJECTED_BY_SERVER,
    OCCLOULD_STATE_TIMEOUT_AND_RETRYING,
    OCCLOULD_STATE_REG_FAILED,
    OCCLOULD_STATE_DEREG_FAILED,
}QL_OCCLOULD_CLIENT_STATE;

typedef enum
{
    OCCLOULD_MSG_NON_NORAI            = 0x0000,
    OCCLOULD_MSG_NON_WITHRAI          = 0x0001,
    OCCLOULD_MSG_NON_WITH_SENDBACKRAI = 0x0010,
    OCCLOULD_MSG_CON_NORAI            = 0x0100,
    OCCLOULD_MSG_CON_WITHRAI          = 0x0101
}QL_OCCLOULD_MSG_MODE;

typedef enum
{
    OCCLOULD_NOT_SENT            = 0,
    OCCLOULD_SENT_WAIT_RESPONSE,  
    OCCLOULD_SENT_FAIL,   
    OCCLOULD_SENT_TIMEOUT,
    OCCLOULD_SENT_SUCCESS,
    OCCLOULD_SENT_GOT_RST,
    OCCLOULD_SEND_PENDING,
}QL_OCCLOULD_SEND_STATUS;

typedef enum
{
    OCCLOULD_FOTA_MODE_AUTOMATIC = 0,
    OCCLOULD_FOTA_MODE_MANUAL    = 1
}QL_OCCLOULD_FOTA_MODE;

typedef enum
{
    OCCLOULD_CTRL_START_DOWNLOAD   = 2,
    OCCLOULD_CTRL_CANCEL_DOWNLOAD  = 3,
    OCCLOULD_CTRL_START_UPGRADE    = 4,
    OCCLOULD_CTRL_CANCEL_UPGRADE   = 5
}QL_OCCLOULD_FOTA_CONTROL;

typedef enum
{
    OCCLOULD_TYPE_DTLS_DISABLE = 0,
    OCCLOULD_TYPE_DTLS_STANDARD,
    OCCLOULD_TYPE_DTLS_OPTIMIZE,
    OCCLOULD_TYPE_DTLS_MAX
}QL_OCCLOULD_SECURE_TYPE;

typedef enum
{
    OCCLOULD_IOT_SERVER     = 0,
    OCCLOULD_TYPE_BS_SERVER = 1,
    OCCLOULD_TYPE_MAX_DEL   = 2
}QL_OCCLOULD_SERVER_TYPE;

typedef enum
{
    OCCLOULD_DTLS_WITH_NAT,
    OCCLOULD_DTLS_NO_NAT
}QL_OCCLOULD_NAT_TYPE;

typedef enum
{
    OCCLOULD_REGISTRATION_COMPLETED, 
    OCCLOULD_DEREGISTRATION_COMPLETED,
    OCCLOULD_REGISTRATION_UPDATE_COMPLETED,
    OCCLOULD_1900_RESOURCE_OBSERVED,
    OCCLOULD_BOOTSTRAP_COMPLETED,
    OCCLOULD_FOTA_503_RESOURCE_OBSERVED,
    OCCLOULD_FOTA_DEVICE_RECEIVE_PUT_PACKAGE_URI,
    OCCLOULD_FOTA_DEVICE_RECEIVE_UPDATE,
	OCCLOULD_EVTIND_RESERVED,
    OCCLOULD_1900_RESOURCE_CANCEL_OBSERVED,
	
	OCCLOULD_EVTIND_MAX,
} QL_OCCLOULD_EVTIND;


typedef struct cloud_init_params
{
    uint8                dtls_mode;
    uint16               iot_server_port;
    char                 *iot_server_ip;
    char                 *psk;
    char                 *psk_id;
}QL_CLOUD_INIT_PARAMS;

#define IMEI_CHANGE_REBOOT_FLAG        0x01
#define SECURE_CHANGE_REBOOT_FLAG      0x02
#define PSK_CHANGE_REBOOT_FLAG         0x04
#define IP_PORT_CHANGE_REBOOT_FLAG     0x08


typedef void (*ql_occloud_recv_callback)(uint16 data_len);

/**
 * @brief  Data Sent status indication.
 * @param  type: 0,OCCLOULD_MESSAGE_CON   1, OCCLOULD_MESSAGE_NON
 * @param  status: 0,DISCARDED  1,SENT   2,SENT_TO_AIR_INTERFACE
 * @param  seq_num: serial number.
 * @return none
 */
typedef void (*ql_occloud_sent_callback)(uint8 type,uint8 status,uint8 seq_num);

typedef void (*ql_occloud_notify_callback)(QL_OCCLOULD_EVTIND notify);

typedef void (*ql_occloud_notify_fota_callback)(char* status);

/*****************************************************************
* Function:     ql_occloud_init
*
* Description:
*                Initializing parameter configuration related to cloud platform interaction
*
* Parameters:
*               cloud_init_paramss:
*                   Parameters related to cloud platform interaction.
*
* Return:
*				QL_RET_OK:
*                         Indicates this function successes.
*               QL_RET_ERR_PROGRESS:
*                         Process processing failed
*               QL_RET_ERR_RE_INIT:
*                         Repeated initialization
*               QL_RET_ERR_PARAM:
*                         Invalid argument.
*               QL_RET_ERR_GET_IMEI:
*                         Failed to get module IMEI number
*               QL_RET_ERR_OC_SET_ADDRESS_FAIL:
*                         Failed to set cloud platform IP address
*               QL_RET_ERR_OC_SET_PSK_FAIL:
*                         Setting PSK failed
*****************************************************************/
QL_RET ql_occloud_init(QL_CLOUD_INIT_PARAMS *cloud_init_params);


/*****************************************************************
* Function: 	ql_occloud_deinit
*
* Description:
*				Deregister the cloud platform and release related resources.
*
* Parameters:
*				none
*
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_OC_NO_INIT:
*                         Not initialized
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_deinit(void);

/*****************************************************************
* Function: 	ql_occloud_connect
*
* Description:
*				Deregister the cloud platform and release related resources.
*
* Parameters:
*				reg_type:
*                      [In] 0,Trigger register operation; 1,Trigger deregister operation.
*               callback:      
*                      [In] OCCloud platform connection state callback function.
*
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_OC_NO_INIT:
*                         Not initialized
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*               QL_RET_ERR_OC_NO_CONTEXT:
*                         LwM2M context is missing
*****************************************************************/
QL_RET ql_occloud_connect(uint8 reg_type,ql_occloud_notify_callback callback);

/*****************************************************************
* Function: 	ql_occloud_send
*
* Description:
*				Send message to OC cloud platform.
*
* Parameters:
*				send_payload:
*					   [In] Buffer containing the data to be transmitted.
*				payload_len:	   
*					   [In] Length of the data in send_payload, in bytes.
*               mode:
*                      [In] 0x0000: Send NON message;
*                           0x0001: Send Non message and carry RELEASE RAI;
*                           0x0010: Send NON message and carry RELEASE_AFTER_REPLY RAI;
*                           0x0100: Send CON message;
*                           0x0101: Send CON message and carry RELEASE_AFTER_REPLY RAI.
*               seq_num:
*                      [In] Serial number of the data to be sent. 0~255
*               callback:
*                      [In] function of con data confirm or indication of non data sent 
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_INIT:
*						  Not initialized
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*               QL_RET_ERR_OC_NO_REGISTERED:
*                         UE is not registered to the OC cloud platform
*               QL_RET_ERR_MEMORY:
*                         Memory allocation failed
*               QL_RET_ERR_FLOW:
*                         The send buffer is full
*				QL_RET_ERR_OC_NO_CONTEXT:
*						  LwM2M context is missing
*               QL_RET_ERR_OC_FOTA_UPDATING:
*                         UE is undergoing FOTA upgrade
*               QL_RET_ERR_GET_IMEI:
*                         Failed to get module IMEI number
*****************************************************************/
QL_RET ql_occloud_send(uint8 *send_payload, uint16 payload_len, QL_OCCLOULD_MSG_MODE mode, uint8 seq_num, ql_occloud_sent_callback callback);


/*****************************************************************
* Function: 	ql_occloud_get_send_con_data_status
*
* Description:
*				 Get the sending status of CON data.
*
* Parameters:
*				send_status:
*					   [Out] Current CON data transmission status
*				seq_num:	   
*					   [Out] The serial number of the current CON data.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_INIT:
*						  Not initialized
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_get_send_con_data_status(QL_OCCLOULD_SEND_STATUS* send_status,uint8* seq_num);


/*****************************************************************
* Function: 	ql_occloud_get_recv_data
*
* Description:
*				 get the receive data from the remote cloud.
*
* Parameters:
*				length:
*					   [Out] return the length of the received data.
*				message:	   
*					   [Out] received data.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_DATA:
*						  Receive buffer has no data
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*****************************************************************/
QL_RET ql_occloud_get_recv_data(uint16 *length, uint8 *message);


/*****************************************************************
* Function: 	ql_occloud_set_recv_callback
*
* Description:
*				Set the receive callback function.
*
* Parameters:
*				callback:
*					   [In] callback function.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*****************************************************************/
QL_RET ql_occloud_set_recv_callback(ql_occloud_recv_callback callback);


/*****************************************************************
* Function: 	ql_occloud_get_registration_status
*
* Description:
*				 Get the status of IOT platform registration.
*
* Parameters:
*				status:
*					   [Out] Return to registration status.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_INIT:
*						  Not initialized
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*				QL_RET_ERR_OC_NO_CONTEXT:
*						  LwM2M context is missing
*****************************************************************/
QL_RET ql_occloud_get_registration_status(QL_OCCLOULD_CLIENT_STATE *status);


/*****************************************************************
* Function: 	ql_occloud_get_send_statistics
*
* Description:
*				Get data delivery status.
*
* Parameters:
*				pending:
*					   [Out] Return the number of pending data.
*				sent:	   
*					   [Out] Return the number of sent data.
*				err:	   
*					   [Out] Return the number of sent failed data.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_INIT:
*						  Not initialized
*****************************************************************/
QL_RET ql_occloud_get_send_statistics(uint32* pending,uint32* sent,uint32* err);


/*****************************************************************
* Function: 	ql_occloud_get_rev_statistics
*
* Description:
*				Get data received status.
*
* Parameters:
*				buffered:
*					   [Out] Return the number of buffered data.
*				received:	   
*					   [Out] Return the number of received data.
*				dropped:	   
*					   [Out] Return the number of dropped  data.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_OC_NO_INIT:
*						  Not initialized
*****************************************************************/
QL_RET ql_occloud_get_rev_statistics(uint32* buffered, uint32* received, uint32* dropped);


/*****************************************************************
* Function: 	ql_occloud_set_server_ip
*
* Description:
*				Set the OC cloud server IP and PORT.
*
* Parameters:
*				ip_address:
*					   [In] OC cloud server ip.
*				port:	   
*					   [In] OC cloud server port.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*				QL_RET_ERR_MEMORY:
*						  Memory allocation failed
*				QL_RET_ERR_GET_IMEI:
*						  Failed to get module IMEI number
*****************************************************************/
QL_RET ql_occloud_set_server_ip(const char *ip_address, uint16 port);

	
/*****************************************************************
* Function: 	ql_occloud_get_server_ip
*
* Description:
*				Get the OC cloud server IP and PORT.
*
* Parameters:
*				ip_address:
*					   [Out] Return OC cloud server IP.
*               buf_len:
*                      [In] the sizeof ip_address.
*               port:
*                      [Out] return OC cloud server PORT.                        
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_BUFFER_SIZE:
*						  The data length is greater than the size of the buffer
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*               QL_RET_ERR_MEMORY:
*                         Memory allocation failed
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_get_server_ip(char *ip_address, uint16 buf_len, uint16 *port);

	
/*****************************************************************
* Function: 	ql_occloud_get_registration_mode
*
* Description:
*				return OC cloud server registration mode.(AT+QREGSWT?)
*
* Parameters:
*				reg_mode:
*					   [Out] return OC cloud server registration mode.						 
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*****************************************************************/
QL_RET ql_occloud_get_registration_mode(uint8* reg_mode);

	
/*****************************************************************
* Function: 	ql_occloud_set_registration_mode
*
* Description:
*				Set the OC cloud server registration mode. (AT+QREGSWT=mode)
*
* Parameters:
*				reg_mode:
*					   [In] 0,Manual registration mode;
*                           1,Automatic registration mode
*                           2,Disable registration
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*****************************************************************/
QL_RET ql_occloud_set_registration_mode(uint8 reg_mode);

 	
/*****************************************************************
* Function: 	ql_occloud_set_fota_mode
*
* Description:
*				Set the OC cloud server FOTA mode. (AT+QLWFOTAIND=mode)
*
* Parameters:
*				mode:
*					   [In] 0,The automatic FOTA upgrade mode is used;
*                           1,The controlled FOTA upgrade mode is used
*               notify_fota_callback:
*                      [In] OC cloud server FOTA status callback function.
*
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_set_fota_mode(QL_OCCLOULD_FOTA_MODE mode, ql_occloud_notify_fota_callback notify_fota_callback);


/*****************************************************************
* Function: 	ql_occloud_get_fota_mode
*
* Description:
*				Get the OC cloud server FOTA mode. (AT+QLWFOTAIND?)
*
* Parameters:
*				mode:
*					   [Out] return OC cloud server FOTA mode.						 
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_get_fota_mode(uint8* mode);


/*****************************************************************
* Function: 	ql_occloud_fota_process
*
* Description:
*				the OC cloud server FOTA process control. (AT+QLWFOTAIND=process)
*
* Parameters:
*				state:
*					   [In] process control.						 
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_occloud_fota_process(QL_OCCLOULD_FOTA_CONTROL state);


/*****************************************************************
* Function: 	ql_occloud_request_send_in_fota
*
* Description:
*				Request to send data in the FOTA process. (AT+QCRITICALDATA=1)
*
* Parameters:
*				none						 
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_FLOW:
*                         The send buffer is full
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*               QL_RET_ERR_OC_FOTA_UPDATING:
*                         UE is undergoing FOTA upgrade
*****************************************************************/
QL_RET ql_occloud_request_send_in_fota(void);

#endif
#endif  //__OPENCPU_CLOUD_API_H__