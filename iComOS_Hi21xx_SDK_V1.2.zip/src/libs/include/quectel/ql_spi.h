/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_spi.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   SPI API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_SPI_H__
#define __QL_SPI_H__
#include "ql_type.h"
#include "ql_error.h "

typedef enum
{
    SPI_Interface_Type_Single_Bidir,
    SPI_Interface_Type_Double,
    SPI_Interface_Type_Quad,
    SPI_Interface_Type_Single_Unidir,
    SPI_Interface_Type_None
}SPI_INTERFACE_TYPE;

typedef enum
{
    SPI_Clock_Mode0,
    SPI_Clock_Mode1,
    SPI_Clock_Mode2,
    SPI_Clock_Mode3
}SPI_CLOCK_MODE;

typedef void (*SPI_CALLBACK_RET)(QL_RET);

/*****************************************************************
* Function:     ql_spi_init 
* 
* Description:
*               This function initialize the configurations for a SPI channel.
*               including the specified pins for SPI, SPI type, and SPI channel No.
*
* Parameters:
*               chnnlNo:
*                   [In] SPI channel No, the parameter support channel  0 or 1.
*               pinClk:
*                   [In] SPI CLK pin.
*               pinMiso:
*                   [In] SPI MISO pin.
*               pinMosi:
*                   [In] SPI MOSI pin.
*               pinCs:
*                   [In] SPI CS pin.
*               spiType:
*                   [In] SPI type, the parameter only support SPI_Interface_Type_Single_Unidir.

* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error or invlide parameter.
*               QL_RET_ERR_INIT, can't claim SPI contronller pin, maybe is SPI contronller not initialization. 
*======================
* Example:
*======================
*   you could use this api like this for SPI:
*   ql_spi_init(    0,                                  //spi channel
                    PINNAME_SPI_CLK,                    //spi CLK pin
                    PINNAME_SPI_SO,                     //spi MISO pin
                    PINNAME_SPI_SI,                     //spi MOSI pin
                    PINNAME_SPI_CS,                     //spi CS pin, user can change this pin to annother pin
                    SPI_Interface_Type_Single_Unidir    //spi interface type
                    1					                //spi type, the parameter is reserved
                );
*****************************************************************/
QL_RET ql_spi_init(uint32 chnnlNo, Enum_PinName pinClk, Enum_PinName pinMiso, Enum_PinName pinMosi, Enum_PinName pinCs, SPI_INTERFACE_TYPE interfaceType, bool spiType);

/*****************************************************************
* Function:     ql_spi_config 
* 
* Description:
*               This function configures the SPI interface.
*
* Parameters:
*               chnnlNo:
*                   [In] SPI channel No, the No is specified by Ql_SPI_Init function.
*               isHost:
*                   [In] must be 'TRUE', not support salve mode .
*               clkMode:
*                   [In] Clock Mode.
*               dataSize:
*                   [In] Data Size.            
*               clkSpeed:
*                   [In] Clock Mode, the range of SPI speed is from 125kbps to 2Mbps.
*                        When clkSpeed is 0x02, the SPI speed is 2Mbps. 
*                        When clkSpeed is 0x04, the SPI speed is 1Mbps.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the SPI channel.
*               QL_RET_ERR_PARAM, SPI interface pins are not SPI contronller pins.
*               QL_RET_ERR_SPI_STATE_FAIL, SPI bus state is wrong.
*               QL_RET_ERR_INIT, can't claim SPI contronller pin, maybe is SPI contronller not initialization.
*======================
* Example:
*======================
*   you could use this api like this :
*   Ql_SPI_Config(  0,                  //spi channel
                    1,                  //spi master mode, now only supports master feature
                    SPI_CLK_MODE3,      //spi clock mode
                    0x08,               //spi data size
                    0x04,               //spi clock speed, the SPI speed is 1Mbps
                );
*****************************************************************/
QL_RET ql_spi_config(uint32 chnnlNo, bool isHost, SPI_CLOCK_MODE clkMode, uint8 dataSize, uint32 clkSpeed);

/*****************************************************************
* Function:     ql_spi_write 
* 
* Description:
*               This function writes data to the specified slave.
*               
* Parameters:
*               chnnlNo:
*                   [In] SPI channel No, the No is specified by Ql_SPI_Init function.
*               cmdBuff:
*                   [In] SPI Command buffer pointer.
*               cmdLen:
*                   [In] SPI Command buffer length.
*               dataBuff:
*                   [In] SPI data buffer pointer.
*               dataLen:
*                   [In] SPI data buffer length.
*               callBack:
*                   [In] SPI send data callback.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the SPI channel.
*               QL_RET_ERR_PARAM, SPI interface pins are not SPI contronller pins.
*               QL_RET_ERR_SPI_STATE_FAIL, SPI bus state is wrong.
*               QL_RET_ERR_SPI_BUS_BUSY, SPI bus is busy.
*               QL_RET_ERR_WRITE, write data failed.
*****************************************************************/
QL_RET ql_spi_write(uint32 chnnlNo,uint8* cmdBuff,uint16 cmdLen, uint8 * dataBuff, uint16 dataLen, SPI_CALLBACK_RET callBack);

/*****************************************************************
* Function:     ql_spi_read 
* 
* Description:
*               This function reads data from the specified slave.
*               
* Parameters:
*               chnnlNo:
*                   [In] SPI channel No, the No is specified by Ql_SPI_Init function.
*               cmdBuff:
*                   [In] SPI command buffer pointer.
*               cmdLen:
*                   [In] SPI Command buffer length.
*               dataBuff:
*                   [In] SPI data buffer pointer.
*               dataLen:
*                   [In] SPI data buffer length.
*               callBack:
*                   [In] SPI send data callback.
*               ignore_rx_while_tx:
*                   [In] .
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the I2C channel.
*               QL_RET_ERR_PARAM, SPI interface pins are not SPI contronller pins.
*               QL_RET_ERR_SPI_STATE_FAIL, SPI bus state is wrong.
*               QL_RET_ERR_SPI_BUS_BUSY, SPI bus is busy.
*               QL_RET_ERR_READ, receive data failed.
*****************************************************************/
QL_RET ql_spi_read(uint32 chnnlNo, uint8* cmdBuff,uint16 cmdLen, uint8* dataBuff, uint16 dataLen, SPI_CALLBACK_RET callBack,bool ignore_rx_while_tx);

/*****************************************************************
* Function:     ql_spi_uninit 
* 
* Description:
*               This function release the SPI pins.
*               
* Parameters:
*               chnnlNo:
*                   [In] SPI channel No, the No is specified by Ql_SPI_Init function.

* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the SPI channel, make sure it is initialized already.
*               QL_RET_ERR_SPI_RELEASE_FAIL, is released some error, Whether the pin is being used.
*               QL_RET_ERR_SPI_DEACTIVATE_FAIL, can't deactivate.
*****************************************************************/
QL_RET ql_spi_uninit(uint32 chnnlNo);

#endif  //__QL_SPI_H__
