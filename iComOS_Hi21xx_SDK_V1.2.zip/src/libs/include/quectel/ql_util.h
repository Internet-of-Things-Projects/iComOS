/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_util.h
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   UTIL API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_UTIL_H__
#define __QL_UTIL_H__

#include "ql_common.h"
#include "ql_error.h"

uint8 ql_util_hex_to_char(uint8 hex);

bool ql_util_char_to_hex(uint8 ch, uint8 *hex);

QL_RET ql_util_hex_to_string(char *str_buf, uint16 str_buf_size,uint8 *hex, uint16 hex_len);

/**
 * Convert packed BCD to a string
 * @param out pointer to output buffer at least (b_len + 1) long. The returned buffer is a null terminated string.
 * @param in input array in BCD format
 * @param b_len number of bytes to convert (maximum length of in array * 2
 * @return number of binary characters converted.
 */
int ql_util_bcd_to_string(char *str_buf, const uint8 *bcd, uint16 str_buf_size);

/**
 * Convert a string to packed BCD
 * tell it number of binary data items expected, convert string and get that number of bytes back
 * will zero fill trailing nibble if needed.
 * @param bin_data pointer to output buffer at least (bin_len + 1)/2 long
 * @param str_data the input buffer containing ascii decimal digits
 * @param bin_len  the number of characters in the input buffer
 * @return number of binary characters converted.
 */
int ql_util_string_to_bcd(uint8 *bcd_buf, const char *string, uint16 bcd_buf_size);

int ql_util_strindex(const char *str, const char *substr);

int ql_util_get_substring_split_by_comma(char *string, uint32 index, char* substring,uint32 subsize);

int ql_util_string_replace(char *string, char oldc,char newc);

QL_RET ql_util_hexstring_to_hex(uint8* hex_buf, const uint8* hexstr, uint16 hexstr_len);

#endif  //__QL_UTIL_H__
