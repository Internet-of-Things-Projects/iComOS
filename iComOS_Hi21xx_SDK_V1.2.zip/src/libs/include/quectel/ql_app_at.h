/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_app_at.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   AT parsing API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
 
#ifndef    __QL_APP_AT_H__
#define    __QL_APP_AT_H__
#include "ql_type.h"
#include "ql_error.h "

/** At command set callback
 * @param at_string The at string parameter to parse
 * @return result or at command
 */
typedef QL_RET(*QL_AT_CMD_SET)(uint8 *at_string);

/** At command read callback
 * @return result or at command
 */
typedef QL_RET(*QL_AT_CMD_READ)(void);

/** At command test callback
 * @return result or at command
 */
typedef QL_RET(*QL_AT_CMD_TEST)(void);

/** At command execute callback
 * @return result or at command
 */

typedef QL_RET(*QL_AT_CMD_EXEC)(void);


typedef enum
{
    QL_AT_FLAG_VISIABLE  = (1 << 1),
}QL_AT_FLAG;


typedef struct
{
    QL_AT_FLAG      flag;
    char *          cmd_str;
    QL_AT_CMD_SET   at_set_handler;
    QL_AT_CMD_READ  at_read_handler;
    QL_AT_CMD_TEST  at_test_handler;
    QL_AT_CMD_EXEC  at_exec_handler;
}QL_AT_CMD_CB_s;


#define QL_AT_PARSE_FIRST_PARAM_POS     0
#define QL_AT_PARSE_SECOND_PARAM_POS    1
#define QL_AT_PARSE_THIRD_PARAM_POS     2
#define QL_AT_PARSE_FOURTH_PARAM_POS    3
#define QL_AT_PARSE_FIFTH_PARAM_POS     4
#define QL_AT_PARSE_SIXTH_PARAM_POS     5
#define QL_AT_PARSE_SEVENTH_PARAM_POS   6
#define QL_AT_PARSE_EIGHTH_PARAM_POS    7
#define QL_AT_PARSE_NINTH_PARAM_POS     8
#define QL_AT_PARSE_TENTH_PARAM_POS     9
#define QL_AT_PARSE_ELEVENTH_PARAM_POS  10


/** Customer register At command callback
 * @return none
 */
typedef void(*QL_SET_APP_AT_CMD_CUSTOMER_CALLBACK)(void);


/*****************************************************************
* Function:     ql_app_at_cmd_customer_init 
* 
* Description:
*               This function is used to initialize the callback function of the AT command.
*
* Parameters:
*               callback:
*                   [In]Customer set registration AT command callback function.
*
* Return:               
*               None
*****************************************************************/ 
void ql_app_at_cmd_customer_init(QL_SET_APP_AT_CMD_CUSTOMER_CALLBACK callback);


/*****************************************************************
* Function:     ql_at_cmd_register 
* 
* Description:
*               This function is to register new AT command.
*
* Parameters:
*               ql_at_cmd_cb:
*                   [In]The pointer of AT command table.
*
* Return:               
*               True indicates that AT command registered successfully. 
*               False indicates that AT command registration failed.
*****************************************************************/
bool ql_at_cmd_register(const QL_AT_CMD_CB_s* ql_at_cmd_cb);


/*****************************************************************
* Function:     ql_at_create_param_array 
* 
* Description:
*               This function is to create AT command parameter array.
*
* Parameters:
*               p_atparams_string:
*                   [Out]The hexadecimal format string buffer to parse.
*               p_param_num:
*                   [Out]The buffer to store result.
*               param_minnum:
*                   [In]The minnum number of AT command parameters.
*               param_maxnum:
*                   [In]The maxmum number of AT command parameters.
*
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_MEMORY, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_create_param_array(uint8 *p_atparams_string, uint8 *p_param_num, uint8 param_minnum, uint8 param_maxnum);


/*****************************************************************
* Function:     ql_at_get_uint16_param 
* 
* Description:
*               This function is to get uint16 parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_uint16:
*                   [Out]The address to store AT command parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_uint16_param(uint8 seqno, uint16 *p_uint16, bool mandatory);


/*****************************************************************
* Function:     ql_at_get_uint8_param 
* 
* Description:
*               This function is to get uint8 parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_uint8:
*                   [Out]The address to store AT command parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_uint8_param(uint8 seqno, uint8 *p_uint8, bool mandatory);


/*****************************************************************
* Function:     ql_at_get_int16_param 
* 
* Description:
*               This function is to get int16 parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_int16:
*                   [Out]The address to store AT command parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_int16_param(uint8 seqno, int16 *p_int16, bool mandatory);


/*****************************************************************
* Function:     ql_at_get_uint32_param 
* 
* Description:
*               This function is to get uint32 parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_uint32:
*                   [Out]The address to store AT command parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_uint32_param(uint8 seqno, uint32 *p_uint32, bool mandatory);


/*****************************************************************
* Function:     ql_at_get_string_param 
* 
* Description:
*               This function is to get string parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_string:
*                   [Out]The address to store AT command parameter.
*               max_len:
*                   [In]The lenght of p_string parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_string_param(uint8 seqno, uint8 *p_string, uint16 max_len, bool mandatory);


/*****************************************************************
* Function:     ql_at_get_hexstring_param 
* 
* Description:
*               This function is to get Hexadecimal format string parameter.
*
* Parameters:
*               seqno:
*                   [In]The sequence number of AT command parameter.
*               p_hexstring:
*                   [Out]The buffer pointer of  Hexadecimal format string parameter.
*               p_hexstring_len:
*                   [Out]The lenght of p_hexstring parameter.
*               mandatory:
*                   [In]The AT command parameter is mandatory or not. 
*                       true:  AT command parameter is mandatory.
*                       false: AT command parameter is optional.
*              
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter error. 
*               QL_RET_ERR_PARAM_UNCONFIG, parameter is not configured.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_at_get_hexstring_param(uint8 seqno, uint8 **p_hexstring, uint16 *p_hexstring_len, bool mandatory);


/*****************************************************************
* Function:     ql_at_is_param_in_double_quotes 
* 
* Description:
*               This function is to query parameter is in double quotes or not.
*
* Parameters:
*               position:
*                   [In]The parameter position.
*              
* Return:               
*               True indicates that parameter is in double quotes.
*               False indicates that parameter is not in double quotes.
*****************************************************************/
bool ql_at_is_param_in_double_quotes(uint8 position);


/*****************************************************************
* Function:     ql_at_parse_buf_hex_to_uint8 
* 
* Description:
*               This function is to convert hexadecimal format string to uint8.
*
* Parameters:
*               source_buf_hex:
*                   [In]The hexadecimal format string buffer to parse.
*               dest_buf:
*                   [Out]The buffer to store result.
*               source_length:
*                   [In]The length of source_buf_hex.
*
* Return:               
*               True indicates that conversion is successful.
*               False indicates that conversion is failed.
*****************************************************************/
bool ql_at_parse_buf_hex_to_uint8(const uint8* source_buf_hex, uint8* dest_buf, uint16 source_length);


/*****************************************************************
* Function:     ql_at_parse_buf_hex_to_uint16 
* 
* Description:
*               This function is to convert hexadecimal format string to uint16.
*
* Parameters:
*               source_buf_hex:
*                   [In]The hexadecimal format string buffer to parse.
*               dest_value:
*                   [Out]The buffer to store result.
*               source_length:
*                   [In]The length of source_buf_hex
*
* Return:               
*               True indicates that conversion is successful.
*               False indicates that conversion is failed.
*****************************************************************/
bool ql_at_parse_buf_hex_to_uint16(const uint8* source_buf_hex, uint16 *dest_value, uint16 source_length);


/*****************************************************************
* Function:     ql_at_parse_buf_hex_to_uint64 
* 
* Description:
*               This function is to convert hexadecimal format string to uint64.
*
* Parameters:
*               source_buf_hex:
*                   [In]The hexadecimal format string buffer to parse.
*               dest_value:
*                   [Out]The buffer to store result.
*               source_length:
*                   [In]The length of source_buf_hex
*
* Return:               
*               True indicates that conversion is successful.
*               False indicates that conversion is failed.
*****************************************************************/
bool ql_at_parse_buf_hex_to_uint64(const uint8* source_buf_hex, uint64 *dest_value, uint16 source_length);


/*****************************************************************
* Function:     ql_app_at_send_at_rsp_string 
* 
* Description:
*               This function is to send AT command string through at uart.
*
* Parameters:
*               at_string:
*                   [In]The hexadecimal format string buffer to parse.
*               claim:
*                   [In]Claim at uart before send and release at uart after send or not.
*               log_flag:
*                   [In]flag for log print.
*
* Return:               
*               None
*****************************************************************/
void ql_app_at_send_at_rsp_string(const char *at_string, bool claim, QL_AT_FLAG log_flag);


/*****************************************************************
* Function:     ql_app_at_send_at_rsp_string_lines 
* 
* Description:
*               This function is to send at string through at uart and with "\r\n" string before, after AT command string.
*
* Parameters:
*               at_string:
*                   [In]The hexadecimal format string buffer to parse.
*               claim:
*                   [In]Claim at uart before send and release at uart after send or not.
*               log_flag:
*                   [In]flag for log print.
*
* Return:               
*               None
*****************************************************************/
void ql_app_at_send_at_rsp_string_lines(const char *at_string, bool claim, QL_AT_FLAG log_flag);


#endif // QL_APP_AT_H_
