/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_fota_iflash.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   fota iflash API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/

#ifndef    __QL_FOTA_IFLASH_H__
#define    __QL_FOTA_IFLASH_H__
#include "ql_type.h"
#include "ql_error.h "

/**
 * Callback for Flash write completion.
 * @param result flash written result which 0 indicating succeeded or indicating failed otherwise
 * @return none
 */
typedef void (*QL_FOTA_FLASH_WRITE_DONE_CB)(uint8 result);

/**
 * Callback for Flash erase completion.
 */
typedef void (*QL_FOTA_FLASH_ERASE_DONE_CB)(void);

/*****************************************************************
* Function:     ql_fota_iflash_get_capacity 
* 
* Description:
*               This function is to get the capacity of the FOTA flash space.
*
* Parameters:
*               None
*
* Return:               
*               Returns FOTA flash space capacity in bytes.
*****************************************************************/
uint32 ql_fota_iflash_get_capacity(void);


/*****************************************************************
* Function:     ql_initialise_fota 
* 
* Description:
*               This function initialize the FOTA update process such as allocate the FOTA related flash regions.
*
* Parameters:
*               erase_callback:
*                    [In]Callback to invoke when flash erase is complete, given the function returned success.
*
* Return:               
*               True indicates that fota is successfully initialized. 
*               False indicates that fota initialization failed.
*****************************************************************/
bool ql_initialise_fota(QL_FOTA_FLASH_ERASE_DONE_CB erase_callback);


/*****************************************************************
* Function:     ql_fota_iflash_write 
* 
* Description:
*               This function is to write data to the internal dedicated flash space.
*
*         Note:
*               Perform an erase flash operation before writing data.
*
* Parameters:
*               buffer:
*                   [In]Buffer with data to write.
*               offset:
*                   [In]From the beginning of the FOTA flash space, where to write the buffer.
*               length:
*                   [In]Buffer length.
*               done_callback:
*                    [In]Callback to invoke when flash write is complete, given the function returned true.
*
* Return:               
*               QL_RET_OK, The data written to the buffer was successful.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_FOTA_WRITE, write data error.
*****************************************************************/
QL_RET ql_fota_iflash_write(uint8* buffer, uint32 offset, uint16 length, QL_FOTA_FLASH_WRITE_DONE_CB done_callback);


/*****************************************************************
* Function:     ql_fota_package_upgrade_req 
* 
* Description:
*               This function is to upgrade the FOTA upgrade request.
*
* Parameters:
*               None
*
* Return:               
*               QL_RET_OK, The fota package upgrade was successful.
*               QL_RET_ERR_FOTA_UPGRADE, The fota upgrade upgrade error.
*****************************************************************/
QL_RET ql_fota_package_upgrade_req(void);

#endif // QL_FOTA_IFLASH_H_
