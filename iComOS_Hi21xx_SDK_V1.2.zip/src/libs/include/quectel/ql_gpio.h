/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_gpio.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   GPIO API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/


#ifndef __QL_GPIO_H__
#define __QL_GPIO_H__
#include "ql_type.h"
#include "ql_error.h "

#if (!defined(_MODULE_BC35_G_) && !defined(_MODULE_BC28_))
#error [ERROR: Please define module type! _MODULE_BC35_G_ or _MODULE_BC28_]
#endif



/****************************************************************************
 * Enumeration for GPIO Pins available.
 ***************************************************************************/
#if defined _MODULE_BC35_G_ 
typedef enum{
    PINNAME_SPI1_CS = 0,
    PINNAME_SPI1_SO,
    PINNAME_SPI1_CLK,
    PINNAME_SPI1_SI,
    PINNAME_UART3_TX,
    
    PINNAME_UART3_RX,
    PINNAME_SPI2_CS,
    PINNAME_SPI2_SO,
    PINNAME_SPI2_CLK,
    PINNAME_SPI2_SI,

    PINNAME_PIO_20,  //Danger: Cannot be used
	PINNAME_NETLIGHT,
    PINNAME_DBG_RXD,
    PINNAME_DTR,
    PINNAME_CTS,
    
    PINNAME_RTS,
    PINNAME_RI,
    PINNAME_I2C_SCL,
    PINNAME_I2C_SDA,
    PINNAME_SIM_DETECT,

    PINNAME_END,
}Enum_PinName;
#elif  defined _MODULE_BC28_
typedef enum{
    PINNAME_GPIO1 = 0,
    PINNAME_GPIO2,
    PINNAME_GPIO3,
    PINNAME_GPIO4,
    PINNAME_UART3_TX,
    
    PINNAME_UART3_RX,
	PINNAME_SPI_CS,
	PINNAME_SPI_SO,
	PINNAME_SPI_CLK,
	PINNAME_SPI_SI,


    PINNAME_GPIO5,//Danger: Cannot be used
	PINNAME_NETLIGHT,
    PINNAME_DBG_RXD,
    PINNAME_DTR,
    PINNAME_CTS,
    
    PINNAME_RTS,
    PINNAME_RI,
    PINNAME_NONE2,//Danger: Cannot be used
    PINNAME_NONE3,//Danger: Cannot be used
    PINNAME_SIM_DETECT,

    PINNAME_END,
}Enum_PinName;
#endif

typedef enum{
    PINDIRECTION_IN  = 0,
    PINDIRECTION_OUT = 1
}Enum_PinDirection;

typedef enum{
    PINLEVEL_LOW  = 0,
    PINLEVEL_HIGH = 1,
    PINLEVEL_NONE
}Enum_PinLevel;

typedef enum {
    /** Interrupt on rising edge of signal */
    PIN_INTERRUPT_RISING_EDGE=0,
    /** Interrupt on falling edge of signal */
    PIN_INTERRUPT_FALLING_EDGE,
    /** Interrupt on rising or falling edge of signal */
    PIN_INTERRUPT_ANY_EDGE,
    /** Interrupt when logic zero */
    PIN_INTERRUPT_LOW,
    /** Interrupt when logic one */
    PIN_INTERRUPT_HIGH,
} Enum_Interrupt_Mode;


typedef enum
{
    PIN_PULL_NONE,  //!< No pull down or pull up enabled
    PIN_PULL_DOWN,  //!< Pull down enabled for this pin
    PIN_PULL_UP     //!< Pull up enabled for this pin
} Enum_Gpio_Pull;

typedef void (*Ql_GPIO_CALLBACK)(uint8 pin);

/***************************************************************************
*not you can not change this value in this pin_map,otherwise the module work innormal 
***************************************************************************/

/****************************************************************************
 * GPIO Config Items
 ***************************************************************************/
typedef struct{
    Enum_PinName           pinName;
    Enum_PinDirection      pinDirection;  
    Enum_PinLevel          pinLevel;
}ST_GPIOConfig;

/*****************************************************************
* Function:     Ql_GPIO_Init 
* 
* Description:
*               This function enables the GPIO function of the specified pin,
*               and initialize the configurations, including direction and level.
*
*           Notes:
*               1. If the pin config input mode, set level status will be invalid.
*
*               2. If the GPIO pin used is in the L1 voltage domain, you need to use 
*                  ql_io_bank_open to open the voltage domain and determine if the GPIO 
*                  pin is in the L1 voltage domain.
*                  ------------------------------------------------------------------------
*                 | voltage domain	     |	    BC35-G PIN       |	    BC28 PIN	       |
*                  ------------------------------------------------------------------------
*		          |                      |	  PINNAME_SPI1_CS    |	   PINNAME_GPIO1       |
*		          |                      |	  PINNAME_SPI1_SO	 |	   PINNAME_GPIO2	   |
*		          |                      |	  PINNAME_SPI1_CLK	 |	   PINNAME_GPIO3	   |
*		          |                      |	  PINNAME_SPI1_SI	 |	   PINNAME_GPIO4	   |
*		          |                      |    PINNAME_SPI2_CS	 |	   PINNAME_SPI_CS	   |
*		          |                      |			 	         |			               |	
*		          |                      |	  PINNAME_SPI2_SO	 |     PINNAME_SPI_SO      |
*                 |  L1 voltage domain   |	  PINNAME_SPI2_CLK	 |	   PINNAME_SPI_CLK     |
*            	  |                      |	  PINNAME_SPI2_SI	 |	   PINNAME_SPI_SI      |
*		          |                      |	  PINNAME_UART3_RX	 |	   PINNAME_UART3_RX    |
*		          |                      |	  PINNAME_UART3_TX	 |	   PINNAME_UART3_TX    |
*		          |                      |				         |			               |
*		          |                      |	  PINNAME_I2C_SCL	 |	        /		       |
*		          |                      |	  PINNAME_I2C_SDA	 |	        /		       |
*                    ---------------------------------------------------------------------- 
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
*               dir:
*                   The initial direction of GPIO, one value of Enum_PinDirection.
*               level:
*                   The initial level of GPIO, one value of Enum_PinLevel. 
*            
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_init(Enum_PinName pinName, Enum_PinDirection dir, Enum_PinLevel level);

/*****************************************************************
* Function:     Ql_GPIO_SetLevel 
* 
* Description:
*               This function sets the level of the specified GPIO.
*
*         Note:
*               Input mode did not supports  set level state.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
*               level:
*                   The initial level of GPIO, one value of Enum_PinLevel. 
*
* Return:               
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_set_level(Enum_PinName pinName, Enum_PinLevel level);

/*****************************************************************
* Function:     Ql_GPIO_GetLevel 
* 
* Description:
*               This function gets the level of the specified GPIO.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
bool ql_gpio_get_level(Enum_PinName pinName);

/*****************************************************************
* Function:   Ql_GPIO_Pull_Config
* 
* Description:
*               This function config the gpio in pull down ,pull_up or no pull in init.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
*               Enum_Gpio_Pull 
*                   pull_type,the pull type to init the  gpio
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_pull_config(Enum_PinName pinName, Enum_Gpio_Pull pull_type);

/*****************************************************************
* Function:     Ql_GPIO_Uninit 
* 
* Description:
*               This function releases the specified GPIO that was 
*               initialized by calling Ql_GPIO_Init() previously.
*               After releasing, the GPIO can be used for other purpose.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_uninit(Enum_PinName pinName);

/*****************************************************************
* Function:     Ql_GPIO_Isq_CallBack_Register
* 
* Description:
*               This function set the pin as a interrupt pin.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
*               Enum_Interrupt_Mode:
*                   type  the type of pin to triger the interrupt
*               Ql_GPIO_CALLBACK :
*                   qi_isq_callback,when a isq occur,this function is called 
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_isq_callback_register(Enum_PinName pinName,Enum_Interrupt_Mode type,Ql_GPIO_CALLBACK qi_isq_callback);

/*****************************************************************
* Function:   Ql_GPIO_Isq_CallBack_Unregister
* 
* Description:
*               This function disable the interrupt function.
*
* Parameters:
*               pinName:
*                   Pin name, one value of Enum_PinName.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, param error. 
*               QL_RET_ERR_USED, The GPIO has beed used.
*               QL_RET_ERR_UNKNOWN, other error.
*****************************************************************/
QL_RET ql_gpio_isq_callback_unregister(Enum_PinName pinName);
#endif  // __QL_GPIO_H__
