/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_mqtt_api.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   MQTT API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_MQTT_H__
#define __QL_MQTT_H__
#include "ql_common.h"
#include "ql_error.h"


#define  QL_MQTT_MAX_SERVER_LEN             100    //MQTT server length
#define  QL_MQTT_CLIENT_MAX_LEN             128
#define  QL_MTCFG_TOPIC_MAX_LEN	            256
#define  QL_MTCFG_WILL_MSG_LEN 	            256

#define  QL_MTCFG_PROD_KEY_MAX_LEN		    (64+1)
#define  QL_MTCFG_DEV_NAME_MAX_LEN		    (64+1)
#define  QL_MTCFG_DEV_SECRET_MAX_LEN        (64+1)


#define  QL_MTCFG_MAX_VERSION_LEN           8
#define  QL_MTCFG_MAX_KEEPALIVE_LEN         10
#define  QL_MTCFG_MAX_SESSION_LEN           8
#define  QL_MTCFG_MAX_TIMEOUT_LEN           8
#define  QL_MTCFG_MAX_WILL_LEN              5
#define  QL_MTCFG_MAX_AIIAUTH_LEN           8

typedef struct mqtt_cfg_version
{
    char    version_type[QL_MTCFG_MAX_VERSION_LEN];
    int     tcpidx;
    uint8   vsn;
}QL_MQTT_CFG_VERSION;

typedef struct mqtt_cfg_keepalive
{
    char    keepalive_type[QL_MTCFG_MAX_KEEPALIVE_LEN];
    int     tcpidx;
    uint16  keepalve_time;
}QL_MQTT_CFG_KEEPALIVE;

typedef struct mqtt_cfg_session
{
    char    session_type[QL_MTCFG_MAX_SESSION_LEN];
    int     tcpidx;
    uint8   cln_session;
}QL_MQTT_CFG_SESSION;

typedef struct mqtt_cfg_timeout
{
    char    timeout_type[QL_MTCFG_MAX_TIMEOUT_LEN];
    int     tcpidx;
    int8    retry_times;
    uint16  pkt_timout;
    int8    timout_nte;
}QL_MQTT_CFG_TIMEOUT;

typedef struct mqtt_cfg_will
{
    char    will_type[QL_MTCFG_MAX_WILL_LEN];
    int     tcpidx;
    uint8   flag;
    uint8   qos;
    uint8   retain;
    uint8   topic[QL_MTCFG_TOPIC_MAX_LEN+1];
    uint8   msg[QL_MTCFG_WILL_MSG_LEN+1];
}QL_MQTT_CFG_WILL;

typedef struct mqtt_cfg_aliauth
{
    char    aliauth_type[QL_MTCFG_MAX_AIIAUTH_LEN];
    int     tcpidx;
    uint8   prod_key[QL_MTCFG_PROD_KEY_MAX_LEN];
    uint8   dev_name[QL_MTCFG_DEV_NAME_MAX_LEN];
    uint8   dev_secret[QL_MTCFG_DEV_SECRET_MAX_LEN];
}QL_MQTT_CFG_ALIAUTH;


typedef struct mqtt_cfg
{
    QL_MQTT_CFG_VERSION     version;
    QL_MQTT_CFG_KEEPALIVE   keepalive;
    QL_MQTT_CFG_SESSION     session;
    QL_MQTT_CFG_TIMEOUT     timeout;
    QL_MQTT_CFG_WILL        will;
    QL_MQTT_CFG_ALIAUTH     aliauth;
}QL_MQTT_CFG;

typedef struct mqtt_link_config
{
	int8 	tcpidx;
	uint16	port;
	char 	hostname[QL_MQTT_MAX_SERVER_LEN+1];
}QL_MQTT_LINK_CONFIG;

typedef void (*QL_MQTT_OPEN_CALLBACK)   (int8 tcpidx, int8  result);                         
typedef void (*QL_MQTT_CONN_CALLBACK)   (int8 tcpidx, int8  result, int8 ret_code);           
typedef void (*QL_MQTT_SUB_CALLBACK)    (int8 tcpidx, uint16 msgID, int8 result, uint8 value); 
typedef void (*QL_MQTT_PUB_CALLBACK)    (int8 tcpidx, uint16 msgID, int8 result, uint8 value);   
typedef void (*QL_MQTT_DISC_CALLBACK)   (int8 tcpidx, int8 result);                             
typedef void (*QL_MQTT_CLOSE_CALLBACK)  (int8 tcpidx, int8 result);                             
typedef void (*QL_MQTT_UNS_CALLBACK)    (int8 tcpidx, uint16 msgID, int8 result);             
typedef void (*QL_MQTT_STAT_CALLBACK)   (int8 tcpidx, uint8 err_code);                         
typedef void (*QL_MQTT_RECV_CALLBACK)   (int8 tcpidx, uint16 msgID, uint8 *topic, uint8 *recv_payload);

typedef struct ql_mqtt_callback
{
    QL_MQTT_OPEN_CALLBACK       ql_mqtt_open_callback;
    QL_MQTT_CONN_CALLBACK       ql_mqtt_conn_callback;
    QL_MQTT_SUB_CALLBACK        ql_mqtt_sub_callback;
	QL_MQTT_RECV_CALLBACK       ql_mqtt_recv_callback;
    QL_MQTT_DISC_CALLBACK       ql_mqtt_disc_callback;
    QL_MQTT_CLOSE_CALLBACK      ql_mqtt_close_callback;
    QL_MQTT_UNS_CALLBACK        ql_mqtt_uns_callback;
    QL_MQTT_PUB_CALLBACK        ql_mqtt_pub_callback;
	QL_MQTT_STAT_CALLBACK       ql_mqtt_stat_callback;
}QL_MQTT_CALLBACK;


/*****************************************************************
* Function:     ql_mqtt_set_config 
* 
* Description:
*               This function is used to configure optional parameters of MQTT.
*               
* Parameters:
*               QL_MQTT_CFG:
*                   [In] Pointer of confiuraton parameters.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_SYNTAX_ERROR, The syntax in the parameter is incorrect.
*****************************************************************/
QL_RET ql_mqtt_set_config(QL_MQTT_CFG * ql_mqtt_cfg);


/*****************************************************************
* Function:     ql_mqtt_init 
* 
* Description:
*               This function is used to initialize the parameter configuration of MQTT.
*               
* Parameters:
*               None
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*****************************************************************/
QL_RET ql_mqtt_init(void);

/*****************************************************************
* Function:     ql_mqtt_open 
* 
* Description:
*               This function is used to open a network for MQTT client.
*               
* Parameters:
*               ql_mqtt_link_config:
*                   [In] Pointer of link parameters.
*               ql_mqtt_callback:
*                   [In] Struct of callback function, all operation related message will be
*                        passed by call corresponding call back function.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_IDX_INVALID, MQTT socket identifier failed.
*****************************************************************/
QL_RET ql_mqtt_open(QL_MQTT_LINK_CONFIG *ql_mqtt_link_config, QL_MQTT_CALLBACK ql_mqtt_callback);

/*****************************************************************
* Function:     ql_mqtt_connect 
* 
* Description:
*               This function is used to when a client requests a connection to MQTT server.             
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*               clientId:
*                   [In] The client identifier string.
*               username:
*                   [In] User name of the client. It can be used for authentication.
*               password:
*                   [In] Password corresponding to the user name of the client. It can be 
*                        used for authentication.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_UNINITIALIZED, uninitialize the parameter configuration of MQTT. 
*               QL_RET_ERR_MQTT_CONNECTPKT, connection packet failed.
*               QL_RET_ERR_MQTT_SENDPKT, send packet failed.
*               QL_RET_ERR_UNKNOWN, some unknown error.
*****************************************************************/
QL_RET ql_mqtt_connect(int8 tcpidx, uint8* clientId, uint8* username, uint8* password);

/*****************************************************************
* Function:     ql_mqtt_subscribe 
* 
* Description:
*               This function is used to subscribe to a topics.         
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*               pktId:
*                   [In] Message identifier of packet.
*               topic:
*                   [In] Topic that the client wants to subscribe to or unsubscribe from.
*               qos:
*                   [In] QoS level at which the client wants to publish the messages.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_SYNTAX_ERROR, the syntax in the parameter is incorrect.
*               QL_RET_ERR_MQTT_UNINITIALIZED, uninitialize the parameter configuration of MQTT. 
*               QL_RET_ERR_MQTT_STATUS_ERROR, the link status failed.
*               QL_RET_ERR_MQTT_PACKSUB_FAIL, subscribe packet failed.
*               QL_RET_ERR_MQTT_SENDPKT, send packet failed.
*               QL_RET_ERR_UNKNOWN, some unknown error.
*****************************************************************/
QL_RET ql_mqtt_subscribe(int8 tcpidx, uint16 pktId, uint8* topic, uint8 qos);

/*****************************************************************
* Function:     ql_mqtt_publish 
* 
* Description:
*               This function is used to  publish messages by a client to a server for distribution 
*               to interested subscribers.        
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*               pktId:
*                   [In] Message identifier of packet.
*               qos:
*                   [In] QoS level at which the client wants to publish the messages.
*               retain:
*                   [In] Whether or not the server will retain the message after it has been delivered
*                        to the current subscribers.
*               topic:
*                   [In] Topic that needs to be published.
*               send_payload:
*                   [In] send payload that relates to the topic name.
*               payload_len:
*                   [In] Length of the send_payload parameter.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_UNINITIALIZED, uninitialize the parameter configuration of MQTT. 
*               QL_RET_ERR_MQTT_STATUS_ERROR, the link status failed.
*****************************************************************/
QL_RET ql_mqtt_publish(int8 tcpidx, uint16 pktId, uint8 qos, uint16 retain, uint8* topic,uint8 *send_payload, uint16 payload_len);

/*****************************************************************
* Function:     ql_mqtt_unsubscribe 
* 
* Description:
*               This function is used to unsubscribe to a topics.         
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*               pktId:
*                   [In] Message identifier of packet.
*               topic:
*                   [In] Topic that the client wants to subscribe to or unsubscribe from.
*               qos:
*                   [In] QoS level at which the client wants to publish the messages.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_SYNTAX_ERROR, the syntax in the parameter is incorrect.
*               QL_RET_ERR_MQTT_UNINITIALIZED, uninitialize the parameter configuration of MQTT. 
*               QL_RET_ERR_MQTT_STATUS_ERROR, the link status failed.
*               QL_RET_ERR_MQTT_PACKSUB_FAIL, subscribe packet failed.
*               QL_RET_ERR_MQTT_SENDPKT, send packet failed.
*               QL_RET_ERR_UNKNOWN, some unknown error.
*****************************************************************/
QL_RET ql_mqtt_unsubscribe(int8 tcpidx, uint16 pktId, uint8* topic);

/*****************************************************************
* Function:     ql_mqtt_disconnect 
* 
* Description:
*               This function is used when a client requests a disconnection from MQTT server.         
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_SYNTAX_ERROR, the syntax in the parameter is incorrect.
*               QL_RET_ERR_MQTT_STATUS_ERROR, the link status failed.
*               QL_RET_ERR_MQTT_SENDPKT, send packet failed.
*               QL_RET_ERR_MQTT_RELEASE_FAIL, failed to release connection.
*****************************************************************/
QL_RET ql_mqtt_disconnect(int8 tcpidx);

/*****************************************************************
* Function:     ql_mqtt_close 
* 
* Description:
*               This function is used close a network for MQTT client.        
*
* Parameters:
*               tcpidx:
*                   [In] MQTT socket identifier. Currently, the value is always 0.
*
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_MQTT_SYNTAX_ERROR, the syntax in the parameter is incorrect.
*               QL_RET_ERR_MQTT_STATUS_ERROR, the link status failed.
*               QL_RET_ERR_MQTT_SENDPKT, send packet failed.
*               QL_RET_ERR_MQTT_RELEASE_FAIL, failed to release connection.
*****************************************************************/
QL_RET ql_mqtt_close(int8 tcpidx);

#endif  //__QL_MQTT_API_H__