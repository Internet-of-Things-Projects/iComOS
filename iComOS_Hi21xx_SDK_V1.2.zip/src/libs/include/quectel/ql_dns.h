/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_dns.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   DNS API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/

#ifndef __QL_DNS_H__
#define __QL_DNS_H__

#include "ql_common.h"
#include "ql_error.h"


typedef enum
{
	DNS_MODE_RESOLVE  = 0,
	DNS_MODE_DELETE   = 1
}QL_DNS_MODE;


typedef void (*ql_dns_parse_callback)(char*);


/*****************************************************************
* Function: 	ql_dns_set_config
*
* Description:
*				 Initializing parameter configuration related to dns domain  resolution
*
* Parameters:
*				max_attempts:
*					 [In]Maximum number of attempts. default:3 times.
*               wait_timeout: 
*                    [In]Single timeout.  default:100s
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*****************************************************************/
QL_RET ql_dns_set_config(uint8	max_attempts,uint32	wait_timeout);


/*****************************************************************
* Function: 	ql_dns_get_config
*
* Description:
*				 get parameter configuration related to dns domain  resolution
*
* Parameters:
*				max_attempts:
*					 [Out]Maximum number of attempts. default:3 times.
*				wait_timeout: 
*					 [Out]Single timeout.  default:100s
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*****************************************************************/
QL_RET ql_dns_get_config(uint8 *max_attempts,uint32	*wait_timeout);


/*****************************************************************
* Function: 	ql_dns_set_server_addr
*
* Description:
*				 Set the DNS server IP address
*
* Parameters:
*				pri_dnsip:
*					 [In]Preferred dns ip.  
*				sec_dnsip: 
*					 [In]Alternate dns ip.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_dns_set_server_addr(const char* pri_dnsip,const char* sec_dnsip);


/*****************************************************************
* Function: 	ql_dns_get_server_addr
*
* Description:
*				 Get the DNS server IP address
*
* Parameters:
*				pri_dnsip:
*					 [In]Preferred dns ip.	default:218.4.4.4
*				sec_dnsip: 
*					 [In]Alternate dns ip.	default:208.67.222.222
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_dns_get_server_addr(char* pri_dnsip,char* sec_dnsip);

/*****************************************************************
* Function: 	ql_dns_parse_hostname
*
* Description:
*				resolve domain name
*
* Parameters:
*				mode:
*					 [In]DNS_MODE_RESOLVE/DNS_MODE_DELETE.
*				hostname: 
*					 [In]string type, domain name.
*				parse_callback: 
*					 [In]Domain name resolution callback function, when mode=DNS_MODE_DELETE, it can be NULL..
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*               QL_RET_ERR_MEMORY:
*                         Memory allocation failed
*****************************************************************/
QL_RET ql_dns_parse_hostname(QL_DNS_MODE mode, const char* hostname,ql_dns_parse_callback parse_callback);

#endif  //__QL_DNS_H__
