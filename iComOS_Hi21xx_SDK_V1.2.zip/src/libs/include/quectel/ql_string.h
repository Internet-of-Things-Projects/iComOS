/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_string.h
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   STRING API defines.
 *
 * Author: Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_STRING_H__
#define __QL_STRING_H__
#include "ql_type.h"
#ifndef NULL
#define NULL ((void *)0)
#endif

extern	void *memcpy(void *s1, const void *s2, size_t n);
extern	void *memmove(void *s1, const void *s2, size_t n);
extern	char *strcpy(char *s1, const char *s2);
extern	char *strncpy(char *s1, const char *s2, size_t n);
extern	size_t strlcpy(char *s1, const char *s2, size_t n);
extern	char *strcat(char *s1, const char *s2);
extern	char *strncat(char *s1, const char *s2, size_t n);
extern	size_t strlcat(char *s1, const char *s2, size_t n);
extern	int memcmp(const void *s1, const void *s2, size_t n);
extern	int strcmp(const char *s1, const char *s2);
extern	int strncmp(const char *s1, const char *s2, size_t n);
extern	void *memchr(const void *s, int c, size_t n);
extern	char *strchr(const char *s, int c);
extern	char *strrchr(const char *s, int c);
extern	char *strstr(const char *s1, const char *s2);
extern	void *memset(void *s, int c, size_t n);
extern	size_t strlen(const char *s);
extern  size_t strspn(const char *s1, const char *s2);
extern  char* strtok(char *s1, const char *s2);
extern  char* strsep(char **s1, const char *s2);
extern  int snprintf(char *s, size_t size, const char * format, ...);
#endif  //__QL_STRING_H__
