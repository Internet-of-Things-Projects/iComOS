/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_system.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   SYSTEM API defines.
 *
 * Author: Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/

#ifndef __QL_SYSTEM_H__
#define __QL_SYSTEM_H__
#include "ql_common.h"
#include "ql_error.h"

#define QL_MANUFACTURER_IDENTITY_MAX_LEN        40

#define QL_SERIAL_NUMBER_MAX_LEN                16

typedef struct 
{
    uint32  current_allocated;
    uint32  total_free;
    uint32  max_free;
    uint32  num_allocs;
    uint32  num_frees;
} QL_UESTATS_APPSMEM;

typedef struct 
{
    int tm_sec;
    int tm_min;
    int tm_hour;
    int tm_day;
    int tm_mon;
    int tm_year;
    int tm_zone;
}QL_TIME;

/**
 * This is a special enum, it is split into three sections
 * Only 16 bits are used.
 * Bits 13 to 15 are flags setting which core caused the reboot
 * Bit 8 sets if the reset reason is custom or fixed
 * Bits 0 to 7 contain the reason
 *
 * If Bit 8 is set then the reasons are Unknown (0), SysReset(1), Watchdog(2) for the apps and the protocol cores
 * The security core has two extra reasons - Self (4) and AltBoot(8)
 * It should not be possible to get reset reason 0 on the Apps or protocol cores. (0xX100)
 */
typedef enum
{
    QL_REBOOT_CAUSE_UNKNOWN                          = 0x0000, //!< Used as a default for the reboot_reset_reason variable
    //Security core reset reasons
    QL_REBOOT_CAUSE_SECURITY_RESET_UNKNOWN           = 0x8000, //!< Should never happen - unknown reset reason
    QL_REBOOT_CAUSE_SECURITY_SYSRESETREQ             = 0x8001, //!< Only possible if the codeloader reboot command was sent, or on a codeloader change speed error
    QL_REBOOT_CAUSE_SECURITY_WATCHDOG                = 0x8002, //!< This watchdog is not currently used (see chip_watchdog bellow).
    QL_REBOOT_CAUSE_SECURITY_SECURITY                = 0x8003, //!< Security core did a soft reset with no other reason stored, apart from HW error, No known causes
    QL_REBOOT_CAUSE_SECURITY_ALTBOOT                 = 0x8004, //!< ROM Failure, apart from HW error, not currently possible
    QL_REBOOT_CAUSE_SECURITY_RESET_REG_0             = 0x8005, //!< Security core did a soft reset with no other reason stored, apart from HW error, No known causes
    QL_REBOOT_CAUSE_SECURITY_RESET_REG_3             = 0x8006, //!< Security core did a soft reset with no other reason stored, apart from HW error, No known causes
    QL_REBOOT_CAUSE_SECURITY_STANDARD_CHIP_WATCHDOG  = 0x8007, //!< Security core could not kick the watchdog in time - If seen, check that the apps->security interrupt line is not being over used
    QL_REBOOT_CAUSE_SECURITY_SCAN_ENTER_EXIT         = 0x8008, //!< Only possible in non-standard test modes
    QL_REBOOT_CAUSE_SECURITY_PMU_POR                 = 0x8009, //!< Power management unit start up - BlackOut/BrownOut/PowerOn
    QL_REBOOT_CAUSE_SECURITY_RESET_PIN               = 0x800A, //!< Reset line was toggled

    QL_REBOOT_CAUSE_SECURITY_MONITOR_REBOOT_REQ      = 0x8100, //!< Placeholder: Start of security custom reset reasons
    QL_REBOOT_CAUSE_SECURITY_REGIONS_UPDATED,                  //!< The Security core updated its mapped in memory regions - No known causes
    QL_REBOOT_CAUSE_SECURITY_FOTA_UPGRADE,                     //!< QL_REBOOT_CAUSE_SECURITY_FOTA_UPGRADE
    QL_REBOOT_CAUSE_SECURITY_UPDATER_CHIP_WATCHDOG,            //!< Updater core hit the NMI handler and waited for the watchdog

    //Protocol core reset reasons
    QL_REBOOT_CAUSE_PROTOCOL_GLOBAL                  = 0x4000, //!< Start of the Protocol reboot reasons
    QL_REBOOT_CAUSE_PROTOCOL_SYSRESETREQ             = 0x4001, //!< The Protocol core reset its self with the SYSRESETREQ internal line - No known causes
    QL_REBOOT_CAUSE_PROTOCOL_WATCHDOG                = 0x4002, //!< The Protocol cores watchdog fired
    QL_REBOOT_CAUSE_PROTOCOL_SECURITY                = 0x4003, //!< The Security core reset the Protocol core with no additional reason given - No known causes
    QL_REBOOT_CAUSE_PROTOCOL_RESERVED_1              = 0x4004, //!< Not Possible, left in for enum compatibility with the security core
    QL_REBOOT_CAUSE_PROTOCOL_RESET_REG_0             = 0x4005, //!< The Security core reset the Protocol core with no additional reason given - No known causes
    QL_REBOOT_CAUSE_PROTOCOL_RESET_REG_3             = 0x4006, //!< The Security core reset the Protocol core with no additional reason given - No known causes

    QL_REBOOT_CAUSE_PROTOCOL_MONITOR_REBOOT_REQ      = 0x4100, //!< Placeholder: Start of protocol custom reset reasons
    QL_REBOOT_CAUSE_PROTOCOL_RPC_TIMEOUT,                      //!< A timeout on the RPC inter-core communication layer, another core failed to respond in time
    QL_REBOOT_CAUSE_PROTOCOL_IMSI_UPDATE,                      //!< A new IMSI was received

    //Application core reset reasons
    QL_REBOOT_CAUSE_APPLICATION_GLOBAL               = 0x2000, //!< Start of the Application reboot reasons
    QL_REBOOT_CAUSE_APPLICATION_SYSRESETREQ          = 0x2001, //!< The Application core reset its self with the SYSRESETREQ internal line
    QL_REBOOT_CAUSE_APPLICATION_WATCHDOG             = 0x2002, //!< The Application cores watchdog fired
    QL_REBOOT_CAUSE_APPLICATION_SECURITY             = 0x2003, //!< The Security core reset the Application core with no additional reason given - No known causes
    QL_REBOOT_CAUSE_APPLICATION_RESERVED_1           = 0x2004, //!< Not Possible, left in for enum compatibility with the security core
    QL_REBOOT_CAUSE_APPLICATION_RESET_REG_0          = 0x2005, //!< The Security core reset the Application core with no additional reason given - No known causes
    QL_REBOOT_CAUSE_APPLICATION_RESET_REG_3          = 0x2006, //!< The Security core reset the Application core with no additional reason given - No known causes

    QL_REBOOT_CAUSE_APPLICATION_MONITOR_REBOOT_REQ   = 0x2100, //!< Placeholder: Start of Application custom reset reasons
    QL_REBOOT_CAUSE_APPLICATION_AT,                            //!< The AT command processor requested a reboot
    QL_REBOOT_CAUSE_APPLICATION_RPC_TIMEOUT,                   //!< A timeout on the RPC inter-core communication layer, another core failed to respond in time
	QL_REBOOT_CAUSE_APPLICATION_OPENCPU,
} QL_REBOOT_CAUSE;


/**
 * @brief reboot system. Be similar to AT+NRB
 */
/*****************************************************************
* Function: 	ql_reboot 
* 
* Description:
*				reboot system. Be similar to AT+NRB.
*
* Parameters:
*				none
*						
* Return:		 
*				none
*
*****************************************************************/
void ql_reboot(void);


/*****************************************************************
* Function:     ql_get_reboot_cause 
* 
* Description:
*               Gets the reason of the last reset.
*
* Parameters:
*               cause:
*                       [out] Return to the last reason for reboot
* Return:        
*               Returns the string information of the last reason for the reboot
*
*****************************************************************/
char* ql_get_reboot_cause(QL_REBOOT_CAUSE* cause);


/*****************************************************************
* Function: 	ql_get_imei 
* 
* Description:
*				Return the IMEI in the location pointed by imei . Be similar to AT+CGSN=1
*
* Parameters:
*				imei_string:
*						[out] buffer to save imei number string
*               buf_len:
*                       [in] sizeof of input buffer
* Return:		 
*				QL_RET_OK:
*                         indicates this function successes.
*               QL_RET_ERR_PARAM:
*                         Invalid argument.
*
*****************************************************************/
QL_RET ql_get_imei(char * imei_string, uint8 buf_len);


/*****************************************************************
* Function: 	ql_get_serial_number 
* 
* Description:
*				Return the SERIAL_NUMBER in the location pointed by serialnumber.
*
* Parameters:
*				serialnumber:
*						[out] buffer to save serial number string
*				buf_len:
*						[in] sizeof of input buffer
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Invalid argument.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_serial_number (uint8 *serialnumber,uint8 buf_len);


/*****************************************************************
* Function: 	ql_get_application_version 
* 
* Description:
*				Return the application core version
*
* Parameters:
*				version_string_length:
*						[out] application version string length
*				version_string:
*						[in] buffer to save version string
*				buff_length:
*						[in] size of of input buffer
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_application_version(uint16 *version_string_length, char *version_string, uint16 buff_length);


/*****************************************************************
* Function: 	ql_get_baseline_version 
* 
* Description:
*				Return the baseline core version
*
* Parameters:
*				version_string_length:
*						[out] baseline version string length
*				version_string:
*						[in] buffer to save version string
*				buff_length:
*						[in] size of of input buffer
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_baseline_version(uint16 *version_string_length, char *version_string, uint16 buff_length);


/*****************************************************************
* Function: 	ql_get_current_time 
* 
* Description:
*				Return the current time
*
* Parameters:
*				current_time:
*						[Out] pointer to current_time
*
* Return:		 
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_NOT_SUPPORT:
*						  Operation cannot be supported.
*                         (Check if the UE is attached to the network)
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_current_time(QL_TIME* current_time);


/*****************************************************************
* Function: 	ql_get_iccid 
* 
* Description:
*				Return card identification of the installed SIM (+NCCID?/+NCCID)
*
* Parameters:
*				iccid:
*						[in] buffer to save iccid string
*				iccid_len:
*						[out] iccid string length
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_iccid( char *iccid , uint16 *iccid_len);


/*****************************************************************
* Function: 	ql_get_chipinfo 
* 
* Description:
*				read chip information(voltage and temperature)
*
* Parameters:
*				vbat:
*						[out] pointer to vbat
*				temp:
*						[out] pointer to temperature
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_chipinfo(uint16 *vbat,uint16* temp);


/*****************************************************************
* Function: 	ql_get_uestats_appsmem 
* 
* Description:
*				get UE status with dynamic memory usage read. Be similar to AT+NUESTATS=APPSMEM
* Parameters:
*				mem_stats:
*						[out] pointer to memory states
*				cell_info_num:
*						[out] get cell infomation numbers
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter.
*****************************************************************/
QL_RET ql_get_uestats_appsmem(QL_UESTATS_APPSMEM *mem_stats);


/*****************************************************************
* Function: 	ql_get_random 
* 
* Description:
*				get a random number by hardware
*
* Parameters:
*				random:
*						[out] pointer to buffer for the random number
*				random_request_len:
*						[in] length of random number requested in bytes
* Return:		 
*				QL_RET_OK:
*						  indicates this function successes.
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_random(uint8 *random, uint16 random_request_len);


/*****************************************************************
* Function: 	ql_add_stop_clocksveto 
* 
* Description:
*			   Add a veto on RTOS stopping the system clocks
*              If there is a veto on stopping the system clocks then the tickless RTOS operation will not be able to go into a low power sleep.
*		       Many vetoes may be independently added or removed; one or more will prevent RTOS stopping the system clocks.
*		       This function may be called in an interrupt context
*		       This function is thread safe and may be called before or after the RTOS scheduler is started
*
* Parameters:
*				none
* Return:		 
*				none
*****************************************************************/
void ql_add_stop_clocksveto(void);


/*****************************************************************
* Function: 	ql_remove_stop_clocksveto 
* 
* Description:
*			   Remove a veto on RTOS stopping the system clocks
*			   If there is a veto on stopping the system clocks then the tickless RTOS operation will not be able to go into a low power sleep.
*			   Many vetoes may be independently added or removed; one or more will prevent RTOS stopping the system clocks.
*			   This function may be called in an interrupt context
*			   This function is thread safe and may be called before or after the RTOS scheduler is started
*
* Parameters:
*				none
* Return:		 
*				none
*****************************************************************/
void ql_remove_stop_clocksveto(void);

/*****************************************************************
* Function: 	ql_get_sdklib_ver 
* 
* Description:
*				Return the opencpu sdklib version
*
* Parameters:
*				none
* Return:		 
*				pointer to the opencpu sdklib string
*****************************************************************/
char* ql_get_sdklib_ver(void);

#endif  //__QL_SYSTEM_H__
