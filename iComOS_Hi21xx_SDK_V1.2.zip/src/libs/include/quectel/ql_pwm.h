/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_pwm.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   PWM API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
 
#ifndef __QL_PWM_H__
#define __QL_PWM_H__
#include "ql_type.h"
#include "ql_error.h "

/** If the period_cycles is 500 and the duty_cycle is 200, then  duty ratio 200/1000, High level occupies 500*(200/1000), low level occupies 500*(1-200/1000) */
typedef struct
{
    /** Clock cycles spent in on phase */
    uint32 period_cycles;
    /** Duty cycle (parts per 1000) */
    uint16 duty_cycle;
} PWM_DATA_CONFIG;


typedef struct
{
    /** PWM data count, indicate the PWM configuration counter */
    uint8 count;
    /** PWM cycles (on and off) used for interrupts or stop */
    uint8 cycles;
    /** Flag to indicate the transmission should start again when finished */
    /** If repeat is 1, repeated output waveform, if repeat is 0, not repeated output waveform,*/
    uint8 repeat;
} PWM_BASE_CONFIG;

//#pragma pack () 
typedef void (*PWM_CALLBACK_CHNNLNO)(uint32 chnnlNo);
/*****************************************************************
* Function:     ql_pwm_init 
* 
* Description:
*               This function initializes the PWM pin. 
*
*               NOTES:
*                   The PWM waveform can't out immediately after ql_pwm_init Initialization,you must 
*                   invoke ql_pwm_cycleoutput/ql_pwm_msoutput/ql_pwm_usoutput function to control output pwm
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the parameter support channel is 0 or 1.
*               pinName:
*                   [In] Pin name.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, the input parameter is invalid. 
*               QL_RET_ERR_INIT, can't claim PWM contronller pin, maybe is PWM contronller not initialization.
*****************************************************************/
QL_RET ql_pwm_init(uint32 chnnlNo,Enum_PinName pwmPinName);

/*****************************************************************
* Function:     ql_pwm_cycleoutput 
* 
* Description:
*               This function is to output cycle PWM waveform.
*
*               NOTES:
*               1. If it is necessary to output the PWM waveform all the time, 
*               the A core is prohibited from enter the idle state and the PSM state.
*               2. The function output is related to the system clock.
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
*               pinName:
*                   [In] Pin name.
*               pwmDataConfig:
*                   [In] PWM data configuration, configure duty cycle and period.
*                   period_cycles is pwm period cycles, the value parameter range is 1 - 0xFFFFFFFE.
*                   duty_cycle is PWM duty cycle. eg.If duty_cycle is 500, PWM duty cycle is 50%.
*               pwmBaseConfig:
*                   [In] PWM base configuration, configure the number of pwm data, 
*                   how many cycles to cycle, and whether to repeat the loop.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, the input parameter is invalid. 
*****************************************************************/
QL_RET ql_pwm_cycleoutput(uint32 chnnlNo,PWM_DATA_CONFIG pwmDataConfig,PWM_BASE_CONFIG pwmBaseConfig);

/*****************************************************************
* Function:     ql_pwm_msoutput 
* 
* Description:
*               This function is to output millisecond level PWM waveform.
*
*               NOTES:
*               If it is necessary to output the PWM waveform all the time, 
*               the A core is prohibited from enter the idle state and the PSM state.
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
*               pinName:
*                   [In] Pin name.
*               pwmDataConfig:
*                   [In] PWM data configuration, configure duty cycle and period.
*                   period_cycles is pwm period cycles, the value parameter range is 1 ~ 300.
*                   duty_cycle is PWM duty cycle. eg.If duty_cycle is 500, PWM duty cycle is 50%.
*               pwmBaseConfig:
*                   [In] PWM base configuration, configure the number of pwm data, 
*                   [In] how many cycles to cycle, and whether to repeat the loop.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, the input parameter is invalid. 
*****************************************************************/
QL_RET ql_pwm_msoutput(uint32 chnnlNo,PWM_DATA_CONFIG pwmDataConfig,PWM_BASE_CONFIG pwmBaseConfig);

/*****************************************************************
* Function:     ql_pwm_usoutput 
* 
* Description:
*               This function is to output microsecond level PWM waveform.
*
*               NOTES:
*               If it is necessary to output the PWM waveform all the time, 
*               the A core is prohibited from enter the idle state and the PSM state.
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
*               pinName:
*                   [In] Pin name.
*               pwmDataConfig:
*                   [In] PWM data configuration, configure duty cycle and period.
*                   period_cycles is pwm period cycles, the value parameter range is 1 ~ 5000.
*                   duty_cycle is PWM duty cycle. eg.If duty_cycle is 500, PWM duty cycle is 50%.
*               pwmBaseConfig:
*                   [In] PWM base configuration, configure the number of pwm data, 
*                   how many cycles to cycle, and whether to repeat the loop.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already.
*               QL_RET_ERR_PARAM, the input parameter is invalid. 
*****************************************************************/
QL_RET ql_pwm_usoutput(uint32 chnnlNo,PWM_DATA_CONFIG pwmDataConfig,PWM_BASE_CONFIG pwmBaseConfig);

/*****************************************************************
* Function:     ql_pwm_uninit 
* 
* Description:
*               This function release a PWM pin.
*
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already. 
*****************************************************************/
QL_RET ql_pwm_uninit(uint32 chnnlNo);

/*****************************************************************
* Function:     ql_pwm_register_interrupt 
* 
* Description:
*               This function regist PWM interruption.
*
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
*               callback:
*                   [In] PWM interrupt callback.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already. 
*               QL_RET_ERR_PARAM, the input parameter is invalid. 
*****************************************************************/
QL_RET ql_pwm_register_interrupt(uint32 chnnlNo, PWM_CALLBACK_CHNNLNO callback);

/*****************************************************************
* Function:     ql_pwm_unregister_interrupt 
* 
* Description:
*               This function unregist PWM interruption.
*
* Parameters:
*               chnnlNo:
*                   [In] PWM channel No, the No is specified by ql_pwm_init function.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_CHANNEL_NOT_FOUND, can't found the PWM channel, make sure it is initialized already. 
*****************************************************************/
QL_RET ql_pwm_unregister_interrupt(uint32 chnnlNo);

#endif  //__QL_PWM_H__
