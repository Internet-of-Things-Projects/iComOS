/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_malloc.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   MALLOC API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_MALLOC_H__
#define __QL_MALLOC_H__

extern void *irzalloc(size_t size);
extern void irfree(void *buf); 

//#define  QL_MEM_DEBUG_PRINT  

#ifdef QL_MEM_DEBUG_PRINT
void* malloc_print(uint32 size);

#define ql_malloc(_size) malloc_print(_size); ql_dbg_trace("QL_MEM in:%s,line:%d",__func__,__LINE__)

#define ql_free(ptr) \
{\
	if (NULL != ptr)\
	{\
		ql_dbg_trace("QL_MEM qfree ===========:0x%08x",(uint32)ptr);\
	    irfree((ptr));\
	    (ptr) = NULL;\
	}\
}
#else 
#define ql_malloc(_size) irzalloc(_size)
#define ql_free(ptr) \
{\
	if (NULL != ptr)\
	{\
	    irfree((ptr));\
	    (ptr) = NULL;\
	}\
}
#endif

#endif  //__QL_MALLOC_H__
