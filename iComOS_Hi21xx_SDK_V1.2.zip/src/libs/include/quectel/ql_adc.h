/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_adc.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   ADC API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_ADC_H__
#define __QL_ADC_H__
#include "ql_type.h"
#include "ql_error.h "
/*****************************************************************
* Function:     ql_adc_sampling 
* 
* Description:
*               this function start ADC sample.
*
* Parameters:
*               mV:
*                  ADC conversion output result.
* Return:        
*               QL_RET_OK, the ADC convert succeeds.
*               QL_RET_ERR_PARAM, the input parameter is invalid.
*               QL_RET_ERR_INIT, init error.
*               QL_RET_ERR_PROGRESS, the ADC is progress.
*****************************************************************/
QL_RET ql_adc_sampling(uint32 * mV);

#endif  //__QL_ADC_H__
