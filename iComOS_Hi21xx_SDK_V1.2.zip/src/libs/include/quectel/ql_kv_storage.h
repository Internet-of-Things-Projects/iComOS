/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_kv_storage.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   The module implements some common API functions.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/

#ifndef __QL_KV_STORAGE_H__
#define __QL_KV_STORAGE_H__

#include "ql_error.h"
#include "ql_common.h"

#define KEY_VALUE_MAX_LEN   512

typedef enum {
    QL_CUSTOM_KV_ID0 = 0,
    QL_CUSTOM_KV_ID1 = 1,
    QL_CUSTOM_KV_ID2 = 2,
    QL_CUSTOM_KV_ID3 = 3,
    QL_CUSTOM_KV_ID4 = 4,
    QL_CUSTOM_KV_ID5 = 5,
    QL_CUSTOM_KV_ID6 = 6,
    QL_CUSTOM_KV_IDMAX,
} QL_CUSTOM_KV_IDS;

/*****************************************************************
* Function: 	ql_set_kv
*
* Description:
*				Store a key value pair
*
* Parameters:
*				key:
*					 [In]key to associate kvalue to.
*				kvalue: 
*					 [In]value to store.
*				kvalue_length: 
*					 [In]length in bytes of kvalue.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_set_kv(uint16 key, const uint8 *kvalue, uint16 kvalue_length);


/*****************************************************************
* Function: 	ql_get_kv
*
* Description:
*				Store a key value pair
*
* Parameters:
*				key:
*					 [In]key of the value to get.
*				kvalue_max_length: 
*					 [In]maximum length (in bytes) allowed to copy in the kvalue buffer if the key is found.
*				kvalue_length: 
*					 [Out]length of kvalue in bytes.
*				kvalue: 
*					 [Out]associated with the provided key and group.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_get_kv(uint16 key, uint16 kvalue_max_length, uint16 *kvalue_length, uint8 *kvalue);

/*****************************************************************
* Function: 	ql_erase_kv
*
* Description:
*				Erase an stored value given its key and group
*
* Parameters:
*				key:
*					 [In]key of the key to erase.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*****************************************************************/
QL_RET ql_erase_kv(uint16 key);

#endif
