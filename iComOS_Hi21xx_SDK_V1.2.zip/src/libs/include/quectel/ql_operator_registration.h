/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_operator_registration.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   OPERATOR REGISTRAION API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __OPENCPU_OPERATOR_REGISTRAION_H__
#define __OPENCPU_OPERATOR_REGISTRAION_H__

#include "ql_common.h"
#include "ql_error.h"


#define QL_DMP_MAX_IP_SIZE             20
#define QL_DMP_MAX_TM_IMEI_SIZE        20
#define QL_DMP_MAX_APPKEY_SIZE         64
#define QL_DMP_MAX_PASSWORD_SIZE       64


typedef struct ql_dmp_addr
{
    char   host[QL_DMP_MAX_IP_SIZE];
    uint16  port;
}QL_DMP_ADDR;

typedef struct ql_dmp_info
{
    uint32  interface_type;
    uint32  updatePeriod;
    char tm_imei[QL_DMP_MAX_TM_IMEI_SIZE];
    char AppKey[QL_DMP_MAX_APPKEY_SIZE]; 		//appkey
	char Pwd[QL_DMP_MAX_PASSWORD_SIZE];			//password
}QL_DMP_ONFO;

typedef enum
{
    QL_DMP_TYPE_INTERFACE        = 0,
    QL_DMP_TYPE_LINUX,
    QL_DMP_TYPE_ANDRIOD,
}QL_DMP_TEAMINAL_TYPE;

typedef enum
{
    QL_DMP_INITIAL             = 0,
    QL_DMP_CONNECT_SUCCESS     = 4,
    QL_DMP_CLOSE_OK,
    QL_DMP_CONNECT_FAILED      = 5,
    QL_DMP_REG_SUCCESS         = 6,
    QL_DMP_REG_FAILED          = 7,
    QL_DMP_REG_TIMEOUT         = 8,
    QL_DMP_UPDATE_SUCCESS      = 11,
    QL_DMP_UPDATE_FAILED       = 12,
    QL_DMP_UPDATE_TIMEOUT      = 13,
    QL_DMP_LIFETIME_TIMEOUT    = 9,
    QL_DMP_WAIT_DEREG,
    QL_DMP_WAIT_DELETE,
}QL_DMP_STATE;



/////////////////////////////////////////////////////////////////////////////////////////////



/*****************************************************************
* Function:     ql_get_chinatelcom_sreg_mode 
* 
* Description:
*               This function is used to get China Telcom registration mode.
*               
* Parameters:
*               NONE
* Return:        
*               China Telcom registration mode
*               true--China Telcom registration enabled
*               false--China Telcom registration enabled
*****************************************************************/
bool ql_get_chinatelcom_sreg_mode(void);

/*****************************************************************
* Function:     ql_set_chinatelcom_sreg_mode 
* 
* Description:
*               This function is used to set China Telcom registration mode.
*               
* Parameters:
*               ver:
*                   [In] China Telcom registration mode
*                   true--China Telcom registration enabled
*                  false--China Telcom registration enabled
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, this function failed.    
*****************************************************************/
QL_RET ql_set_chinatelcom_sreg_mode(bool mode);

/*****************************************************************
* Function:     ql_get_chinaunicom_sreg_mode 
* 
* Description:
*               This function is used to get China Unicom registration mode.
*               
* Parameters:
*               NONE
* Return:        
*               China Telcom registration mode
*               true--China Unicom registration enabled
*               false--China Unicom registration enabled
*****************************************************************/
bool ql_get_chinaunicom_sreg_mode(void);
/*****************************************************************
* Function:     ql_set_chinaunicom_sreg_mode 
* 
* Description:
*               This function is used to set China Unicom registration mode.
*               
* Parameters:
*               ver:
*                   [In] China Unicom registration mode
*                   true--China Unicom registration enabled
*                  false--China Unicom registration enabled
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, this function failed.    
*****************************************************************/
QL_RET ql_set_chinaunicom_sreg_mode(bool mode);

/*****************************************************************
* Function:     ql_get_chinaunicom_sreg_period 
* 
* Description:
*               This function is used to get China Unicom registration period.
*               
* Parameters:
*               period:
*                   [Out] Pointer of China Unicom registration period.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, this function failed. 
*****************************************************************/
QL_RET ql_get_chinaunicom_sreg_period(uint32 *period);

/*****************************************************************
* Function:     ql_set_chinaunicom_sreg_period 
* 
* Description:
*               This function is used to set China Unicom registration period.
*               
* Parameters:
*               period:
*                   [In] Pointer of China Unicom registration period.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, this function failed. 
*               QL_RET_ERR_PARAM, parameter is not correct.
*****************************************************************/
QL_RET ql_set_chinaunicom_sreg_period(uint32 period);

/*****************************************************************
* Function:     ql_get_chinamobile_dm_mode 
* 
* Description:
*               This function is used to get China Mobile registration mode.
*               
* Parameters:
*               mode:
*                   [Out] Pointer of China Mobile registration mode.
*               true--China Mobile registration enabled
*               false--China Mobile registration enabled
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_get_chinamobile_dm_mode(bool *mode);

/*****************************************************************
* Function:     ql_set_chinamobile_dm_mode 
* 
* Description:
*               This function is used to set China Mobile registration mode.
*               
* Parameters:
*               mode:
*                   [In] Pointer of China Mobile registration mode.
*               true--China Mobile registration enabled
*               false--China Mobile registration enabled
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, this function failed. 
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_set_chinamobile_dm_mode(bool mode);

/*****************************************************************
* Function:     ql_get_chinamobile_dm_configuration 
* 
* Description:
*               This function is used to get China Mobile registration configuration.
*               
* Parameters:
*               dmp_addr:
*                   [Out] Pointer of DM server address.
*               dmp_info:
*                   [Out] Pointer of DM registration configuration.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_NO_INIT,the configuration does not be initialized.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_get_chinamobile_dm_configuration(QL_DMP_ADDR *dmp_addr,QL_DMP_ONFO *dmp_info);

/*****************************************************************
* Function:     ql_set_chinamobile_dm_configuration 
* 
* Description:
*               This function is used to set China Mobile registration configuration.
*               
* Parameters:
*               dmp_addr:
*                   [In] Pointer of DM server address.
*               dmp_info:
*                   [In] Pointer of DM registration configuration.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_set_chinamobile_dm_configuration(QL_DMP_ADDR *dmp_addr,QL_DMP_ONFO *dmp_info);

/*****************************************************************
* Function:     ql_reset_chinamobile_dm_configuration 
* 
* Description:
*               This function is used to reset China Mobile registration configuration.
*               
* Parameters:
*               NONE
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_reset_chinamobile_dm_configuration(void);

/*****************************************************************
* Function:     ql_get_chinamobile_dm_state 
* 
* Description:
*               This function is used to get China Mobile registration state.
*               
* Parameters:
*               state:
*                   [Out]  China Mobile registration state.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_NOT_SUPPORT,the SDK does not support China Mobile registration.
*****************************************************************/
QL_RET ql_get_chinamobile_dm_state(QL_DMP_STATE *state);

#endif  //__QL_OPERATOR_REGISTRATION_H__