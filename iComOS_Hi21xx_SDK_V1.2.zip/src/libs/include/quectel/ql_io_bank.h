/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_io_bank.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   GPIO_VOLTAGE_BANK API defines.
 *
 * Author: Hayden.Wang
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/

#ifndef _QL_IO_BANK_H_
#define _QL_IO_BANK_H_

#include "ql_error.h "

typedef enum{
  IO_BANK_L1 ,  //default closed   ,so if you use the gpio or peripheral in this bank,you need first turn on the voltage
}ql_io_bank;

typedef enum
{
    VDD_IO_LEVEL_1V5  = 0,    //!< Set internal VDD_IO regulator to 1.5V
    VDD_IO_LEVEL_1V8  = 1,    //!< Set internal VDD_IO regulator to 1.8V
    VDD_IO_LEVEL_2V1  = 2,    //!< Set internal VDD_IO regulator to 2.1V
    VDD_IO_LEVEL_2V4  = 3,    //!< Set internal VDD_IO regulator to 2.4V
    VDD_IO_LEVEL_2V7  = 4,    //!< Set internal VDD_IO regulator to 2.7V
    VDD_IO_LEVEL_3V0  = 5,    //!< Set internal VDD_IO regulator to 3.0V
    VDD_IO_LEVEL_3V3  = 6,    //!< Set internal VDD_IO regulator to 3.3V
    VDD_IO_LEVEL_VBAT = 7,    //!< Bypass internal VDD_IO regulator and drive from VBAT
    VDD_IO_LEVEL_OFF,         //!< Used to indicate that an internal VDD_IO regulator is turned off
}IO_VOLTAGE;


/*****************************************************************
* Function: 	ql_io_bank_open
*
* Description:
*				configure IO bank voltage(turn on)
*
* Parameters:
*				bank:
*					 [In]IO bank to set on voltage level.
*               IO_VOL: 
*                    [In]voltage level to configure bank on voltage.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*****************************************************************/
QL_RET ql_io_bank_open(ql_io_bank bank,IO_VOLTAGE IO_VOL);

/*****************************************************************
* Function: 	ql_io_bank_close
*
* Description:
*				turn off IO bank voltage
*
* Parameters:
*				bank:
*					 [In]IO bank.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*               QL_RET_ERR_PARAM:
*                         Illegal parameter
*****************************************************************/
QL_RET ql_io_bank_close(ql_io_bank bank);

#endif  //__QL_IO_BANK_H__
