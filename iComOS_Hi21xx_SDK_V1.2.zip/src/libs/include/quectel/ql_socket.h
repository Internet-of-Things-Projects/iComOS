/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_socket.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   SOCKET API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __QL_SOCKET_H__
#define __QL_SOCKET_H__
#include "ql_common.h"
#include "ql_error.h"

#define  IPV4     "IPv4"    //ip type
#define  IPV6     "IPv6"

#define  TCP      "TCP"     //socket type
#define  UDP      "UDP"

/**
 * Socket status
 * Indicate the socket status updated
 */
typedef enum
{
    QL_TCP_CONNECTED,
    QL_TCP_SENT,
    QL_TCP_RECV,
    QL_TCP_ERR,
    QL_TCP_CONNECTION_CLOSED,         // Close by protocol stack when server close the connection
    QL_SOCKET_CLOSE_PASSIVE,          // Close by protocol stack when error happened
    QL_SOCKET_CLOSE_PROACTIVE,        // Close by user
    QL_SOCKET_DATA_DROPPED            // Apps cache full, DL data dropped
}QL_SOCKET_STATUS;

/**
 * Message Flags
 * Forced enumeration values to enable or of multiple flags.
 */
typedef enum {
    QL_SOCMSG_NORMAL                = 0,
    QL_SOCMSG_NEXCEPTION            = 0x100,
    QL_SOCMSG_NRELEASE              = 0x200,
    QL_SOCMSG_NRELEASE_AFTER_REPLY  = 0x400,
    QL_SOCMSGNNO_DATA_STATUS        = 0x800
} QL_SOCMSG_FLAG;


/** @brief socket recv notify callback type
 * @param socket that has received data
 * @param length amount of data to be read
 * @param addr passed into callback
 * @param addr_len length of sockaddr
*/
typedef void (*ql_socket_recv_callback)(int socket, ssize_t length);


/** @brief socket sent notify callback type
 * @param socket that has send data
 * @param seq_num data sequence number
 * @param status boolean indicating success or failure
*/
typedef void (*ql_socket_sent_notify_callback)(int socket, uint8 seq_num, bool status);

/** @brief socket status notify callback type
 * @param socket that status need report
 * @param status to report
 * @param arg socket send/recv/drop data len, or errno
*/
typedef void (*ql_socket_status_notify_callback)(int socket, QL_SOCKET_STATUS status, int arg);


/*****************************************************************
* Function: 	ql_soc_init
*
* Description:
*				initialise sockets
*
* Parameters:
*				none
* Return:
*				none
*****************************************************************/

void ql_soc_init(void);

/*****************************************************************
* Function: 	ql_soc_create
*
* Description:
*				 Create a socket. If all available sockets are in use, this will return an error
*
* Parameters:
*				soc:
*					 [Out]socekt index.
*				socket_type: 
*					 [In] string type.  "IPv4" or "IPv6".
*				loc_ip: 
*					 [In]The IP address of the network assigned to UE..
*				loc_port: 
*					 [In] Integer type. A number in the range of 0-65535 except 5683, 5684, 56830, 56831 and 56833.
*               socket_recv_callback:
*                    [In] the function will called, when soceket received data
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_PROGRESS:
*						  Process processing failed
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*****************************************************************/

QL_RET ql_soc_create(uint16 *soc, char* socket_type,char* ip_type, const char* loc_ip,uint16 loc_port, ql_socket_recv_callback socket_recv_callback);

 
/*****************************************************************
* Function: 	ql_soc_set_callback
*
* Description:
*				set callbacks for socket
*
* Parameters:
*				soc:
*					 [In]Set the callback socket.
*				sent_callback: 
*					 [In] Send result callback function.
*				status_callback: 
*					 [In]Send status callback function.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*****************************************************************/
QL_RET ql_soc_set_callback(uint16 soc,ql_socket_sent_notify_callback sent_callback,ql_socket_status_notify_callback status_callback);

 
/*****************************************************************
* Function: 	ql_soc_connect
*
* Description:
*				
*
* Parameters:
*				soc:
*					 [In] socket number from ql_soc_create().
*				remote_ip: 
*					 [In] remote ip address to connect.
*				remote_port: 
*					 [In]remote port .
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*               QL_RET_ERR_SOC_NO_NETWORK_SERVICE:
*                         No network service.
*****************************************************************/
QL_RET ql_soc_connect(uint16 soc, const char* remote_ip, uint16 remote_port);

/*****************************************************************
* Function: 	ql_soc_sendto_with_ind
*
* Description:
*				send data to a specified remote host/port
*
* Parameters:
*				soc:
*					 [In] socket number from ql_soc_create().
*				seq_num: 
*					 [In] data sequence number.
*				message: 
*					 [In] data to be sent.
*               length:
*                    [In] length of data to be sent
*				remote_ip: 
*					 [In] server ip.
*				remote_port: 
*					 [In] server port.
*               flags:
*                    [In] controls aspects of operation.
*               sent_len:
*                    [In]number of bytes of data transmitted in buffer.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*               QL_RET_ERR_SOC_NO_NETWORK_SERVICE:
*                         No network service.
*				QL_RET_ERR_SOC_FLOWCONTROL:
*						  The send buffer is full
*               QL_RET_ERR_SOC_DATA_SEQUENCE_REPEAT:
*                         Repeated sequence number.
*****************************************************************/
QL_RET ql_soc_sendto_with_ind(uint16 soc,uint8 seq_num,const void *message, size_t length, QL_SOCMSG_FLAG flags, const char* remote_ip, uint16 remote_port,uint32 *sent_len);


/*****************************************************************
* Function: 	ql_soc_send_with_ind
*
* Description:
*				send data to remote TCP host/port
*
* Parameters:
*				soc:
*					 [In] socket number from ql_soc_create().
*				seq_num: 
*					 [In] data sequence number.
*				message: 
*					 [In] data to be sent.
*				length:
*					 [In] length of data to be sent
*				flags:
*					 [In] controls aspects of operation.
*				sent_len:
*					 [In]number of bytes of data transmitted in buffer.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*				QL_RET_ERR_SOC_NO_NETWORK_SERVICE:
*						  No network service.
*				QL_RET_ERR_SOC_FLOWCONTROL:
*						  The send buffer is full
*				QL_RET_ERR_SOC_DATA_SEQUENCE_REPEAT:
*						  Repeated sequence number.
*****************************************************************/
QL_RET ql_soc_send_with_ind(uint16 soc,uint8 seq_num,const void *message, size_t length, QL_SOCMSG_FLAG flags, uint32 *sent_len);


/*****************************************************************
* Function: 	ql_soc_recvfrom
*
* Description:
*				Receive data. Can be called in blocking or non-blocking mode. Notify callback will trigger  when recvfrom() would return data.
*
* Parameters:
*				soc:
*					 [In] socket number from ql_soc_create().
*				buffer: 
*					 [Out] Receive buffer of data.
*				length: 
*					 [In] length of buffer.
*				remote_ip:
*					 [Out] server ip
*				len:
*					 [In] size of remote_ip.
*				remote_port:
*					 [Out]server port.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						  Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*****************************************************************/
QL_RET ql_soc_recvfrom(uint16 soc, void *buffer, size_t length, char* remote_ip,uint8 len, uint16 *remote_port);

 
 /*****************************************************************
 * Function:	 ql_soc_close
 *
 * Description:
 *				 Close a socket.
 * Parameters:
 *				 soc:
 *					  [In] socket number from ql_soc_create().
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_SOC_INVALID:
 *						   Illegal socket
 *				 QL_RET_ERR_SOC_ERROR:
 *						   Failed to create local socket
 *****************************************************************/
QL_RET ql_soc_close(uint16 soc);

 /*****************************************************************
 * Function:	 ql_soc_remainlen
 *
 * Description:
 *				 remaining data to be read from a socket
 * Parameters:
 *				 soc:
 *					  [In] socket number from ql_soc_create().
 *				 remainlen:
 *					  [Out] remain data length on a socket.
 * Return:
 *				 QL_RET_OK:
 *						   Indicates this function successes.
 *				 QL_RET_ERR_PARAM:
 *						  Illegal parameter
 *				 QL_RET_ERR_SOC_INVALID:
 *						   Illegal socket
 *				 QL_RET_ERR_SOC_ERROR:
 *						   Failed to create local socket
 *****************************************************************/
QL_RET ql_soc_remainlen(uint16 soc,uint32 *remainlen);

/*****************************************************************
* Function: 	ql_get_tcp_pending_data_seqs
*
* Description:
*				get tcp pending data seqs.
* Parameters:
*				soc:
*					 [In] socket number from ql_soc_create().
*				data_seqs:
*					 [Out] Sequence number.
* Return:
*				QL_RET_OK:
*						  Indicates this function successes.
*				QL_RET_ERR_PARAM:
*						 Illegal parameter
*				QL_RET_ERR_SOC_INVALID:
*						  Illegal socket
*				QL_RET_ERR_SOC_ERROR:
*						  Failed to create local socket
*****************************************************************/
QL_RET ql_get_tcp_pending_data_seqs(uint16 soc, uint8* data_seqs);

#endif  //__QL_SOCKET_H__
