/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_uart.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   UART API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef _QL_UART_H_
#define _QL_UART_H_
#include "ql_type.h"
#include "ql_error.h "

///////

typedef enum{
     UART_PORT1=0,
     UART_PORT2,   //System log printing, please do not use this UART
     UART_PORT3,   
     VIRTUAL_PORT,
     UART_NONE,
}uart_port;

///////

/** Uart data bits available */
typedef enum
{
    QL_UART_DATA_BITS_MIN_BITS = 0, /*!< Used for checking, the min value it can take */
    QL_UART_DATA_BITS_5         = 0, /*!< 5 Data bits */
    QL_UART_DATA_BITS_6         = 1, /*!< 6 Data bits */
    QL_UART_DATA_BITS_7         = 2, /*!< 7 Data bits */
    QL_UART_DATA_BITS_8         = 3, /*!< 8 Data bits */
    QL_UART_DATA_BITS_MAX_BITS = 3, /*!< Used for checking, the max value it can take*/
} QL_UART_DATA_BITS;

/** Uart parity modes available */
typedef enum
{
    QL_UART_PARITY_NONE, /*!< No parity enabled */
    QL_UART_PARITY_ODD,  /*!< Odd parity        */
    QL_UART_PARITY_EVEN, /*!< Even parity       */
}QL_UART_PARITY;

/** Uart stop bits modes available */
typedef enum
{
    QL_UART_STOP_BITS_1 = 0, /*!< 1 Stop bit*/
    QL_UART_STOP_BITS_2 = 1, /*!< 2 Stop bits */
}QL_UART_STOP_BITS;


///////

typedef struct
{
    uint32 baudrate;
    uint8  syncmode;
    QL_UART_STOP_BITS  stopbits;
    QL_UART_PARITY  parity;
    QL_UART_DATA_BITS  data_bits;
    uint8  sw_flow_control;
}ql_uart_config; //lint !e959: This is an internal structure, not shared on the wire.

typedef void(*uart_recieve_data_callback)(uint8 *,uint32);

void ql_wait_for_at_init(void);
QL_RET ql_uart_open( uart_port port,ql_uart_config *uart_config_pameter,uart_recieve_data_callback uart_receive_call_back);
QL_RET ql_uart_write(uart_port port,uint8 *buff,uint32 buff_len);
QL_RET ql_uart_init(uart_port port);
void ql_uart_close(uart_port port);

#endif  //__QL_UART_H__
