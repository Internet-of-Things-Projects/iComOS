/*****************************************************************************
*  Copyright Statement:
*  --------------------
*  This software is protected by Copyright and the information contained
*  herein is confidential. The software may not be copied and the information
*  contained herein may not be used or disclosed except with the written
*  permission of Quectel Co., Ltd. 2019
*
*****************************************************************************/
/*****************************************************************************
 *
 * Filename:
 * ---------
 *   ql_onenet_api.h 
 *
 * Project:
 * --------
 *   OpenCPU
 *
 * Description:
 * ------------
 *   ONENET API defines.
 *
 * Author:
 * -------
 * -------
 *
 *============================================================================
 *             HISTORY
 *----------------------------------------------------------------------------
 * 
 ****************************************************************************/
#ifndef __OPENCPU_ONENET_API_H__
#define __OPENCPU_ONENET_API_H__

#include "ql_common.h"
#include "ql_error.h"


typedef int32      QL_ONT_EVT;
typedef int32      QL_ONT_RET;
typedef uint8      QL_ONT_COAPRET;

/*
 * OneNET Event code
 * @QL_ONT_evt_t
 */
#define     QL_ONT_EVENT_BASE                      (QL_ONT_evt_t)0x00
#define     QL_ONT_EVENT_BOOTSTRAP_START           QL_ONT_EVENT_BASE + 1
#define     QL_ONT_EVENT_BOOTSTRAP_SUCCESS         QL_ONT_EVENT_BASE + 2
#define     QL_ONT_EVENT_BOOTSTRAP_FAILED          QL_ONT_EVENT_BASE + 3
#define     QL_ONT_EVENT_CONNECT_SUCCESS           QL_ONT_EVENT_BASE + 4
#define     QL_ONT_EVENT_CONNECT_FAILED            QL_ONT_EVENT_BASE + 5

#define     QL_ONT_EVENT_REG_SUCCESS               QL_ONT_EVENT_BASE + 6
#define     QL_ONT_EVENT_REG_FAILED                QL_ONT_EVENT_BASE + 7
#define     QL_ONT_EVENT_REG_TIMEOUT               QL_ONT_EVENT_BASE + 8

#define     QL_ONT_EVENT_LIFETIME_TIMEOUT          QL_ONT_EVENT_BASE + 9
#define     QL_ONT_EVENT_STATUS_HALT               QL_ONT_EVENT_BASE + 10
#define     QL_ONT_EVENT_UPDATE_SUCCESS            QL_ONT_EVENT_BASE + 11
#define     QL_ONT_EVENT_UPDATE_FAILED             QL_ONT_EVENT_BASE + 12
#define     QL_ONT_EVENT_UPDATE_TIMEOUT            QL_ONT_EVENT_BASE + 13
#define     QL_ONT_EVENT_UPDATE_NEED               QL_ONT_EVENT_BASE + 14


#define     QL_ONT_EVENT_UNREG_DONE                QL_ONT_EVENT_BASE + 15

#define     QL_ONT_EVENT_RESPONSE_FAILED           QL_ONT_EVENT_BASE + 20
#define     QL_ONT_EVENT_RESPONSE_SUCCESS          QL_ONT_EVENT_BASE + 21
#define     QL_ONT_EVENT_NOTIFY_FAILED             QL_ONT_EVENT_BASE + 25
#define     QL_ONT_EVENT_NOTIFY_SUCCESS            QL_ONT_EVENT_BASE + 26

#define     QL_ONT_EVENT_FIRMWARE_DOWNLOADING           QL_ONT_EVENT_BASE + 40 //enter to downloading
#define     QL_ONT_EVENT_FIRMWARE_DOWNLOAD_FAILED       QL_ONT_EVENT_BASE + 41 //enter downloading error
#define     QL_ONT_EVENT_FIRMWARE_DOWNLOADED            QL_ONT_EVENT_BASE + 42  //download finish
#define     QL_ONT_EVENT_FIRMWARE_UPDATING              QL_ONT_EVENT_BASE + 43  //updating
#define     QL_ONT_EVENT_FIRMWARE_UPDATE_SUCCESS        QL_ONT_EVENT_BASE + 44  //update success
#define     QL_ONT_EVENT_FIRMWARE_UPDATE_FAILED         QL_ONT_EVENT_BASE + 45   //update fail
#define     QL_ONT_EVENT_FIRMWARE_UPDATE_OVER           QL_ONT_EVENT_BASE + 46   //update finish
#define     QL_ONT_EVENT_FIRMWARE_DOWNLOAD_DISCONNECT   QL_ONT_EVENT_BASE + 47    //update error
#define     QL_ONT_EVENT_FIRMWARE_ERASE_SUCCESS         QL_ONT_EVENT_BASE + 48
#define     QL_ONT_EVENT_FIRMWARE_ERASE_FAIL            QL_ONT_EVENT_BASE + 49


/*
 *COAP result code 
 *@QL_ONT_ret_t
 */
#define     QL_ONT_COAP_204_CHANGED                (uint8)0x44
#define     QL_ONT_COAP_205_CONTENT                (uint8)0x45
#define     QL_ONT_COAP_206_CONFORM                (uint8)0x46
#define     QL_ONT_COAP_231_CONTINUE               (uint8)0x5F
#define     QL_ONT_COAP_400_BAD_REQUEST            (uint8)0x80
#define     QL_ONT_COAP_401_UNAUTHORIZED           (uint8)0x81
#define     QL_ONT_COAP_404_NOT_FOUND              (uint8)0x84
#define     QL_ONT_COAP_405_METHOD_NOT_ALLOWED     (uint8)0x85
#define     QL_ONT_COAP_406_NOT_ACCEPTABLE         (uint8)0x86
#define     QL_ONT_COAP_503_SERVICE_UNAVAILABLE    (uint8)0xA3



#define     QL_ONT_CALLBACK_CONFORM               QL_ONT_COAP_206_CONFORM
#define     QL_ONT_CALLBACK_BAD_REQUEST           QL_ONT_COAP_400_BAD_REQUEST
#define     QL_ONT_CALLBACK_UNAUTHORIZED          QL_ONT_COAP_401_UNAUTHORIZED
#define     QL_ONT_CALLBACK_NOT_FOUND             QL_ONT_COAP_404_NOT_FOUND
#define     QL_ONT_CALLBACK_METHOD_NOT_ALLOWED    QL_ONT_COAP_405_METHOD_NOT_ALLOWED
#define     QL_ONT_CALLBACK_NOT_ACCEPTABLE        QL_ONT_COAP_406_NOT_ACCEPTABLE
#define     QL_ONT_CALLBACK_SERVICE_UNAVAILABLE   QL_ONT_COAP_503_SERVICE_UNAVAILABLE

#define QL_URI_INVALID           ((uint16)0xFFFF)
#define QL_URI_MAX_ID            ((uint16)0xFFFF - 1)

#define QL_URI_FLAG_OBJECT_ID    (uint8)0x04
#define QL_URI_FLAG_INSTANCE_ID  (uint8)0x02
#define QL_URI_FLAG_RESOURCE_ID  (uint8)0x01

#define QL_URI_IS_SET_INSTANCE(uri) (((uri)->flag & QL_URI_FLAG_INSTANCE_ID) != 0)
#define QL_URI_IS_SET_RESOURCE(uri) (((uri)->flag & QL_URI_FLAG_RESOURCE_ID) != 0)


#define QL_ONT_MAX_IP_SIZE          20
#define QL_ONT_VERSION_SIZE         16


typedef struct onenet_init_params
{
    bool            bs_mode;
    uint16          ont_server_port;
    char            ont_server_ip[QL_ONT_MAX_IP_SIZE];
    uint8           ack_timeout;
    bool            observe_autoack_enable;
    uint16          write_format;
}QL_ONENET_INIT_PARAMS;

typedef enum
{
	data_type_undefine = 0,
	data_type_string,
	data_type_opaque,
	data_type_integer,
	data_type_float,
	data_type_bool,
}QL_ONT_DATA_TYPE;

typedef struct ql_ont_data
{
    uint16             id;
	QL_ONT_DATA_TYPE      type;

    struct
    {
        uint32    length;
        uint8*    buffer;
    }asBuffer;

	union
	{
		bool          asBoolean;
		int64         asInteger;
		double        asFloat;

	} value;
}QL_ONT_DATA;

typedef struct ql_ont_uri
{
	uint8      flag;           // indicates which segments are set
	uint16    objectId;
	uint16    instanceId;
	uint16    resourceId;
}QL_ONT_URI;

typedef struct ql_ont_observe_attr
{
    uint8     toSet;
    uint8     toClear;
    uint32  minPeriod;
    uint32  maxPeriod;
    float       greaterThan;
    float       lessThan;
    float       step;
}QL_ONT_OBSERVE_ATTR;

typedef enum {
    MSG_RAI_NORMAL      = 0,
    MSG_RAI_NRELEASE    = 0x200,
    MSG_RAI_NRELEASE_AFTER_REPLY    = 0x400,
} QL_MSG_RAI_FLAG;

typedef enum
{
    QL_WRITE_FORMAT_HEXSTRING = 0,
    QL_WRITE_FORMAT_STRING,
}QL_ONT_WRITE_FORMAT;


typedef void    (*QL_ONT_READ_CB)               (QL_ONT_URI* uri,uint32 mid);
typedef void    (*QL_ONT_WRITE_CB)              (QL_ONT_URI* uri,const QL_ONT_DATA* value,uint16 attrcount,uint32 mid);
typedef void    (*QL_ONT_EXEC_CB)               (QL_ONT_URI* uri,const uint8* buffer,uint32 length,uint32 mid);
typedef void    (*QL_ONT_OBSERVE_CB)            (QL_ONT_URI* uri,bool flag,uint32 mid);
typedef void    (*QL_ONT_DISCOVER_CB)           (uint16 objectId,uint32 mid);
typedef void    (*QL_ONT_SET_PARAMS_CB)         (QL_ONT_URI* uri,const uint8* buffer,uint32 length,uint32 mid);
typedef void    (*QL_ONT_EVENT_CB)              (QL_ONT_EVT id,uint16 ackid,uint32 mid,void* param);

typedef struct ql_ont_callback
{
    QL_ONT_READ_CB          ql_Read;
    QL_ONT_WRITE_CB         ql_Write;
    QL_ONT_EXEC_CB          ql_Exec;
    QL_ONT_OBSERVE_CB       ql_Observe;
	QL_ONT_DISCOVER_CB      ql_Discover;
	QL_ONT_SET_PARAMS_CB    ql_SetParams;
    QL_ONT_EVENT_CB         ql_Event;
}QL_ONT_CALLBACK;

/////////////////////////////////////////////////////////////////////////////////////////////



/*****************************************************************
* Function:     ql_onenet_get_version 
* 
* Description:
*               This function is used to get version of OneNET sdk.
*               
* Parameters:
*               ver:
*                   [In] Pointer of version buffer.
*               length:
*                   [In] Length of version buffer.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*****************************************************************/
QL_RET ql_onenet_get_version(char *ver,uint8 length);

/*****************************************************************
* Function:     ql_onenet_init 
* 
* Description:
*               This function is used to configure bootstrap mode and bootstrap server address or LwM2M server address. 
*               It can also be used to set the parameter ACK_TIMEOUT of CoAP protocol. 
*               MAX_TRANSMIT_WAIT of CoAP protocol implemented by the UE = ACK_TIMEOUT * ((2(4+1)) - 1). 
*               
* Parameters:
*               onenet_init_params:
*                   [In] Confiuraton parameters.
*                   < bs_mode>:
*                   true--enable bootstrap mode
*                   false--disable bootstrap mode
*                   <ont_server_port>:
*                   When <bs_mode>is true, <port> is bootstrap server port.
*                   When <bs_mode>is false, <port> is LwM2M server port.
*                   <ont_server_ip>:
*                   When <bs_mode>is true, <port> is bootstrap server IP address.
*                   When <bs_mode>is false, <port> is LwM2M server IP address.
*                   <ack_timeout>:
*                   Value of ACK_TIMEOUT. Range: 2-20. Unit: second. Default value: 2.
*                   <observe_autoack_enable>:
*                   Set whether to enable the module to automatically respond to observe requests.
*                   false--Disable automatic observe request response.
*                   true--Enable automatic observe request response and program should not respond to observerequest.
*                   <write_format>:
*                   Output format of received write data
*                   0--Hexstring
*                   1--String
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_RE_INIT, reinitialize error.
*               QL_RET_ERR_PARAM, parameter is not correct.
*****************************************************************/
QL_RET ql_onenet_init(QL_ONENET_INIT_PARAMS *onenet_init_params);

/*****************************************************************
* Function:     ql_onenet_get_config 
* 
* Description:
*               This function is used to get configuration parameters.
*               
* Parameters:
*               onenet_init_params:
*                   [In] [Out] Pointer of configuration parameters.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, get configuration parameters failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_get_config(QL_ONENET_INIT_PARAMS *onenet_init_params);

/*****************************************************************
* Function:     ql_onenet_deinit 
* 
* Description:
*               This function is used to deinitilize OneNET communication suite instance.             
* Parameters:
*               None
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, deinitilize failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_deinit(void);

/*****************************************************************
* Function:     ql_onenet_addobj 
* 
* Description:
*               This function is used to add object and instance.
*               
* Parameters:
*               object_id:
*                   [In] Object id,which will be create on platform.
*               instanceCount:
*                   [In] Count of instance.
*               instanceBitmap:
*                   [In] Pointer of instanceBitmap,the length of instanceBitmap should be equal to <instanceCount>.
*                         For example, if <instanceCount>=4, and the <instanceBitmap>="1101", it means that the instance ID 0, 1, 3 will be registered, 
*                         while the instance ID 2 will not be registered.
*               attributeCount:
*                   [In] Attribute count, which indicates the count of readable and/or writeable resources.
*               actionCount:
*                   [In] Action count, which indicates the count of executable resources.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, add object failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_addobj(uint32 object_id,uint16 instanceCount,char * instanceBitmap,uint16 attributeCount,uint16 actionCount);


/*****************************************************************
* Function:     ql_onenet_deleteobj 
* 
* Description:
*               This function is used to delete object.
*               
* Parameters:
*               object_id:
*                   [In] Object id,which will be delete from platform.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, delete object failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_deleteobj(uint32 object_id);

/*****************************************************************
* Function:     ql_onenet_connect 
* 
* Description:
*               This function is used to send a register request to OneNET platform.
*               
* Parameters:
*               lifetime:
*                   [In] lifetime value. The range is 0 or 16-268435454. Unit: second. "0" means that lifetime is 86400 seconds..
*               timeout:
*                   [In] Timeout of registration. Range: 30-65535. Unit: second.
*               callback:
*                   [In] Struct of callback function, all operation related message will be passed by call corresponding call back function.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, registeration failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_connect(uint32 lifetime,uint16 timeout,QL_ONT_CALLBACK callback);

/*****************************************************************
* Function:     ql_onenet_disconnect 
* 
* Description:
*               This function is used to send an deregister request to OneNET platform.
*               
* Parameters:
*               None
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PROGRESS, can not execute deregister operation.
*****************************************************************/
QL_RET ql_onenet_disconnect(void);

/*****************************************************************
* Function:     ql_onenet_update 
* 
* Description:
*               This function is used to send an update request to update lifetime and objects to OneNET platform.
*               
* Parameters:
*               lifetime:
*                   [In] Updated lifetime value. The range is 0 or 16-268435454. Unit: second. "0" means that lifetime is 86400 seconds..
*               withobject_flag:
*                   [In] Whether to update with objects list.
*                         false--Update without objects list.
*                         true--Update with objects list.
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, update failure or other unknown error.
*****************************************************************/
QL_RET ql_onenet_update(uint32 lifetime,bool withobject_flag,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_observe_response 
* 
* Description:
*               This function response to Observe request from OneNET platform or Application server.
*               
* Parameters:
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Observe callback function passed.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_205_CONTENT means Observe operation is success.
*                         Other result code can be chosed accordingly. 
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the respond is timeout or other unknown error.
*****************************************************************/
QL_RET ql_onenet_observe_response(uint32 msgid,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_observe_param_response 
* 
* Description:
*               This function response to Write-Attributes request from OneNET platform or Application server.
*               
* Parameters:
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Write-Attributes(ql_SetParams) callback function passed.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_204_CHANGED means Write-Attributes operation is success.
*                         Other result code can be chosed accordingly. 
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the respond is timeout or other unknown error.
*****************************************************************/
QL_RET ql_onenet_observe_param_response(uint32 msgid,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_discover_response 
* 
* Description:
*               This function response to Discover request from OneNET platform or Application server.
*               
* Parameters:
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Discover callback function passed.
*               count:
*                   [In] The count of resources.
*               reslist:
*                   [In] The list of resource identifiers.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_205_CONTENT means Discover operation is success.
*                         Other result code can be chosed accordingly. 
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the respond is timeout or other unknown error.
*****************************************************************/
QL_RET ql_onenet_discover_response(uint32 msgid,uint8 count,uint16 *reslist,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_read_response 
* 
* Description:
*               This function response to Read request from OneNET platform or Application server.
*               
* Parameters:
*               uri:
*                   [In] URI.
*               value:
*                   [In] The  pointer of message need to be sent.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_205_CONTENT means sending the message immediately
*                         QL_ONT_COAP_231_CONTINUE means the message should be sent combining with next message with result code QL_ONT_COAP_205_CONTENT.
*                         Other result code can be chosed accordingly. 
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Read callback function passed.
*               ackid:
*                   [In] 0--Message will be sent in NON message.
*                         Nonzero --Message will be sent in CON message.
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the uri is not observed or other unknown error.
*****************************************************************/
QL_RET ql_onenet_read_response(const QL_ONT_URI* uri,const QL_ONT_DATA* value,uint32 msgid,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_write_response 
* 
* Description:
*               This function response to Write request from OneNET platform or Application server.
*               
* Parameters:
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Write callback function passed.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_204_CHANGED means Write operation is success.
*                         Other result code can be chosed accordingly. 
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the respond is timeout or other unknown error.
*****************************************************************/
QL_RET ql_onenet_write_response(uint32 msgid,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_execute_response 
* 
* Description:
*               This function response to Execute request from OneNET platform or Application server.
*               
* Parameters:
*               msgid:
*                   [In] Message identifier,should be same with the parameter "mid" Execute callback function passed.
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_204_CHANGED means Execute operation is success.
*                         Other result code can be chosed accordingly. 
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the respond is timeout or other unknown error.
*****************************************************************/
QL_RET ql_onenet_execute_response(uint32 msgid,QL_ONT_COAPRET result,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:     ql_onenet_notify 
* 
* Description:
*               This function notify message to OneNET platform.
*               
* Parameters:
*               uri:
*                   [In] URI.
*               value:
*                   [In] The  pointer of message need to be sent..
*               result:
*                   [In] Result code.
*                         QL_ONT_COAP_205_CONTENT means sending the message immediately
*                         QL_ONT_COAP_231_CONTINUE means the message should be sent combining with next message with result code QL_ONT_COAP_205_CONTENT. 
*                         Other result code can be chosed accordingly. 
*               ackid:
*                   [In] 0--Message will be sent in NON message.
*                         Nonzero --Message will be sent in CON message.
*               rai_flag:
*                   [In] MSG_RAI_NORMAL--Send message without RAI flag.
*                         MSG_RAI_NRELEASE--Send message with RELEASE auxiliary instructions.
*                         MSG_RAI_NRELEASE_AFTER_REPLY--Send message with RELEASE auxiliary instructions.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, parameter is not correct.
*               QL_RET_ERR_PROGRESS, the uri is not observed or other unknown error.
*****************************************************************/
QL_RET ql_onenet_notify(const QL_ONT_URI* uri,const QL_ONT_DATA* value,QL_ONT_COAPRET result,uint16 ackid,QL_MSG_RAI_FLAG rai_flag);

/*****************************************************************
* Function:  ql_onenet_uri_make 
* 
* Description:
*               This function makes QL_ONT_URI structure.
*               
* Parameters:
*               oid:
*                   [In] Object ID.
*               iid:
*                   [In] Instance ID.
*               rid:
*                   [In] Resource ID.
*               uri:
*                   [Out] URI pointer.
* Return:        
*               QL_RET_OK, this function succeeds.
*               QL_RET_ERR_PARAM, uri is NULL.
*****************************************************************/
QL_RET ql_onenet_uri_make(uint16 oid,uint16 iid,uint16 rid, QL_ONT_URI* uri);

#endif  //__OPENCPU_ONENET_API_H__