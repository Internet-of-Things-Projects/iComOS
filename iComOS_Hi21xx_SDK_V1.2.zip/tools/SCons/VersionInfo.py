import os
import platform
import subprocess
import errno


_root = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.realpath(__file__)))), "build_scons")

def _get_description_from_git():
    try:
        git_string = subprocess.check_output(["git", "describe", "--tags", "--first-parent", "--dirty", "--always"]).strip()
    except:
        git_string = "UNKNOWN"
    return git_string

def get_git_hash():
    description = _get_description_from_git()
    desc_list = description.split("-")
    
    if desc_list[-1] == "dirty":
        git_hash = desc_list[-2] + "-dirty"
    else:
        git_hash = desc_list[-1]

    return (git_hash, description)
    
def read_string(filename):
    filepath = os.path.join(_root, filename)
    with open(filepath,'a+') as f: #modify by Hayden@20171107
        str = f.read()
        f.close()
        return str


def _update_string(filename, string):
    # update version info file if changed
    
    filepath = os.path.join(_root, filename)
    
    if not os.path.exists(_root):
        os.makedirs(_root)
    
    existing_string = read_string(filename) if os.path.exists(filepath) else ''

    if existing_string != string:
        print "Updating", filename, "file"
        with open(filepath, "w") as f:
            f.write(string)
            

def update_version(ARGUMENTS):
    (git_hash, description) = get_git_hash()
    
    if "VERSION_STRING" in ARGUMENTS:
        version_string = ARGUMENTS["VERSION_STRING"]
    else:
        version_string = description + "-" + platform.node()
    
    # Limit to what the target code can handle - must fit in a 48 char array so it has a maximum of 47 characters.
    # Magic number shared with source code in the build_version module!
    version_string = version_string[:47]
    
    #delete  by Hayden @20170824
    #print "Using version string:", version_string
    #print "Using git hash:", git_hash
                
    _update_string("VERSION_STRING", version_string)
    _update_string("GIT_HASH", git_hash)

#add by Hayden @20170721    
    if "SUB_VERSION" in ARGUMENTS:
        subvers_string = ARGUMENTS["SUB_VERSION"]
    else:
        subvers_string = "NO SUBVER"

    subvers_string = subvers_string[:47]
    _update_string("SUB_VERSION", subvers_string)
#add end

#add by Hayden @20170824
    if "BAND_STR" in ARGUMENTS:
        band_string = ARGUMENTS["BAND_STR"]
    else:
        band_string = "NOBAND"

    band_string = band_string[:9]
    _update_string("BAND_STR", band_string)

    if "HW_STR" in ARGUMENTS:
        hw_string = ARGUMENTS["HW_STR"]
    else:
        hw_string = "NOHW"

    hw_string = hw_string[:9]
    _update_string("HW_STR", hw_string)

    if "MODULE" in ARGUMENTS:
        module_string = ARGUMENTS["MODULE"]
    else:
        module_string = "NOMODULE"

    module_string = module_string[:9]
    _update_string("MODULE", module_string)
#add end