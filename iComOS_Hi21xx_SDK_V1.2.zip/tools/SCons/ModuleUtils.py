#===============================================================================
# @brief    Scons make file
# Copyright (c) 2016 NEUL LIMITED
#===============================================================================

import os
import re
import itertools
from SCons.Script import *
from EnvironmentUtils import *
from common_tools import *

# The top level XML generation needs an include path which has the build_scons
# private directory for each module which uses an FSM, so remember that here as
# we don't have a good way to pass that information back to the top level. The
# XML generation code reaches in and reads this when it wants it.
fsm_inc_dirs = []

class MembersFromInit(object):
    def __init__(self, **args):
        # Set the keyword arguments as attributes on this instance.
        # That means we can instantiate the class like MembersFromInit(thing=2,
        # thang="jjj") and end up with self.thing=2 and self.thang="jjj"
        for a in args:
            setattr(self, a, args[a])

class TestAndLib(MembersFromInit):
    pass

class Test(MembersFromInit):
    pass

# It is assumed this is instantiated within a module SConscript,
# so I'm taking it that all paths are relative to the module the 
# instance is created for.
class Module:
    def __init__(self, name, env, components = None, sources = None, public_inc_dirs = None, private_inc_dirs = None, additional_release_files = None, cpp_defines = None):
        self.name = name
        self.env = env.Clone()
        self.components = [] if components is None else components
        self.module_test_opt_libs = []
        self.module_test_libs_to_link = []
        
        # Source public and private to keep implemented behaviour
        self.source_files  = Flatten(sources) if sources is not None else sources    
            
        if public_inc_dirs is None:
            self.public_inc_dirs = [os.path.join(Dir('.').srcnode().abspath, 'public')]
        else:
            self.public_inc_dirs = public_inc_dirs
        
        env.Append(CPPPATH = self.public_inc_dirs)  
            
        if private_inc_dirs is None:
            self.private_inc_dirs = [os.path.join(Dir('.').srcnode().abspath, 'private')]
        else:
            self.private_inc_dirs = private_inc_dirs

        self.additional_release_files  = [] if additional_release_files is None else additional_release_files            
        self.cpp_defines  = [] if cpp_defines is None else cpp_defines            


    def _expose_public_path(self, path):
        if os.path.exists(path):
            public_header_files = Glob(os.path.join(path, '*.h'))
            # We'll need a list of header files for Robot ctypesgen tool
            NeulBuildConfig.add_public_headers(public_header_files)
            self.env.Append(CPPPATH = [path])

    def add_module_test_optional_lib(self, module):
        """
        Module tests sometimes need to be linked against another library,
        for instance, RRC needs the ASN library to be module-tested.
        We can't get it in with how the current build system conventions,
        but we can use this method to specify what libraries to link against,
        when we compile for module tests.
        """
        self.module_test_opt_libs.append(module)

    # helper functions to build a library and export the include paths
    def build(self, env):
        self.subproducts = []

        # Get the build artifacts of all submodules.
        for component in self.components:
            built_lib = SConscript(os.path.join(component, 'SConscript'), {'env': self.env })
            self.subproducts.append( built_lib )
            
            # Special case: If this module wants to link against a subproduct for module tests,
            # add the build lib to a list. We do this for RRC and ASN library.
            if component in self.module_test_opt_libs:
                # Note CXXTEST product is a TestAndLib object, so extract just the libs.
                if NeulTargetConfig.get_build_type(env) == BuildType.CXXTEST_ALL:
                    self.module_test_libs_to_link.append(built_lib.libs)
                else:
                    self.module_test_libs_to_link.append(built_lib)
                
                if 'LIBS' in self.env:
                    self.module_test_libs_to_link.append(self.env['LIBS'])

        self.robot_kwrd_lib = Glob(os.path.join('.', 'test', 'robot', '*.py'))
        self.robot_kwrd_lib.append(NeulBuildConfig.ROBOT_KEYWORDS_LIB_PATH)
        if self.source_files is None:        
            self.source_files = Glob(os.path.join('private', '*.c'))
        fsm_sources = self.autogen_fsms()

        # For fsm generated code to compile, we need to provide access to the private
        # header files so files under build_scons can see them. Similarly, src needs to 
        # see the generated header files under build_scons. If we add 'private' to CPPPATH,
        # it will make it look like the generated FSM files are under the source tree, in 'private'.
        # Of course, we want this to apply only for this module, so we clone the environment
        # to leave the common CPPPATH unaffected
        if fsm_sources is not None:
            self.env.Append(CPPPATH = os.path.join(Dir('.').abspath, 'private'))
            fsm_inc_dirs.append(os.path.join(Dir('.').abspath, 'private'))
            for fsm_source in fsm_sources:
                if fsm_source not in self.source_files:
                    self.source_files.extend([fsm_source])

        if NeulTargetConfig.get_build_type(env) == BuildType.ROBOT_TEST:
            self.subproducts.extend( self._build_robot_tests() )
        elif NeulTargetConfig.get_build_type(env) == BuildType.ARM:
            self.subproducts.extend( self.env.Library(target = self.name, source = self.source_files) )
        elif NeulTargetConfig.get_build_type(env) == BuildType.CXXTEST:
            self.subproducts.extend( self._build_unit_tests() )
        elif NeulTargetConfig.get_build_type(env) == BuildType.LINT:
            if self.source_files != []:
                self.subproducts.extend( self.env.PcLintLob(target = self.name, source = self.source_files) )
        elif NeulTargetConfig.get_build_type(env) in [BuildType.SOURCE_PACKAGE, BuildType.DOXYGEN]:
            return self
        elif NeulTargetConfig.get_build_type(env) == BuildType.CXXTEST_ALL:
            self.subproducts.extend( self._build_cxxtest_all() )

        return self.subproducts

    def autogen_fsms(self):
        fsm_path = os.path.join(Dir('.').srcnode().abspath, 'fsm')
        out_path = os.path.join(Dir('.').abspath, 'private')
        return generate_fsm_sources(self.env, fsm_path, out_path)

    def _build_robot_tests(self):
        test_results = []
        all_headers = []
        self.source_files.extend(Glob(os.path.join('.', 'test', 'robot', 'stubs', '*.c')))
        self.env.Prepend(CPPPATH = os.path.join(Dir('.').srcnode().abspath, 'test', 'robot', 'stubs'))
        self.env.Append(CPPPATH = os.path.join(Dir('.').srcnode().abspath, 'private'))
        self.robot_tests = Glob(os.path.join('.', 'test', 'robot', '*.txt'))
        tests_to_run = []

        # Run only matching tests, if specified from command line
        if len(NeulBuildConfig.get_selected_tests()) > 0:
            for i in self.robot_tests:
                for s in NeulBuildConfig.get_selected_tests():
                    if s in str(i):
                        tests_to_run.append(i)
        else:
            tests_to_run = self.robot_tests

        if len(tests_to_run) >0 :
            # Remove duplicate entries
            self.source_files = sorted(set(self.source_files))
            sos = [ self.env.SharedObject(File(src)) for src in self.source_files ]
            self.lib = self.env.SharedLibrary(self.name, sos, LIBS = self.module_test_libs_to_link)
            test_results = self.env.run_robot_tests(self.name, self.lib, self.robot_kwrd_lib, self.source_files, tests_to_run)

        return test_results

    def _build_unit_tests(self):
        unit_tests = []
        self.cxxtests = Glob(os.path.join('.', 'test', 'cxxtest', '*.h'))
        self.source_files.extend(Glob(os.path.join('.', 'test', 'cxxtest', 'stubs', '*.c')))
        for dirname in self.private_inc_dirs:
            self.env.Prepend(CPPPATH = dirname)
        self.env.Prepend(CPPPATH = os.path.join(Dir('.').srcnode().abspath, 'test', 'cxxtest', 'stubs'))

        if (len(NeulBuildConfig.get_selected_tests()) > 0 and self.name in NeulBuildConfig.get_selected_tests()) or len(NeulBuildConfig.get_selected_tests()) == 0:
            if len(self.cxxtests) > 0:
                self.lib = self.env.Library(self.name, self.source_files)
                for t in self.cxxtests:
                    # The build environment is different for each test, because
                    # each one may have different LINKFLAGS depending on what
                    # is declared as __wrap in the _test.h file.
                    test_env = self.env.Clone()

                    test_part = test_env.CxxtestPart(t)
                    test_name = os.path.splitext(os.path.basename(t.abspath))[0]
                    test_root = test_env.CxxtestRoot(test_name, test_part)

                    # Manifest required to prevent windows requiring admin priveleges.
                    manifest = test_env.InstallAs(test_name + ".exe.manifest", "#tools/cxxtest.manifest")
                    Depends(test_root, manifest)

                    # Where we need to generate wrapped symbols list to pass to the
                    # linker. This comes from parsing the library for __wrap_
                    # symbols and appending all wrapped function to the
                    # LINKFLAGS
                    test_part_obj = test_env.Object(test_part)
                    wrapped_symbols = test_env.WrappedSymbolsList(test_name + '_wrapped_symbols', [self.lib, test_part_obj])
                    wrap_ld_args = test_env.WrappedArgsList(test_name + '_wrapped_symbols_', wrapped_symbols)
                    if 'LIBS' in self.env:
                        self.module_test_libs_to_link.append(self.env['LIBS'])
                        
                    p = test_env.Program([test_root, test_part_obj], LIBS = [self.lib] + self.module_test_libs_to_link)
                    Depends(p, wrap_ld_args)
                    unit_tests.extend(p)

        # Return a list of all executables, one for each unit test
        return unit_tests
    
    def _build_cxxtest_all(self):
        """
        These are Cxxtests which link against a library composed of the whole system.
        """
        tests = Glob(os.path.join('.', 'test', 'cxxtest_all', '*.h'))
        self.env.Prepend(CPPPATH = os.path.join(Dir('.').srcnode().abspath, 'private'))

        # Allow Helper functions for tests from all layers
        self.source_files.extend(Glob(os.path.join('.', 'test', 'cxxtest_all', 'helper', '*.c')))

        test_list = []
        lib = self.env.Library(self.name, self.source_files)
        if (len(NeulBuildConfig.get_selected_tests()) > 0 and self.name in NeulBuildConfig.get_selected_tests()) or len(NeulBuildConfig.get_selected_tests()) == 0:
            if len(tests) > 0:
                for t in tests:
                    # The build environment is different for each test, because
                    # each one may have different LINKFLAGS depending on what
                    # is declared as __wrap in the _test.h file.
                    test_env = self.env.Clone()

			        # Add the paths to the helper interface files       
                    for helper_path in test_env['HELPERPATH']:
                        test_env.Prepend(CPPPATH = test_env['HELPERPATH'])
       
                    test_part = test_env.CxxtestPart(t)
                    test_name = os.path.splitext(os.path.basename(t.abspath))[0]
                    test_root = test_env.CxxtestRoot(test_name, test_part)

                    # Manifest required to prevent windows requiring admin priveleges.
                    manifest = test_env.InstallAs(test_name + ".exe.manifest", "#tools/cxxtest.manifest")
                    Depends(test_root, manifest)

                    # Where we need to generate wrapped symbols list to pass to the
                    # linker. This comes from parsing the library for __wrap_
                    # symbols and appending all wrapped function to the
                    # LINKFLAGS
                    test_part_obj = test_env.Object(test_part)
                    wrapped_symbols = test_env.WrappedSymbolsList(test_name + '_wrapped_symbols', [test_part_obj])
                    wrap_ld_args = test_env.WrappedArgsList(test_name + '_wrapped_symbols_', wrapped_symbols)

                    # Make a Test namedtuple with the information needed to
                    # complete the build once we have a library containing the
                    # entire firmware.
                    test_list.append(Test(root=test_root, part_obj=test_part_obj, env=test_env, wrap_ld_args=wrap_ld_args))

        ret = TestAndLib(libs = lib, tests= test_list)
        return [ret]

    def get_sources(self):
        return self.source_files
        
    def get_public_inc_dirs(self):
        return self.public_inc_dirs
        
    def get_private_inc_dirs(self):
        return self.private_inc_dirs

    def get_additional_release_files(self):
        return self.additional_release_files
        
    def get_name(self):
        return self.name
    
    def get_additional_files(self):
        return self.aditional_files   

    def add_module(self, sm):
        self.source_files.extend(sm.get_sources())
        self.public_inc_dirs.extend(sm.get_public_inc_dirs())
        self.private_inc_dirs.extend(sm.get_private_inc_dirs())  
        self.additional_release_files.extend(sm.get_additional_release_files())  

    def add_public_inc_dirs(self, public_inc_dirs_list):
        self.public_inc_dirs.extend(public_inc_dirs_list)
 
    def add_private_inc_dirs(self, private_inc_dirs_list):
        self.private_inc_dirs.extend(private_inc_dirs_list)
        
    def add_cpp_defines(self, cpp_defines_list):
        self.cpp_defines.extend(cpp_defines_list)
 
    def get_cpp_defines(self):
        return self.cpp_defines        
