#include "ql_common.h"
#include "ql_string.h"
#include "ql_uart.h"
#include "ql_app_debug.h"
#include "ql_gpio.h"
#include "example.h"
static osTimerId_t timer_handle;
static uint32 m_nInterval = 500;//500ms
// Define GPIO pin
static Enum_PinName m_gpioPin = PINNAME_NETLIGHT;
static void uart1_recieve_handle(uint8 *buffer,uint32 len)
{
	(void)buffer;
	(void)len;
}
// Define a timer and the handler
static void Callback_OnTimer(void)
{
	Enum_PinLevel gpioLvl = ql_gpio_get_level(m_gpioPin);
	if (PINLEVEL_LOW == gpioLvl)
	{
		// Set GPIO to high level, then LED is light
		ql_gpio_set_level(m_gpioPin, PINLEVEL_HIGH);
		APP_DEBUG ("<-- Set NETLIGHT GPIO to high level -->\r\n");
	}
	else
	{
		// Set GPIO to low level, then LED is dark
		ql_gpio_set_level(m_gpioPin, PINLEVEL_LOW);
		APP_DEBUG ("<-- Set NETLIGHT GPIO to low level -->\r\n");
	}
}
/************************************************************************
* Main Task
************************************************************************/
void main_task( void *unused )
{
	(void) unused;
	// Define uart1_config varible
	ql_uart_config uart1_config;
	QL_RET ret = 0;
	ql_wait_for_at_init(); //wait for modem ok
	// Initialize UART1
	if (ql_uart_init(UART_PORT1) != QL_RET_OK)
	{
		QDEBUG_TRACE("uart port1 init error");
	}
	else
	{
		QDEBUG_TRACE("uart port1 init succ");
	}
	uart1_config.baudrate=9600;
	uart1_config.data_bits=QL_UART_DATA_BITS_8;
	uart1_config.parity=QL_UART_PARITY_NONE;
	uart1_config.stopbits=QL_UART_STOP_BITS_1;
	// Open UART1
	if (ql_uart_open(UART_PORT1, &uart1_config, uart1_recieve_handle) != QL_RET_OK )
	{
		QDEBUG_TRACE("uart port1 open error");
	}
	else
	{
		QDEBUG_TRACE("uart port1 open succ");
	}
	APP_DEBUG ("\r\n <-- OpenCPU: LED Blinking by NETLIGH -->\r\n");
	// Initialize GPIO
	ret = ql_gpio_init (m_gpioPin, PINDIRECTION_OUT, PINLEVEL_LOW);
	if (QL_RET_OK == ret)
	{
		APP_DEBUG ("\r\n<-- Initialize NETLIGHT GPIO succ -->\r\n");
	}
	else
	{
		APP_DEBUG ("<-- Initialize NETLIGHT GPIO error, cause=%d -->\r\n", ret);
	}
	ret = ql_gpio_pull_config (m_gpioPin, PIN_PULL_DOWN);
	if (QL_RET_OK == ret)
	{
		APP_DEBUG ("<-- Set NETLIGHT GPIO pull down succ -->\r\n");
	}
	else
	{
		APP_DEBUG ("<-- Set NETLIGHT GPIO pull down error, cause=%d -->\r\n", ret);
	}
	timer_handle = osTimerNew((osTimerFunc_t)Callback_OnTimer, osTimerPeriodic, NULL, NULL);
	osTimerStart(timer_handle, m_nInterval);
	while(true)
	{
		osDelay(10);
	}
}
